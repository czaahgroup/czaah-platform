'use client'
// @ts-nocheck

import { useState, useEffect, type FormEvent } from 'react'
import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [interest, setInterest] = useState('')

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const interestParam = params.get('interest')
    if (interestParam) {
      setInterest(interestParam)
    }
    if (window.location.hash === '#contact-form') {
      setTimeout(() => {
        const form = document.getElementById('contact-form')
        if (form) form.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }, 300)
    }
  }, [])

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)

    const form = e.currentTarget
    const formData = new FormData(form)

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.get('name'),
          email: formData.get('email'),
          phone: formData.get('phone') || '',
          interest: formData.get('interest'),
          message: formData.get('message'),
        }),
      })

      const result = await res.json()

      if (res.ok) {
        setSubmitted(true)
      } else {
        setError(result.error || 'Something went wrong. Please try again.')
      }
    } catch {
      setError('Network error. Please check your connection and try again.')
    }

    setSubmitting(false)
  }

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: `
        .contact-form { display: flex; flex-direction: column; gap: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group label { font-size: 12px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--gold); font-weight: 500; }
        .form-group input, .form-group select, .form-group textarea {
          background: rgba(255,255,255,0.03); border: 1px solid var(--black-border); border-radius: 8px;
          padding: 14px 16px; color: var(--white); font-family: 'Raleway', sans-serif; font-size: 14px;
          transition: border-color 0.3s ease; outline: none;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: var(--gold); }
        .form-group select { appearance: none; cursor: pointer; }
        .form-group select option { background: #0F0F0F; color: var(--white); }
        .form-group textarea { resize: vertical; min-height: 120px; }
        .form-group input::placeholder, .form-group textarea::placeholder { color: rgba(255,255,255,0.25); }
        .contact-info-card { padding: 24px; background: var(--black-card); border: 1px solid var(--black-border); border-radius: 14px; transition: all 0.5s var(--ease-smooth); }
        .contact-info-card:hover { border-color: rgba(201, 168, 76, 0.2); transform: translateY(-2px); box-shadow: 0 12px 36px rgba(0, 0, 0, 0.3); }
        .contact-info-card h4 { font-size: 14px; font-weight: 600; margin-bottom: 6px; }
        .contact-info-card p { font-size: 13px; line-height: 1.6; color: var(--white-muted); }
        .contact-info-cards { display: flex; flex-direction: column; gap: 16px; }
        .contact-success { padding: 48px 24px; background: var(--black-card); border: 1px solid var(--black-border); border-radius: 14px; text-align: center; }
        .contact-success h3 { font-family: 'Cinzel', serif; font-size: 24px; color: var(--gold); margin-bottom: 12px; }
        .contact-success p { font-size: 14px; color: var(--white-muted); line-height: 1.6; }
        .form-error { font-size: 13px; padding: 12px 16px; border-radius: 8px; background: rgba(220,38,38,0.1); border: 1px solid rgba(220,38,38,0.2); color: #f87171; }
      `}} />

      <div className="page-wrap">
        <Navbar />

        {/* HERO */}
        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Contact.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Get in Touch</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Contact <span className="gold">us.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Institutional investors, family offices, sovereign entities, and corporate leadership evaluating Pakistan &mdash; we welcome a confidential conversation.</p>
              <a href="#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Send a Message &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* CONTACT FORM + INFO */}
        <section className="section fade-in" id="contact-form">
          <h2 className="serif">Send us a <span className="gold">message.</span></h2>
          <p className="subtitle">Tell us about your investment interests and we&apos;ll arrange a confidential consultation.</p>

          <div className="split" style={{ marginTop: 48, alignItems: 'start' }}>
            <div className="fade-in-left">
              {submitted ? (
                <div className="contact-success">
                  <h3>Message Received</h3>
                  <p>Thank you for reaching out. A member of our team will respond within 24 hours. A confirmation email has been sent to your inbox.</p>
                </div>
              ) : (
                <form className="contact-form" onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" placeholder="Your name" required />
                  </div>
                  <div className="form-group">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="your@email.com" required />
                  </div>
                  <div className="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone" placeholder="+971 XX XXX XXXX" />
                  </div>
                  <div className="form-group">
                    <label>Interest Area</label>
                    <select name="interest" id="interestSelect" value={interest} onChange={(e) => setInterest(e.target.value)}>
                      <option value="">Select an area...</option>
                      <optgroup label="Sectors">
                        <option value="Minerals & Mining">Minerals &amp; Mining</option>
                        <option value="Real Estate">Real Estate</option>
                        <option value="Construction & Development">Construction &amp; Development</option>
                        <option value="Technology & IT">Technology &amp; IT</option>
                        <option value="Textiles & Trade">Textiles &amp; Trade</option>
                        <option value="Agriculture">Agriculture</option>
                        <option value="Pharmaceuticals">Pharmaceuticals</option>
                        <option value="Engineering & Energy">Engineering &amp; Energy</option>
                        <option value="Aviation">Aviation</option>
                        <option value="Human Resources">Human Resources</option>
                        <option value="Tourism & Hospitality">Tourism &amp; Hospitality</option>
                        <option value="Luxury Car Rentals">Luxury Car Rentals</option>
                        <option value="Education">Education</option>
                      </optgroup>
                      <optgroup label="Services">
                        <option value="Business Setup">Business Setup</option>
                        <option value="Licensing & Compliance">Licensing &amp; Compliance</option>
                        <option value="Import & Export">Import &amp; Export</option>
                        <option value="Investor Protection">Investor Protection</option>
                        <option value="Investment Advisory">Investment Advisory</option>
                        <option value="Partnership Development">Partnership Development</option>
                        <option value="Government Contracts">Government Contracts</option>
                        <option value="Security Services">Security Services</option>
                        <option value="Payment Solutions">Payment Solutions</option>
                        <option value="Investment Migration">Investment Migration</option>
                      </optgroup>
                      <option value="General Inquiry">General Inquiry</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Message</label>
                    <textarea name="message" rows={5} placeholder="Tell us about your investment interests..."></textarea>
                  </div>
                  {error && <div className="form-error">{error}</div>}
                  <button type="submit" className="btn-gold" style={{ width: '100%', justifyContent: 'center' }} disabled={submitting}>
                    {submitting ? 'Sending...' : 'Send Message \u2192'}
                  </button>
                </form>
              )}
            </div>
            <div className="fade-in-right">
              <div className="contact-info-cards">
                <div className="contact-info-card">
                  <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                    <div className="rel-icon" style={{ width: 38, height: 38, borderRadius: 10, fontSize: 14 }}>&#9670;</div>
                    <div>
                      <h4>Islamabad Office</h4>
                      <p>CZAAH Capital &amp; Ventures<br />Emirates Tower, F-7 Markaz<br />Islamabad, Pakistan</p>
                    </div>
                  </div>
                </div>
                <div className="contact-info-card">
                  <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                    <div className="rel-icon" style={{ width: 38, height: 38, borderRadius: 10, fontSize: 14 }}>&#9632;</div>
                    <div>
                      <h4>International Enquiries</h4>
                      <p>For international investment enquiries<br />and cross-border partnerships</p>
                    </div>
                  </div>
                </div>
                <div className="contact-info-card">
                  <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                    <div className="rel-icon" style={{ width: 38, height: 38, borderRadius: 10, fontSize: 14 }}>&#9733;</div>
                    <div>
                      <h4>London Office</h4>
                      <p>CZAAH International<br />Berkeley Square, Mayfair, London, W1J 6BD</p>
                    </div>
                  </div>
                </div>
                <div className="contact-info-card">
                  <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                    <div className="rel-icon" style={{ width: 38, height: 38, borderRadius: 10, fontSize: 14 }}>&#8644;</div>
                    <div>
                      <h4>Email</h4>
                      <p><a href="mailto:info@czaah.com" style={{ color: 'var(--gold)', textDecoration: 'none' }}>info@czaah.com</a></p>
                    </div>
                  </div>
                </div>
                <div className="contact-info-card">
                  <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                    <div className="rel-icon" style={{ width: 38, height: 38, borderRadius: 10, fontSize: 14 }}>&#8644;</div>
                    <div>
                      <h4>WhatsApp</h4>
                      <p>Available on request</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* CONSULTATION CTA */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">Prefer a direct <span className="gold">conversation?</span></h2>
          <p className="subtitle" style={{ marginBottom: 32 }}>Our investment team is available for confidential discussions tailored to your objectives, timeline, and sector interests.</p>
          <a href="mailto:info@czaah.com" className="btn-gold">Request a Consultation &rarr;</a>
        </section>

        <Footer />
      </div>
    </>
  )
}
