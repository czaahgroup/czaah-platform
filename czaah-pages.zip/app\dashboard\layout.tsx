'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { NotificationBell } from '@/components/NotificationBell'

interface Profile {
  full_name: string
  role: string
  status: string
}

export default function MemberDashboardLayout({ children }: { children: React.ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const router = useRouter()
  const pathname = usePathname()
  const supabase = createClient()

  // Close sidebar on route change
  useEffect(() => {
    setSidebarOpen(false)
  }, [pathname])

  // Close sidebar on ESC key
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') setSidebarOpen(false)
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [])

  useEffect(() => {
    async function checkAuth() {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session?.user) {
        window.location.href = '/login'
        return
      }

      const { data: prof } = await supabase
        .from('profiles')
        .select('full_name, role, status')
        .eq('id', session.user.id)
        .single()

      if (!prof) { window.location.href = '/login'; return }
      if (prof.status !== 'approved') { window.location.href = '/pending'; return }

      setProfile(prof)
      setLoading(false)
    }
    checkAuth()

    // Listen for sign-out events
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        window.location.href = '/login'
      }
    })

    return () => subscription.unsubscribe()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000' }}>
        <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: 'rgba(255,255,255,0.4)' }}>Loading...</div>
      </div>
    )
  }

  if (!profile) return null

  const isElite = profile.role === 'elite_member' || profile.role === 'super_admin'
  const isRealEstatePartner = profile.role === 'real_estate_partner'

  // Grouped navigation sections
  const navSections: { label?: string; links: { href: string; label: string }[] }[] = [
    {
      links: [
        { href: '/dashboard', label: 'Overview' },
        { href: '/dashboard/membership-card', label: 'Membership Card' },
        { href: '/dashboard/notifications', label: 'Notifications' },
      ],
    },
    {
      label: 'Business',
      links: [
        { href: '/dashboard/enquiries', label: 'Enquiries' },
        { href: '/dashboard/investments', label: 'Investments' },
        { href: '/dashboard/meetings', label: 'Meetings' },
      ],
    },
    ...(isRealEstatePartner ? [{
      label: 'Properties',
      links: [
        { href: '/dashboard/properties', label: 'My Listings' },
        { href: '/dashboard/properties/new', label: 'Add Property' },
        { href: '/dashboard/property-chats', label: 'Property Chats' },
      ],
    }] : []),
    ...(isElite ? [{
      label: 'Elite',
      links: [
        { href: '/dashboard/live-chat', label: 'Live Chat' },
      ],
    }] : []),
    {
      label: 'Resources',
      links: [
        { href: '/dashboard/documents', label: 'Documents' },
        { href: '/dashboard/paperwork', label: 'Paperwork' },
        { href: '/dashboard/broadcasts', label: 'Broadcasts' },
        { href: '/dashboard/bookmarks', label: 'Bookmarks' },
      ],
    },
    {
      label: 'Account',
      links: [
        { href: '/dashboard/history', label: 'History' },
        { href: '/dashboard/settings', label: 'Settings' },
      ],
    },
  ]

  return (
    <div style={{ minHeight: '100vh', display: 'flex' }}>
      {/* Mobile backdrop */}
      {sidebarOpen && (
        <div
          className="dashboard-sidebar-backdrop"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`dashboard-sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        {/* Logo Area */}
        <div style={{
          padding: '28px 24px 22px',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
        }}>
          <Link href="/dashboard" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <svg viewBox="-5 -12 100 128" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ height: '32px', width: 'auto' }}>
              <defs>
                <linearGradient id="mbHornGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8a6f2e"/>
                  <stop offset="40%" stopColor="#c9a84c"/>
                  <stop offset="60%" stopColor="#e8c97a"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
                <linearGradient id="mbBodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#c9a84c"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
              </defs>
              <path d="M 38 38 C 34 30, 24 22, 20 12 C 17 4, 22 -2, 28 2 C 34 6, 36 16, 32 24 C 28 32, 22 34, 18 28 C 15 22, 18 14, 24 12" stroke="url(#mbHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 35 36 C 30 28, 22 20, 22 12 C 22 7, 26 4, 29 6" stroke="url(#mbHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 52 36 C 56 28, 66 20, 70 10 C 73 2, 68 -4, 62 0 C 56 4, 54 14, 58 22 C 62 30, 68 32, 72 26 C 75 20, 72 12, 66 10" stroke="url(#mbHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 55 34 C 60 26, 68 18, 68 10 C 68 5, 64 2, 61 4" stroke="url(#mbHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 34 38 C 32 42, 32 48, 36 52 L 38 58 C 40 64, 50 64, 52 58 L 54 52 C 58 48, 58 42, 56 38 C 54 34, 50 32, 45 32 C 40 32, 36 34, 34 38 Z" fill="url(#mbBodyGrad)" opacity="0.9"/>
              <path d="M 42 64 C 41 70, 40 76, 41 82" stroke="url(#mbHornGrad)" strokeWidth="1" fill="none" strokeLinecap="round" opacity="0.5"/>
              <path d="M 45 65 C 45 72, 45 78, 45 84" stroke="url(#mbHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.55"/>
              <path d="M 48 64 C 49 70, 50 76, 49 82" stroke="url(#mbHornGrad)" strokeWidth="1" fill="none" strokeLinecap="round" opacity="0.5"/>
              <circle cx="41" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
              <circle cx="49" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
              <path d="M 38 58 C 36 66, 35 76, 38 86 C 40 90, 50 90, 52 86 C 55 76, 54 66, 52 58" fill="url(#mbBodyGrad)" opacity="0.5"/>
              <line x1="35" y1="108" x2="55" y2="108" stroke="url(#mbHornGrad)" strokeWidth="1.5" opacity="0.7"/>
            </svg>
            <div>
              <span style={{
                fontFamily: "'Cinzel', serif",
                fontWeight: 600,
                fontSize: '18px',
                letterSpacing: '6px',
                color: 'transparent',
                background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 30%, #e8c97a 50%, #c9a84c 70%, #8a6f2e 100%)',
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                lineHeight: 1,
                display: 'block',
              }}>CZAAH</span>
              <span style={{
                fontFamily: "'Raleway', sans-serif",
                fontSize: '10px',
                letterSpacing: '3px',
                textTransform: 'uppercase' as const,
                color: 'rgba(201,168,76,0.4)',
                marginTop: '4px',
                display: 'block',
              }}>Member Portal</span>
            </div>
          </Link>
        </div>

        {/* Navigation */}
        <div style={{ flex: 1, padding: '16px 12px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1px' }}>
          {navSections.map((section, sIdx) => (
            <div key={sIdx}>
              {section.label && (
                <div style={{
                  paddingTop: sIdx === 0 ? '0' : '16px',
                  paddingBottom: '6px',
                  paddingLeft: '16px',
                }}>
                  <p style={{
                    fontFamily: "'Cinzel', serif",
                    fontSize: '10px',
                    letterSpacing: '3px',
                    textTransform: 'uppercase' as const,
                    color: 'rgba(255,255,255,0.2)',
                    margin: 0,
                  }}>{section.label}</p>
                </div>
              )}
              {section.links.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="member-nav-link"
                  onClick={() => setSidebarOpen(false)}
                  style={{
                    borderLeftColor: pathname === link.href ? 'rgba(201,168,76,0.6)' : undefined,
                    color: pathname === link.href ? '#fff' : undefined,
                    background: pathname === link.href ? 'rgba(255,255,255,0.02)' : undefined,
                  }}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{
          padding: '16px 20px',
          borderTop: '1px solid rgba(255,255,255,0.06)',
          display: 'flex',
          flexDirection: 'column',
          gap: '10px',
        }}>
          <Link
            href="/"
            style={{
              fontFamily: "'Raleway', sans-serif",
              fontSize: '11px',
              letterSpacing: '1.5px',
              color: 'rgba(255,255,255,0.35)',
              textDecoration: 'none',
              transition: 'color 0.3s ease',
              textTransform: 'uppercase' as const,
            }}
            className="member-footer-link"
          >
            &larr; View Main Site
          </Link>
          <Link
            href="/dashboard/enquiries/new"
            style={{
              fontFamily: "'Raleway', sans-serif",
              fontSize: '11px',
              letterSpacing: '1.5px',
              color: 'rgba(201,168,76,0.5)',
              textDecoration: 'none',
              transition: 'color 0.3s ease',
              textTransform: 'uppercase' as const,
            }}
            className="member-footer-link"
          >
            + New Enquiry
          </Link>
          <p style={{
            fontFamily: "'Raleway', sans-serif",
            fontSize: '12px',
            color: 'rgba(255,255,255,0.3)',
            margin: 0,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>{profile.full_name}</p>
          <form action="/api/auth/signout" method="POST">
            <button
              type="submit"
              className="member-signout-btn"
              style={{
                background: 'none',
                border: 'none',
                padding: 0,
                cursor: 'pointer',
                fontFamily: "'Raleway', sans-serif",
                fontSize: '11px',
                letterSpacing: '1px',
                color: 'rgba(201,168,76,0.5)',
                transition: 'color 0.3s ease',
              }}
            >
              Sign Out
            </button>
          </form>
        </div>
      </aside>

      {/* Main Content */}
      <main style={{
        flex: 1,
        overflow: 'auto',
        background: '#000000',
        display: 'flex',
        flexDirection: 'column',
        minWidth: 0,
      }}>
        {/* Top bar with notification bell */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          padding: '12px 40px 0',
          gap: '12px',
        }}
        className="dashboard-topbar"
        >
          <button
            className="hamburger-btn"
            onClick={() => setSidebarOpen(true)}
            style={{
              display: 'none',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '4px',
              marginRight: 'auto',
            }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="2">
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>
          <span style={{
            fontFamily: "'Raleway', sans-serif",
            fontSize: '12px',
            color: 'rgba(255,255,255,0.3)',
          }}>{profile.full_name}</span>
          <NotificationBell />
        </div>
        <div className="dashboard-content" style={{ padding: '24px 40px 40px', flex: 1 }}>{children}</div>
      </main>

      {/* Hover styles */}
      <style>{`
        .dashboard-sidebar {
          width: 260px;
          background: #080808;
          border-right: 1px solid rgba(255,255,255,0.06);
          display: flex;
          flex-direction: column;
          flex-shrink: 0;
        }
        .member-nav-link {
          display: flex;
          align-items: center;
          padding: 10px 16px;
          font-family: 'Raleway', sans-serif;
          font-size: 13px;
          color: rgba(255,255,255,0.5);
          text-decoration: none;
          border-left: 2px solid transparent;
          border-radius: 0 4px 4px 0;
          transition: all 0.25s ease;
          letter-spacing: 0.5px;
        }
        .member-nav-link:hover {
          color: #fff;
          border-left-color: rgba(201,168,76,0.3);
          background: rgba(255,255,255,0.02);
        }
        .member-footer-link:hover {
          color: rgba(255,255,255,0.7) !important;
        }
        .member-signout-btn:hover {
          color: rgba(201,168,76,1) !important;
        }
        @media (max-width: 767px) {
          .dashboard-sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            z-index: 50;
            transition: left 0.3s ease;
          }
          .dashboard-sidebar.closed {
            left: -260px;
          }
          .dashboard-sidebar.open {
            left: 0;
          }
          .dashboard-sidebar-backdrop {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            z-index: 49;
          }
          .hamburger-btn {
            display: flex !important;
          }
          .dashboard-content {
            padding: 16px !important;
          }
          .dashboard-topbar {
            padding: 12px 16px 0 !important;
          }
        }
        @media (min-width: 768px) {
          .dashboard-sidebar {
            position: relative;
          }
          .dashboard-sidebar-backdrop {
            display: none;
          }
          .hamburger-btn {
            display: none !important;
          }
        }
      `}</style>
    </div>
  )
}
