import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

export default function PrivacyPage() {
  return (
    <>
      <Navbar />

      <main className="legal-page fade-in">
        <h1>Privacy Policy</h1>
        <span className="legal-date">Last updated: March 2026</span>

        <h2>1. Introduction</h2>
        <p>CZAAH Capital &amp; Ventures (Private) Limited (&quot;CZAAH&quot;), registered with the Securities and Exchange Commission of Pakistan (SECP), together with its affiliated entities (collectively referred to as &quot;CZAAH&quot;, &quot;we&quot;, &quot;us&quot;, or &quot;our&quot;), is committed to protecting the privacy and security of your personal information.</p>
        <p>This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website, engage with our services, or otherwise interact with our business operations. By accessing or using our services, you acknowledge that you have read and understood this Privacy Policy.</p>

        <h2>2. Information We Collect</h2>
        <p>We may collect information about you in a variety of ways, including:</p>
        <p><strong>Information You Provide Directly</strong></p>
        <ul>
          <li>Full name, title, and professional designation</li>
          <li>Contact details including email address, telephone number, and business address</li>
          <li>Company name, registration details, and business information</li>
          <li>Financial information necessary for investment facilitation and due diligence</li>
          <li>Identity verification documents as required by applicable anti-money laundering (AML) and know-your-customer (KYC) regulations</li>
          <li>Correspondence and communications you send to us</li>
        </ul>
        <p><strong>Information Collected Automatically</strong></p>
        <ul>
          <li>IP address, browser type, and operating system</li>
          <li>Pages visited, time spent on pages, and navigation patterns</li>
          <li>Referring website addresses</li>
          <li>Device identifiers and technical information</li>
        </ul>

        <h2>3. How We Use Your Information</h2>
        <p>We use the information we collect for the following purposes:</p>
        <ul>
          <li>To provide, operate, and maintain our investment facilitation, advisory, and consulting services</li>
          <li>To process and manage investment inquiries and client relationships</li>
          <li>To conduct due diligence, KYC, and AML checks as required by law</li>
          <li>To communicate with you regarding our services, updates, and opportunities</li>
          <li>To comply with legal obligations, regulatory requirements, and industry standards</li>
          <li>To improve our website, services, and client experience</li>
          <li>To protect our rights, property, and the safety of our clients and stakeholders</li>
          <li>To send you marketing communications, where you have provided consent or where we have a legitimate interest to do so</li>
        </ul>

        <h2>4. Information Sharing</h2>
        <p>We do not sell, trade, or rent your personal information to third parties. We may share your information in the following circumstances:</p>
        <ul>
          <li><strong>Between CZAAH Entities:</strong> Information may be shared between CZAAH entities for operational purposes and to provide you with seamless service.</li>
          <li><strong>Service Providers:</strong> We may share information with trusted third-party service providers who assist us in operating our business, including legal advisors, auditors, IT service providers, and compliance consultants, subject to appropriate confidentiality agreements.</li>
          <li><strong>Legal Requirements:</strong> We may disclose your information when required by law, regulation, or legal process, including requests from the SECP or other regulatory bodies.</li>
          <li><strong>Business Transactions:</strong> In the event of a merger, acquisition, reorganisation, or sale of assets, your information may be transferred as part of that transaction.</li>
          <li><strong>With Your Consent:</strong> We may share your information with third parties when you have given us explicit consent to do so.</li>
        </ul>

        <h2>5. Data Security</h2>
        <p>We implement appropriate technical and organisational measures to protect your personal information against unauthorised access, alteration, disclosure, or destruction. These measures include encryption of data in transit, secure storage systems, access controls, and regular security assessments.</p>
        <p>While we strive to protect your personal information, no method of transmission over the internet or electronic storage is completely secure. We cannot guarantee absolute security but are committed to maintaining industry-standard protections.</p>

        <h2>6. International Data Transfers</h2>
        <p>As CZAAH operates across multiple jurisdictions, your personal information may be transferred between our entities for operational and service delivery purposes.</p>
        <ul>
          <li>CZAAH Capital &amp; Ventures (Private) Limited processes data in accordance with the laws of the Islamic Republic of Pakistan, including applicable data protection provisions.</li>
        </ul>
        <p>When transferring data between jurisdictions, we ensure that appropriate safeguards are in place to protect your information in compliance with the applicable legal requirements of each jurisdiction.</p>

        <h2>7. Your Rights</h2>
        <p>Depending on your jurisdiction, you may have the following rights regarding your personal information:</p>
        <ul>
          <li>The right to access the personal information we hold about you</li>
          <li>The right to request correction of inaccurate or incomplete information</li>
          <li>The right to request deletion of your personal information, subject to legal and regulatory obligations</li>
          <li>The right to withdraw consent for marketing communications at any time</li>
          <li>The right to object to or restrict certain processing activities</li>
          <li>The right to data portability, where technically feasible</li>
        </ul>
        <p>To exercise any of these rights, please contact us using the details provided in Section 10 below.</p>

        <h2>8. Cookies</h2>
        <p>Our website may use cookies and similar tracking technologies to enhance your browsing experience. Cookies are small data files stored on your device that help us understand how you interact with our website.</p>
        <p>We may use the following types of cookies:</p>
        <ul>
          <li><strong>Essential Cookies:</strong> Required for the basic functionality of our website.</li>
          <li><strong>Analytics Cookies:</strong> Help us understand how visitors interact with our website, allowing us to improve its performance and content.</li>
          <li><strong>Preference Cookies:</strong> Allow our website to remember choices you have made, such as language or region preferences.</li>
        </ul>
        <p>You can control cookie settings through your browser preferences. Disabling certain cookies may affect the functionality of our website.</p>

        <h2>9. Changes to This Policy</h2>
        <p>We reserve the right to update or modify this Privacy Policy at any time. When we make changes, we will update the &quot;Last updated&quot; date at the top of this page. We encourage you to review this Privacy Policy periodically to stay informed about how we are protecting your information.</p>
        <p>Material changes to this Privacy Policy will be communicated through a notice on our website or, where appropriate, by direct communication to affected individuals.</p>

        <h2>10. Contact Us</h2>
        <p>If you have questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact us:</p>
        <p>
          <strong>Email:</strong> <a href="mailto:info@czaah.com" className="text-czaah-gold">info@czaah.com</a><br />
          <strong>CZAAH Capital &amp; Ventures (Private) Limited</strong><br />
          Islamabad, Pakistan
        </p>
      </main>

      <Footer />
    </>
  )
}
