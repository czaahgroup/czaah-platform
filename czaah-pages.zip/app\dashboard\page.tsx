'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

interface Profile {
  id: string
  full_name: string
  email: string
  role: string
  status: string
  company_name: string | null
}

interface Enquiry {
  id: string
  reference_number: string
  product_name: string | null
  status: string
  created_at: string
  member_id: string
  assigned_admin_id: string | null
}

export default function DashboardPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [enquiries, setEnquiries] = useState<Enquiry[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/login'); return }

      const { data: prof } = await supabase
        .from('profiles')
        .select('id, full_name, email, role, status, company_name')
        .eq('id', user.id)
        .single()

      if (!prof) { router.push('/pending'); return }
      setProfile(prof)

      // Load enquiries — use API route which handles role-based filtering
      const res = await fetch('/api/enquiries')
      if (res.ok) {
        const json = await res.json()
        setEnquiries((json.data || []).slice(0, 10))
      }

      setLoading(false)
    }
    load()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) {
    return (
      <>
        <style>{`
          @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
          }
          .dash-loader {
            display: flex; align-items: center; justify-content: center; padding: 80px 0;
          }
          .dash-loader-inner {
            width: 48px; height: 48px; border-radius: 50%;
            border: 2px solid rgba(201,168,76,0.1);
            border-top-color: #C9A84C;
            animation: spin 0.8s linear infinite;
          }
          @keyframes spin { to { transform: rotate(360deg); } }
        `}</style>
        <div className="dash-loader">
          <div className="dash-loader-inner" />
        </div>
      </>
    )
  }

  if (!profile) return null

  const firstName = profile.full_name.split(' ')[0]
  const now = new Date()
  const dateStr = now.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

  const activeEnquiries = enquiries.filter(e => ['submitted', 'assigned', 'active', 'waiting'].includes(e.status))
  const resolvedEnquiries = enquiries.filter(e => e.status === 'resolved')
  const isAdmin = profile.role === 'admin' || profile.role === 'super_admin'
  const assignedEnquiries = isAdmin ? enquiries.filter(e => e.assigned_admin_id === profile.id && e.member_id !== profile.id) : []
  const myEnquiries = isAdmin ? enquiries.filter(e => e.member_id === profile.id) : enquiries

  const tierLabel = profile.role === 'super_admin' ? 'SUPER ADMIN' : profile.role === 'admin' ? 'ADMIN' : 'MEMBER'

  const statusConfig: Record<string, { bg: string; color: string; glow: string }> = {
    submitted: { bg: 'rgba(201,168,76,0.12)', color: '#C9A84C', glow: 'rgba(201,168,76,0.15)' },
    assigned: { bg: 'rgba(107,138,224,0.12)', color: '#6B8AE0', glow: 'rgba(107,138,224,0.15)' },
    active: { bg: 'rgba(34,197,94,0.12)', color: '#22c55e', glow: 'rgba(34,197,94,0.15)' },
    waiting: { bg: 'rgba(234,179,8,0.12)', color: '#eab308', glow: 'rgba(234,179,8,0.15)' },
    resolved: { bg: 'rgba(158,158,158,0.12)', color: '#9E9E9E', glow: 'rgba(158,158,158,0.1)' },
    archived: { bg: 'rgba(100,100,100,0.12)', color: '#666', glow: 'rgba(100,100,100,0.1)' },
  }

  // Build recent activity from enquiries
  const recentActivity = [...enquiries]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 5)

  function timeAgo(dateStr: string) {
    const diff = Date.now() - new Date(dateStr).getTime()
    const mins = Math.floor(diff / 60000)
    if (mins < 60) return `${mins}m ago`
    const hrs = Math.floor(mins / 60)
    if (hrs < 24) return `${hrs}h ago`
    const days = Math.floor(hrs / 24)
    return `${days}d ago`
  }

  return (
    <>
      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes glowPulse {
          0%, 100% { box-shadow: 0 0 8px rgba(201,168,76,0.15); }
          50% { box-shadow: 0 0 16px rgba(201,168,76,0.3); }
        }
        @keyframes badgeGlow {
          0%, 100% { box-shadow: 0 0 6px rgba(201,168,76,0.2); }
          50% { box-shadow: 0 0 14px rgba(201,168,76,0.4); }
        }
        .dash-animate { opacity: 0; animation: fadeInUp 0.6s ease forwards; }
        .dash-animate-1 { animation-delay: 0.1s; }
        .dash-animate-2 { animation-delay: 0.2s; }
        .dash-animate-3 { animation-delay: 0.3s; }
        .dash-animate-4 { animation-delay: 0.4s; }
        .dash-animate-5 { animation-delay: 0.5s; }
        .dash-animate-6 { animation-delay: 0.6s; }
        .dash-stat-card {
          background: rgba(8,8,8,0.6);
          border: 1px solid rgba(201,168,76,0.08);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          border-radius: 12px;
          padding: 24px;
          position: relative;
          overflow: hidden;
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .dash-stat-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(201,168,76,0.15), transparent);
        }
        .dash-stat-card::after {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(201,168,76,0.03) 0%, transparent 50%);
          pointer-events: none;
        }
        .dash-stat-card:hover {
          border-color: rgba(201,168,76,0.2);
          transform: translateY(-2px);
          box-shadow: 0 8px 32px rgba(0,0,0,0.3), 0 0 0 1px rgba(201,168,76,0.08);
        }
        .dash-action-card {
          background: rgba(8,8,8,0.6);
          border: 1px solid rgba(201,168,76,0.08);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          border-radius: 12px;
          padding: 20px 24px;
          display: flex;
          align-items: center;
          gap: 16px;
          text-decoration: none;
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          position: relative;
          overflow: hidden;
          border-left: 3px solid rgba(201,168,76,0.3);
        }
        .dash-action-card:hover {
          border-color: rgba(201,168,76,0.2);
          border-left-color: #C9A84C;
          transform: translateY(-2px);
          box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }
        .dash-enquiry-card {
          display: block;
          background: rgba(8,8,8,0.6);
          border: 1px solid rgba(201,168,76,0.06);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          border-radius: 10px;
          padding: 20px 24px;
          text-decoration: none;
          transition: all 0.3s ease;
        }
        .dash-enquiry-card:hover {
          border-color: rgba(201,168,76,0.2);
          box-shadow: 0 0 20px rgba(201,168,76,0.06);
          transform: translateY(-1px);
        }
        .dash-activity-item {
          display: flex;
          gap: 16px;
          padding: 16px 0;
          border-bottom: 1px solid rgba(255,255,255,0.04);
        }
        .dash-activity-item:last-child { border-bottom: none; }
        .dash-bg-pattern {
          position: fixed;
          inset: 0;
          pointer-events: none;
          z-index: 0;
          background-image:
            linear-gradient(rgba(201,168,76,0.02) 1px, transparent 1px),
            linear-gradient(90deg, rgba(201,168,76,0.02) 1px, transparent 1px);
          background-size: 60px 60px;
          mask-image: radial-gradient(ellipse at center, black 30%, transparent 70%);
          -webkit-mask-image: radial-gradient(ellipse at center, black 30%, transparent 70%);
        }
        .dash-section-title {
          font-family: 'Cinzel', serif;
          font-size: 18px;
          color: #fff;
          letter-spacing: 1px;
          margin: 0;
        }
        .dash-sparkline {
          display: flex;
          align-items: flex-end;
          gap: 2px;
          height: 24px;
        }
        .dash-sparkline-bar {
          width: 3px;
          border-radius: 1px;
          background: rgba(201,168,76,0.3);
          transition: height 0.3s ease;
        }
      `}</style>

      <div className="dash-bg-pattern" />

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Welcome Section */}
        <div className="dash-animate dash-animate-1" style={{ marginBottom: '40px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '8px', flexWrap: 'wrap' }}>
            <h1 style={{
              fontFamily: "'Cinzel', serif",
              fontSize: '32px',
              color: '#fff',
              margin: 0,
              fontWeight: 500,
              letterSpacing: '1px',
            }}>
              Welcome back, {firstName}
            </h1>
            <span style={{
              fontFamily: "'Raleway', sans-serif",
              fontSize: '11px',
              fontWeight: 600,
              letterSpacing: '2px',
              padding: '5px 16px',
              borderRadius: '20px',
              background: 'linear-gradient(135deg, rgba(201,168,76,0.15), rgba(201,168,76,0.05))',
              border: '1px solid rgba(201,168,76,0.25)',
              color: '#C9A84C',
              animation: 'badgeGlow 3s ease-in-out infinite',
            }}>
              {tierLabel}
            </span>
          </div>
          <p style={{
            fontFamily: "'Raleway', sans-serif",
            fontSize: '14px',
            color: 'rgba(255,255,255,0.4)',
            margin: 0,
          }}>
            {dateStr}
            {profile.company_name && <span style={{ color: 'rgba(201,168,76,0.5)', margin: '0 8px' }}>&middot;</span>}
            {profile.company_name && <span>{profile.company_name}</span>}
          </p>
        </div>

        {/* Stats Row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '40px' }}>
          <div className="dash-stat-card dash-animate dash-animate-1">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '1.5px', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', margin: '0 0 10px' }}>Active Enquiries</p>
                <p style={{ fontFamily: "'Cinzel', serif", fontSize: '32px', color: '#C9A84C', margin: 0, fontWeight: 600, lineHeight: 1 }}>
                  {activeEnquiries.length}
                </p>
              </div>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ opacity: 0.3 }}>
                <path d="M20 6L9 17l-5-5" stroke="#C9A84C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="dash-sparkline" style={{ marginTop: '12px' }}>
              {[3, 5, 4, 7, 6, 8, activeEnquiries.length].map((v, i) => (
                <div key={i} className="dash-sparkline-bar" style={{ height: `${Math.max((v / 10) * 24, 3)}px`, background: i === 6 ? '#C9A84C' : 'rgba(201,168,76,0.25)' }} />
              ))}
            </div>
          </div>

          <div className="dash-stat-card dash-animate dash-animate-2">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '1.5px', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', margin: '0 0 10px' }}>Resolved</p>
                <p style={{ fontFamily: "'Cinzel', serif", fontSize: '32px', color: '#fff', margin: 0, fontWeight: 600, lineHeight: 1 }}>
                  {resolvedEnquiries.length}
                </p>
              </div>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ opacity: 0.3 }}>
                <circle cx="12" cy="12" r="10" stroke="#22c55e" strokeWidth="2"/>
                <path d="M8 12l3 3 5-5" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="dash-sparkline" style={{ marginTop: '12px' }}>
              {[2, 3, 1, 4, 3, 5, resolvedEnquiries.length].map((v, i) => (
                <div key={i} className="dash-sparkline-bar" style={{ height: `${Math.max((v / 8) * 24, 3)}px`, background: i === 6 ? '#22c55e' : 'rgba(34,197,94,0.2)' }} />
              ))}
            </div>
          </div>

          <div className="dash-stat-card dash-animate dash-animate-3">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '1.5px', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', margin: '0 0 10px' }}>KYC Status</p>
                <p style={{ fontFamily: "'Cinzel', serif", fontSize: '24px', color: profile.status === 'approved' ? '#22c55e' : '#eab308', margin: 0, fontWeight: 600, lineHeight: 1, textTransform: 'capitalize' }}>
                  {profile.status === 'approved' ? 'Approved' : profile.status}
                </p>
              </div>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ opacity: 0.3 }}>
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke={profile.status === 'approved' ? '#22c55e' : '#eab308'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>

          <div className="dash-stat-card dash-animate dash-animate-4">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '1.5px', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', margin: '0 0 10px' }}>Total Enquiries</p>
                <p style={{ fontFamily: "'Cinzel', serif", fontSize: '32px', color: '#fff', margin: 0, fontWeight: 600, lineHeight: 1 }}>
                  {enquiries.length}
                </p>
              </div>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ opacity: 0.3 }}>
                <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke="#C9A84C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="dash-animate dash-animate-3" style={{ marginBottom: '40px' }}>
          <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: '18px', color: '#fff', letterSpacing: '1px', margin: '0 0 20px' }}>
            Quick Actions
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '12px' }}>
            <Link href="/dashboard/enquiries/new" className="dash-action-card">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="#C9A84C" strokeWidth="1.5"/>
                <path d="M12 8v8m-4-4h8" stroke="#C9A84C" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              <div>
                <div style={{ fontFamily: "'Cinzel', serif", fontSize: '14px', color: '#fff', marginBottom: '2px' }}>New Enquiry</div>
                <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.35)' }}>Submit a new request</div>
              </div>
            </Link>
            <Link href="/dashboard/investments" className="dash-action-card">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#C9A84C" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#C9A84C" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <div>
                <div style={{ fontFamily: "'Cinzel', serif", fontSize: '14px', color: '#fff', marginBottom: '2px' }}>Browse Investments</div>
                <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.35)' }}>Explore opportunities</div>
              </div>
            </Link>
            <Link href="/dashboard/documents" className="dash-action-card">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" stroke="#C9A84C" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" stroke="#C9A84C" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <div>
                <div style={{ fontFamily: "'Cinzel', serif", fontSize: '14px', color: '#fff', marginBottom: '2px' }}>View Documents</div>
                <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.35)' }}>Access your files</div>
              </div>
            </Link>
            <Link href="/dashboard/enquiries" className="dash-action-card">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2" stroke="#C9A84C" strokeWidth="1.5"/>
                <path d="M16 2v4M8 2v4M3 10h18" stroke="#C9A84C" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              <div>
                <div style={{ fontFamily: "'Cinzel', serif", fontSize: '14px', color: '#fff', marginBottom: '2px' }}>All Enquiries</div>
                <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.35)' }}>Track your activity</div>
              </div>
            </Link>
          </div>
        </div>

        {/* Recent Activity */}
        {recentActivity.length > 0 && (
          <div className="dash-animate dash-animate-4" style={{ marginBottom: '40px' }}>
            <h2 className="dash-section-title" style={{ marginBottom: '20px' }}>Recent Activity</h2>
            <div style={{
              background: 'rgba(8,8,8,0.6)',
              border: '1px solid rgba(201,168,76,0.08)',
              backdropFilter: 'blur(10px)',
              WebkitBackdropFilter: 'blur(10px)',
              borderRadius: '12px',
              padding: '8px 24px',
            }}>
              {recentActivity.map((item, idx) => (
                <div key={item.id} className="dash-activity-item" style={{ animationDelay: `${0.5 + idx * 0.1}s` }}>
                  <div style={{
                    width: '10px',
                    height: '10px',
                    borderRadius: '50%',
                    background: '#C9A84C',
                    marginTop: '5px',
                    flexShrink: 0,
                    boxShadow: '0 0 8px rgba(201,168,76,0.3)',
                  }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Link href={`/dashboard/enquiries/${item.id}`} style={{
                        fontFamily: "'Raleway', sans-serif",
                        fontSize: '14px',
                        color: '#fff',
                        textDecoration: 'none',
                      }}>
                        {item.product_name || 'General Enquiry'}
                      </Link>
                      <span style={{
                        fontFamily: "'Raleway', sans-serif",
                        fontSize: '11px',
                        color: 'rgba(255,255,255,0.25)',
                      }}>
                        {timeAgo(item.created_at)}
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px' }}>
                      <span style={{
                        fontFamily: "'Raleway', sans-serif",
                        fontSize: '11px',
                        color: 'rgba(255,255,255,0.3)',
                      }}>
                        {item.reference_number}
                      </span>
                      <span style={{
                        fontSize: '10px',
                        fontFamily: "'Raleway', sans-serif",
                        fontWeight: 600,
                        padding: '2px 8px',
                        borderRadius: '4px',
                        background: statusConfig[item.status]?.bg || 'rgba(100,100,100,0.12)',
                        color: statusConfig[item.status]?.color || '#666',
                        textTransform: 'capitalize',
                      }}>
                        {item.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Enquiry Lists */}
        {isAdmin ? (
          <>
            {/* Assigned Enquiries */}
            <div className="dash-animate dash-animate-5" style={{ marginBottom: '24px' }}>
              <h2 className="dash-section-title" style={{ marginBottom: '16px' }}>Assigned Enquiries</h2>
              {assignedEnquiries.length === 0 ? (
                <div style={{
                  background: 'rgba(8,8,8,0.6)',
                  border: '1px solid rgba(201,168,76,0.06)',
                  borderRadius: '12px',
                  padding: '48px 20px',
                  textAlign: 'center',
                  backdropFilter: 'blur(10px)',
                  WebkitBackdropFilter: 'blur(10px)',
                }}>
                  <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: 'rgba(255,255,255,0.35)', margin: 0 }}>
                    No enquiries assigned to you.
                  </p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {assignedEnquiries.map((enq) => (
                    <Link key={enq.id} href={`/dashboard/enquiries/${enq.id}`} className="dash-enquiry-card">
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span style={{
                            fontFamily: "'Courier New', monospace",
                            fontSize: '11px',
                            color: '#C9A84C',
                            background: 'rgba(201,168,76,0.1)',
                            padding: '3px 10px',
                            borderRadius: '4px',
                            letterSpacing: '0.5px',
                          }}>
                            {enq.reference_number}
                          </span>
                          <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: '#fff' }}>
                            {enq.product_name || 'General Enquiry'}
                          </span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span style={{
                            fontSize: '11px',
                            fontFamily: "'Raleway', sans-serif",
                            fontWeight: 600,
                            padding: '3px 12px',
                            borderRadius: '4px',
                            background: statusConfig[enq.status]?.bg || 'rgba(100,100,100,0.12)',
                            color: statusConfig[enq.status]?.color || '#666',
                            textTransform: 'capitalize',
                            boxShadow: `0 0 10px ${statusConfig[enq.status]?.glow || 'transparent'}`,
                          }}>
                            {enq.status}
                          </span>
                          <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.25)' }}>
                            {new Date(enq.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {/* My Enquiries */}
            <div className="dash-animate dash-animate-6">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                <h2 className="dash-section-title">My Enquiries</h2>
                <Link href="/dashboard/enquiries/new" style={{
                  fontFamily: "'Raleway', sans-serif",
                  fontSize: '12px',
                  color: '#C9A84C',
                  textDecoration: 'none',
                  transition: 'color 0.3s ease',
                }}>
                  New Enquiry &rarr;
                </Link>
              </div>
              {myEnquiries.length === 0 ? (
                <div style={{
                  background: 'rgba(8,8,8,0.6)',
                  border: '1px solid rgba(201,168,76,0.06)',
                  borderRadius: '12px',
                  padding: '48px 20px',
                  textAlign: 'center',
                  backdropFilter: 'blur(10px)',
                  WebkitBackdropFilter: 'blur(10px)',
                }}>
                  <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: 'rgba(255,255,255,0.35)', margin: '0 0 16px' }}>
                    You haven&apos;t submitted any enquiries yet.
                  </p>
                  <Link href="/dashboard/enquiries/new" style={{
                    display: 'inline-block',
                    background: 'linear-gradient(135deg, #8a6f2e 0%, #C9A84C 50%, #8a6f2e 100%)',
                    color: '#000',
                    fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600,
                    fontSize: '13px',
                    padding: '10px 24px',
                    borderRadius: '6px',
                    textDecoration: 'none',
                  }}>
                    Submit an Enquiry
                  </Link>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {myEnquiries.map((enq) => (
                    <Link key={enq.id} href={`/dashboard/enquiries/${enq.id}`} className="dash-enquiry-card">
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span style={{
                            fontFamily: "'Courier New', monospace",
                            fontSize: '11px',
                            color: '#C9A84C',
                            background: 'rgba(201,168,76,0.1)',
                            padding: '3px 10px',
                            borderRadius: '4px',
                            letterSpacing: '0.5px',
                          }}>
                            {enq.reference_number}
                          </span>
                          <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: '#fff' }}>
                            {enq.product_name || 'General Enquiry'}
                          </span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span style={{
                            fontSize: '11px',
                            fontFamily: "'Raleway', sans-serif",
                            fontWeight: 600,
                            padding: '3px 12px',
                            borderRadius: '4px',
                            background: statusConfig[enq.status]?.bg || 'rgba(100,100,100,0.12)',
                            color: statusConfig[enq.status]?.color || '#666',
                            textTransform: 'capitalize',
                            boxShadow: `0 0 10px ${statusConfig[enq.status]?.glow || 'transparent'}`,
                          }}>
                            {enq.status}
                          </span>
                          <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.25)' }}>
                            {new Date(enq.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </>
        ) : (
          /* Member view — single list */
          <div className="dash-animate dash-animate-5">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
              <h2 className="dash-section-title">My Enquiries</h2>
              <Link href="/dashboard/enquiries/new" style={{
                fontFamily: "'Raleway', sans-serif",
                fontSize: '12px',
                color: '#C9A84C',
                textDecoration: 'none',
              }}>
                New Enquiry &rarr;
              </Link>
            </div>
            {enquiries.length === 0 ? (
              <div style={{
                background: 'rgba(8,8,8,0.6)',
                border: '1px solid rgba(201,168,76,0.06)',
                borderRadius: '12px',
                padding: '64px 20px',
                textAlign: 'center',
                backdropFilter: 'blur(10px)',
                WebkitBackdropFilter: 'blur(10px)',
              }}>
                <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: 'rgba(255,255,255,0.35)', margin: '0 0 20px' }}>
                  No enquiries yet.
                </p>
                <Link href="/dashboard/enquiries/new" style={{
                  display: 'inline-block',
                  background: 'linear-gradient(135deg, #8a6f2e 0%, #C9A84C 50%, #8a6f2e 100%)',
                  color: '#000',
                  fontFamily: "'Raleway', sans-serif",
                  fontWeight: 600,
                  fontSize: '13px',
                  padding: '12px 28px',
                  borderRadius: '6px',
                  textDecoration: 'none',
                }}>
                  Submit Your First Enquiry
                </Link>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {enquiries.map((enq) => (
                  <Link key={enq.id} href={`/dashboard/enquiries/${enq.id}`} className="dash-enquiry-card">
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <span style={{
                          fontFamily: "'Courier New', monospace",
                          fontSize: '11px',
                          color: '#C9A84C',
                          background: 'rgba(201,168,76,0.1)',
                          padding: '3px 10px',
                          borderRadius: '4px',
                          letterSpacing: '0.5px',
                        }}>
                          {enq.reference_number}
                        </span>
                        <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: '#fff' }}>
                          {enq.product_name || 'General Enquiry'}
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <span style={{
                          fontSize: '11px',
                          fontFamily: "'Raleway', sans-serif",
                          fontWeight: 600,
                          padding: '3px 12px',
                          borderRadius: '4px',
                          background: statusConfig[enq.status]?.bg || 'rgba(100,100,100,0.12)',
                          color: statusConfig[enq.status]?.color || '#666',
                          textTransform: 'capitalize',
                          boxShadow: `0 0 10px ${statusConfig[enq.status]?.glow || 'transparent'}`,
                        }}>
                          {enq.status}
                        </span>
                        <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.25)' }}>
                          {new Date(enq.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </>
  )
}
