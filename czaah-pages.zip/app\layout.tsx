import type { Metadata, Viewport } from "next"
import { CookieConsent } from "@/components/CookieConsent"
import "./globals.css"

export const metadata: Metadata = {
  title: "CZAAH — Investing in Pakistan's Future",
  description:
    "CZAAH — Pakistan's institutional gateway for global capital. Investment facilitation across 13 sectors including minerals, real estate, technology, and textiles.",
  manifest: "/favicon/site.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "CZAAH",
  },
  openGraph: {
    title: "CZAAH — Capital · Ventures · Infrastructure",
    description:
      "Pakistan's institutional investment facilitation group. Connecting international capital with Pakistan's trillion-dollar resource base.",
    siteName: "CZAAH",
    type: "website",
    images: [{ url: "/favicon/czaah-shared.png" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "CZAAH — Capital · Ventures · Infrastructure",
    description:
      "Pakistan's institutional investment facilitation group.",
    images: ["/favicon/czaah-shared.png"],
  },
  icons: {
    icon: [
      { url: "/favicon/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon/favicon-96x96.png", sizes: "96x96", type: "image/png" },
    ],
    shortcut: "/favicon/favicon.ico",
    apple: "/favicon/apple-touch-icon.png",
  },
}

export const viewport: Viewport = {
  themeColor: "#000000",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400;1,500;1,600&family=Raleway:wght@200;300;400;500;600&display=swap"
          rel="stylesheet"
        />
        {/* PWA: Apple-specific */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="mobile-web-app-capable" content="yes" />
        {/* Splash screens for iOS */}
        <link rel="apple-touch-startup-image" href="/favicon/czaah-shared.png" />
      </head>
      <body>
        {children}
        <CookieConsent />
        {/* Register service worker */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', () => {
                  navigator.serviceWorker.register('/sw.js').catch(() => {});
                });
              }
            `,
          }}
        />
      </body>
    </html>
  )
}
