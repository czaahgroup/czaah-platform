'use client'

import { useState, Suspense } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'

export default function LoginPage() {
  return (
    <Suspense fallback={<div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000' }}><div style={{ color: 'rgba(255,255,255,0.3)', fontFamily: "'Raleway', sans-serif" }}>Loading...</div></div>}>
      <LoginForm />
    </Suspense>
  )
}

function LoginForm() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [forgotMode, setForgotMode] = useState(false)
  const [resetSent, setResetSent] = useState(false)
  const [mfaRequired, setMfaRequired] = useState(false)
  const [mfaFactorId, setMfaFactorId] = useState<string | null>(null)
  const [mfaCode, setMfaCode] = useState('')
  const router = useRouter()
  const searchParams = useSearchParams()
  const redirect = searchParams.get('redirect') || '/'

  function navigateByRole(profile: { role: string }) {
    if (redirect !== '/') {
      router.push(redirect)
    } else if (profile.role === 'super_admin') {
      router.push('/admin')
    } else if (profile.role === 'admin') {
      router.push('/dashboard')
    } else if (profile.role === 'member') {
      router.push('/dashboard')
    } else {
      router.push('/')
    }
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)

    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      setError(error.message)
      setLoading(false)
      return
    }

    // Check if MFA is required
    const { data: mfaData } = await supabase.auth.mfa.listFactors()
    const verifiedFactors = mfaData?.totp?.filter(f => f.status === 'verified') || []

    if (verifiedFactors.length > 0) {
      // MFA is enabled, show TOTP input
      setMfaFactorId(verifiedFactors[0].id)
      setMfaRequired(true)
      setLoading(false)
      return
    }

    // No MFA, proceed normally
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('role, status')
        .eq('id', user.id)
        .single()

      if (!profile || profile.status !== 'approved') {
        router.push('/pending')
        return
      }

      navigateByRole(profile)
    }
  }

  async function handleMfaVerify(e: React.FormEvent) {
    e.preventDefault()
    if (!mfaFactorId || !mfaCode) return
    setError('')
    setLoading(true)

    const supabase = createClient()

    const { error: verifyError } = await supabase.auth.mfa.challengeAndVerify({
      factorId: mfaFactorId,
      code: mfaCode,
    })

    if (verifyError) {
      setError(verifyError.message)
      setLoading(false)
      return
    }

    // MFA verified, check profile and redirect
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('role, status')
        .eq('id', user.id)
        .single()

      if (!profile || profile.status !== 'approved') {
        router.push('/pending')
        return
      }

      navigateByRole(profile)
    }
  }

  async function handleForgotPassword(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!email.trim()) {
      setError('Please enter your email address')
      return
    }
    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })
    if (error) {
      setError(error.message)
      setLoading(false)
      return
    }
    setResetSent(true)
    setLoading(false)
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 16px', background: '#000' }}>
      <div style={{ width: '100%', maxWidth: '28rem' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <Link href="/" style={{ textDecoration: 'none', display: 'inline-block' }}>
            <svg viewBox="-5 -12 100 80" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ height: '96px', width: 'auto', display: 'block', margin: '0 auto' }}>
              <defs>
                <linearGradient id="authHornGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8a6f2e"/>
                  <stop offset="40%" stopColor="#c9a84c"/>
                  <stop offset="60%" stopColor="#e8c97a"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
                <linearGradient id="authBodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#c9a84c"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
              </defs>
              <path d="M 38 38 C 34 30, 24 22, 20 12 C 17 4, 22 -2, 28 2 C 34 6, 36 16, 32 24 C 28 32, 22 34, 18 28 C 15 22, 18 14, 24 12" stroke="url(#authHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 35 36 C 30 28, 22 20, 22 12 C 22 7, 26 4, 29 6" stroke="url(#authHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 52 36 C 56 28, 66 20, 70 10 C 73 2, 68 -4, 62 0 C 56 4, 54 14, 58 22 C 62 30, 68 32, 72 26 C 75 20, 72 12, 66 10" stroke="url(#authHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 55 34 C 60 26, 68 18, 68 10 C 68 5, 64 2, 61 4" stroke="url(#authHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 34 38 C 32 42, 32 48, 36 52 L 38 58 C 40 64, 50 64, 52 58 L 54 52 C 58 48, 58 42, 56 38 C 54 34, 50 32, 45 32 C 40 32, 36 34, 34 38 Z" fill="url(#authBodyGrad)" opacity="0.9"/>
              <circle cx="41" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
              <circle cx="49" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
            </svg>
          </Link>
        </div>

        {/* Form */}
        <div style={{
          background: '#080808',
          border: '1px solid rgba(255,255,255,0.06)',
          borderRadius: '12px',
          padding: '40px',
        }}>
          {mfaRequired ? (
            // ── MFA Verification Mode ──
            <>
              <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                <div style={{
                  width: '64px', height: '64px', borderRadius: '50%',
                  border: '2px solid rgba(201,168,76,0.25)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  margin: '0 auto 20px',
                }}>
                  <svg style={{ width: '28px', height: '28px', color: '#C9A84C' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
                  </svg>
                </div>
                <h2 style={{
                  fontFamily: "'Cinzel', serif", fontSize: '20px',
                  color: '#fff', marginBottom: '8px',
                }}>Two-Factor Authentication</h2>
                <p style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '13px',
                  color: 'rgba(255,255,255,0.4)', lineHeight: 1.6,
                }}>Enter the 6-digit code from your authenticator app.</p>
              </div>

              <form onSubmit={handleMfaVerify} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <label style={{
                    display: 'block', fontFamily: "'Raleway', sans-serif",
                    fontSize: '12px', letterSpacing: '0.05em',
                    color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase',
                    marginBottom: '6px',
                  }}>Verification Code</label>
                  <input
                    type="text"
                    value={mfaCode}
                    onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    required
                    maxLength={6}
                    autoFocus
                    style={{
                      width: '100%', background: '#000',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '6px', padding: '14px 16px',
                      color: '#fff', fontFamily: "'Raleway', sans-serif",
                      fontSize: '24px', transition: 'border-color 0.3s',
                      outline: 'none', boxSizing: 'border-box',
                      textAlign: 'center', letterSpacing: '0.5em',
                    }}
                    onFocus={e => e.target.style.borderColor = '#C9A84C'}
                    onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.08)'}
                    placeholder="000000"
                  />
                </div>

                {error && (
                  <p style={{ color: '#ef4444', fontFamily: "'Raleway', sans-serif", fontSize: '12px', margin: 0 }}>{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading || mfaCode.length !== 6}
                  style={{
                    background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                    color: '#000', fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600, fontSize: '14px', letterSpacing: '0.1em',
                    textTransform: 'uppercase', padding: '14px',
                    borderRadius: '6px', border: 'none',
                    cursor: (loading || mfaCode.length !== 6) ? 'not-allowed' : 'pointer',
                    width: '100%', transition: 'opacity 0.3s',
                    opacity: (loading || mfaCode.length !== 6) ? 0.5 : 1,
                  }}
                >
                  {loading ? 'Verifying...' : 'Verify'}
                </button>
              </form>

              <div style={{ marginTop: '24px', textAlign: 'center' }}>
                <button
                  onClick={() => { setMfaRequired(false); setMfaCode(''); setMfaFactorId(null); setError('') }}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    fontFamily: "'Raleway', sans-serif", fontSize: '14px',
                    color: '#C9A84C', transition: 'opacity 0.3s',
                  }}
                >
                  Back to Sign In
                </button>
              </div>
            </>
          ) : forgotMode ? (
            // ── Forgot Password Mode ──
            resetSent ? (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: '64px', height: '64px', borderRadius: '50%',
                  border: '2px solid rgba(201,168,76,0.25)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  margin: '0 auto 24px',
                }}>
                  <svg style={{ width: '28px', height: '28px', color: '#C9A84C' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
                  </svg>
                </div>
                <h2 style={{
                  fontFamily: "'Cinzel', serif", fontSize: '20px',
                  color: '#fff', marginBottom: '12px',
                }}>Check Your Email</h2>
                <p style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '14px',
                  color: 'rgba(255,255,255,0.45)', lineHeight: 1.7,
                  marginBottom: '24px',
                }}>
                  We&apos;ve sent a password reset link to <strong style={{ color: '#C9A84C' }}>{email}</strong>. Please check your inbox and follow the instructions.
                </p>
                <button
                  onClick={() => { setForgotMode(false); setResetSent(false); setError('') }}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    fontFamily: "'Raleway', sans-serif", fontSize: '14px',
                    color: '#C9A84C', transition: 'opacity 0.3s',
                  }}
                >
                  Back to Sign In
                </button>
              </div>
            ) : (
              <>
                <h2 style={{
                  fontFamily: "'Cinzel', serif", fontSize: '20px',
                  marginBottom: '8px', textAlign: 'center', color: '#fff',
                }}>Reset Password</h2>
                <p style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '13px',
                  color: 'rgba(255,255,255,0.4)', textAlign: 'center',
                  marginBottom: '24px', lineHeight: 1.6,
                }}>Enter your email address and we&apos;ll send you a link to reset your password.</p>

                <form onSubmit={handleForgotPassword} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  <div>
                    <label style={{
                      display: 'block', fontFamily: "'Raleway', sans-serif",
                      fontSize: '12px', letterSpacing: '0.05em',
                      color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase',
                      marginBottom: '6px',
                    }}>Email</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      style={{
                        width: '100%', background: '#000',
                        border: '1px solid rgba(255,255,255,0.08)',
                        borderRadius: '6px', padding: '12px 16px',
                        color: '#fff', fontFamily: "'Raleway', sans-serif",
                        fontSize: '14px', transition: 'border-color 0.3s',
                        outline: 'none', boxSizing: 'border-box',
                      }}
                      onFocus={e => e.target.style.borderColor = '#C9A84C'}
                      onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.08)'}
                      placeholder="your@email.com"
                    />
                  </div>

                  {error && (
                    <p style={{ color: '#ef4444', fontFamily: "'Raleway', sans-serif", fontSize: '12px', margin: 0 }}>{error}</p>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    style={{
                      background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                      color: '#000', fontFamily: "'Raleway', sans-serif",
                      fontWeight: 600, fontSize: '14px', letterSpacing: '0.1em',
                      textTransform: 'uppercase', padding: '14px',
                      borderRadius: '6px', border: 'none',
                      cursor: loading ? 'not-allowed' : 'pointer',
                      width: '100%', transition: 'opacity 0.3s',
                      opacity: loading ? 0.5 : 1,
                    }}
                  >
                    {loading ? 'Sending...' : 'Send Reset Link'}
                  </button>
                </form>

                <div style={{ marginTop: '24px', textAlign: 'center' }}>
                  <button
                    onClick={() => { setForgotMode(false); setError('') }}
                    style={{
                      background: 'none', border: 'none', cursor: 'pointer',
                      fontFamily: "'Raleway', sans-serif", fontSize: '14px',
                      color: '#C9A84C', transition: 'opacity 0.3s',
                    }}
                  >
                    Back to Sign In
                  </button>
                </div>
              </>
            )
          ) : (
            // ── Sign In Mode ──
            <>
              <h2 style={{
                fontFamily: "'Cinzel', serif", fontSize: '20px',
                marginBottom: '24px', textAlign: 'center', color: '#fff',
              }}>Sign In</h2>

              <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <label style={{
                    display: 'block', fontFamily: "'Raleway', sans-serif",
                    fontSize: '12px', letterSpacing: '0.05em',
                    color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase',
                    marginBottom: '6px',
                  }}>Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    style={{
                      width: '100%', background: '#000',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '6px', padding: '12px 16px',
                      color: '#fff', fontFamily: "'Raleway', sans-serif",
                      fontSize: '14px', transition: 'border-color 0.3s',
                      outline: 'none', boxSizing: 'border-box',
                    }}
                    onFocus={e => e.target.style.borderColor = '#C9A84C'}
                    onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.08)'}
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                    <label style={{
                      fontFamily: "'Raleway', sans-serif",
                      fontSize: '12px', letterSpacing: '0.05em',
                      color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase',
                    }}>Password</label>
                    <button
                      type="button"
                      onClick={() => { setForgotMode(true); setError('') }}
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        fontFamily: "'Raleway', sans-serif", fontSize: '11px',
                        color: 'rgba(201,168,76,0.6)', transition: 'color 0.3s',
                      }}
                      onMouseEnter={e => e.currentTarget.style.color = '#C9A84C'}
                      onMouseLeave={e => e.currentTarget.style.color = 'rgba(201,168,76,0.6)'}
                    >
                      Forgot password?
                    </button>
                  </div>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    style={{
                      width: '100%', background: '#000',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '6px', padding: '12px 16px',
                      color: '#fff', fontFamily: "'Raleway', sans-serif",
                      fontSize: '14px', transition: 'border-color 0.3s',
                      outline: 'none', boxSizing: 'border-box',
                    }}
                    onFocus={e => e.target.style.borderColor = '#C9A84C'}
                    onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.08)'}
                    placeholder="••••••••"
                  />
                </div>

                {error && (
                  <p style={{ color: '#ef4444', fontFamily: "'Raleway', sans-serif", fontSize: '12px', margin: 0 }}>{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                    color: '#000', fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600, fontSize: '14px', letterSpacing: '0.1em',
                    textTransform: 'uppercase', padding: '14px',
                    borderRadius: '6px', border: 'none',
                    cursor: loading ? 'not-allowed' : 'pointer',
                    width: '100%', transition: 'opacity 0.3s',
                    opacity: loading ? 0.5 : 1,
                  }}
                >
                  {loading ? 'Signing in...' : 'Sign In'}
                </button>
              </form>

              <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '14px', color: 'rgba(255,255,255,0.4)', fontFamily: "'Raleway', sans-serif" }}>
                Don&apos;t have an account?{' '}
                <Link href="/register" style={{ color: '#C9A84C', fontFamily: "'Raleway', sans-serif", textDecoration: 'none' }}>
                  Become a Member
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
