'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'

interface Sector {
  id: string
  name: string
  slug: string
  description: string
  icon_url: string | null
  image_url: string | null
}

export default function SectorsPage() {
  const [sectors, setSectors] = useState<Sector[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchSectors() {
      try {
        const res = await fetch('/api/public/sectors')
        if (res.ok) {
          const data = await res.json()
          setSectors(data)
        }
      } catch (err) {
        console.error('Failed to fetch sectors:', err)
      } finally {
        setLoading(false)
      }
    }
    fetchSectors()
  }, [])

  return (
    <div className="min-h-screen bg-czaah-black">
      {/* Hero */}
      <section className="pt-32 pb-24 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-[family-name:var(--font-heading)] text-5xl md:text-6xl lg:text-7xl text-czaah-gold tracking-wide mb-8">
            Our Sectors.
          </h1>
          <p className="font-[family-name:var(--font-display)] italic text-xl md:text-2xl text-czaah-muted max-w-4xl leading-relaxed">
            CZAAH operates across 13 high-impact sectors spanning natural resources,
            infrastructure, technology, and institutional services — bridging
            international capital with Pakistan&apos;s most significant opportunities.
          </p>
        </div>
      </section>

      {/* Sectors Grid */}
      <section className="pb-24 px-6 border-t border-czaah-border">
        <div className="max-w-7xl mx-auto pt-16">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-czaah-card border border-czaah-border rounded-lg p-8 animate-pulse"
                >
                  <div className="h-6 bg-czaah-elevated rounded w-2/3 mb-4" />
                  <div className="h-4 bg-czaah-elevated rounded w-full mb-2" />
                  <div className="h-4 bg-czaah-elevated rounded w-4/5" />
                </div>
              ))}
            </div>
          ) : sectors.length === 0 ? (
            <div className="text-center py-20">
              <p className="font-[family-name:var(--font-body)] text-czaah-muted text-lg">
                No sectors available at this time.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {sectors.map((sector) => (
                <Link
                  key={sector.id}
                  href={`/sectors/${sector.slug}`}
                  className="group bg-czaah-card border border-czaah-border rounded-lg p-8 hover:border-czaah-gold/40 transition-all duration-300"
                >
                  <h3 className="font-[family-name:var(--font-heading)] text-lg text-czaah-gold mb-4 group-hover:text-czaah-gold-light transition-colors">
                    {sector.name}
                  </h3>
                  <p className="font-[family-name:var(--font-body)] text-czaah-muted text-sm leading-relaxed mb-6">
                    {sector.description}
                  </p>
                  <span className="font-[family-name:var(--font-body)] text-czaah-gold text-sm tracking-wide uppercase group-hover:translate-x-1 inline-block transition-transform">
                    Explore &rarr;
                  </span>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 border-t border-czaah-border">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="font-[family-name:var(--font-display)] italic text-3xl md:text-4xl text-czaah-white mb-8">
            Interested in a specific sector?
          </h2>
          <Link
            href="/contact"
            className="inline-block bg-czaah-gold text-czaah-black font-[family-name:var(--font-body)] font-semibold px-10 py-4 rounded hover:bg-czaah-gold-light transition-colors text-lg"
          >
            Get in Touch
          </Link>
        </div>
      </section>
    </div>
  )
}
