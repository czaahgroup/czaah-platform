'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter, useParams } from 'next/navigation'
import Link from 'next/link'
import { ChatPanel } from '@/components/chat/ChatPanel'
import { openFile } from '@/lib/utils/openFile'

interface Profile {
  id: string
  full_name: string
  role: string
}

interface Attachment {
  id: string
  file_url: string
  file_name: string
  uploaded_at: string
}

interface Enquiry {
  id: string
  reference_number: string
  product_name: string | null
  description: string | null
  estimated_quantity: string | null
  timeline: string | null
  additional_notes: string | null
  status: string
  sector_id: string | null
  service_id: string | null
  member_id: string
  assigned_admin_id: string | null
  created_at: string
  resolved_at: string | null
}

interface AdminProfile {
  id: string
  full_name: string
}

const STATUS_BADGES: Record<string, string> = {
  submitted: 'bg-yellow-500/20 text-yellow-400',
  assigned: 'bg-blue-500/20 text-blue-400',
  active: 'bg-green-500/20 text-green-400',
  waiting: 'bg-orange-500/20 text-orange-400',
  resolved: 'bg-neutral-500/20 text-neutral-400',
  archived: 'bg-neutral-500/20 text-neutral-400',
}

const TIMELINE_LABELS: Record<string, string> = {
  urgent: 'Urgent',
  '1_3_months': '1-3 Months',
  '3_6_months': '3-6 Months',
  '6_plus_months': '6+ Months',
  flexible: 'Flexible',
}

export default function EnquiryDetailPage() {
  const params = useParams()
  const enquiryId = params.id as string
  const [profile, setProfile] = useState<Profile | null>(null)
  const [enquiry, setEnquiry] = useState<Enquiry | null>(null)
  const [sectorName, setSectorName] = useState<string | null>(null)
  const [attachments, setAttachments] = useState<Attachment[]>([])
  const [assignedAdmin, setAssignedAdmin] = useState<AdminProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [resolving, setResolving] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function load() {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) { router.push('/login'); return }

        const { data: prof } = await supabase
          .from('profiles')
          .select('id, full_name, role')
          .eq('id', user.id)
          .single()

        if (!prof) { router.push('/login'); return }
        setProfile(prof)

        // Fetch enquiry
        const { data: enq, error: enqError } = await supabase
          .from('enquiries')
          .select('*')
          .eq('id', enquiryId)
          .single()

        if (enqError || !enq) {
          setError('Enquiry not found')
          setLoading(false)
          return
        }
        setEnquiry(enq)

        // Fetch sector name
        if (enq.sector_id) {
          const { data: sector } = await supabase
            .from('sectors')
            .select('name')
            .eq('id', enq.sector_id)
            .single()
          if (sector) setSectorName(sector.name)
        }

        // Fetch assigned admin name for voice calls
        if (enq.assigned_admin_id) {
          const { data: adminProf } = await supabase
            .from('profiles')
            .select('id, full_name')
            .eq('id', enq.assigned_admin_id)
            .single()
          if (adminProf) setAssignedAdmin(adminProf)
        }

        // Fetch attachments
        const { data: atts } = await supabase
          .from('enquiry_attachments')
          .select('id, file_url, file_name, uploaded_at')
          .eq('enquiry_id', enquiryId)
          .order('uploaded_at', { ascending: true })
        setAttachments(atts || [])
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Something went wrong')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [enquiryId]) // eslint-disable-line react-hooks/exhaustive-deps

  async function handleResolve() {
    if (!enquiry || resolving) return
    setResolving(true)
    const { error: updateError } = await supabase
      .from('enquiries')
      .update({ status: 'resolved', resolved_at: new Date().toISOString() })
      .eq('id', enquiry.id)

    if (!updateError) {
      setEnquiry({ ...enquiry, status: 'resolved', resolved_at: new Date().toISOString() })
    }
    setResolving(false)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-czaah-muted">Loading...</div>
      </div>
    )
  }

  if (error || !enquiry || !profile) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <p className="text-red-400 mb-4">{error || 'Enquiry not found'}</p>
          <Link href="/dashboard/enquiries" className="text-sm text-czaah-gold hover:underline">
            &larr; Back to Enquiries
          </Link>
        </div>
      </div>
    )
  }

  const canResolve = enquiry.status !== 'resolved' && enquiry.status !== 'archived'

  return (
    <>
      <Link
        href="/dashboard/enquiries"
        className="text-sm text-czaah-muted hover:text-czaah-gold transition-colors mb-6 inline-block"
      >
        &larr; Back to Enquiries
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left: Enquiry details */}
        <div className="lg:col-span-2">
          <div className="bg-czaah-card border border-czaah-border rounded-lg">
            <div className="px-6 py-4 border-b border-czaah-border">
              <div className="flex items-center justify-between mb-2">
                <h1 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
                  Enquiry Details
                </h1>
                <span className={`text-xs px-2 py-0.5 rounded ${STATUS_BADGES[enquiry.status] || ''}`}>
                  {enquiry.status}
                </span>
              </div>
              <p className="text-xs text-czaah-muted-dim">{enquiry.reference_number}</p>
            </div>

            <div className="px-6 py-4 space-y-4">
              <DetailRow label="Product" value={enquiry.product_name || 'N/A'} />
              {sectorName && <DetailRow label="Sector" value={sectorName} />}
              <DetailRow label="Description" value={enquiry.description || 'N/A'} />
              <DetailRow label="Quantity" value={enquiry.estimated_quantity || 'N/A'} />
              <DetailRow label="Timeline" value={TIMELINE_LABELS[enquiry.timeline || ''] || enquiry.timeline || 'N/A'} />
              {enquiry.additional_notes && (
                <DetailRow label="Notes" value={enquiry.additional_notes} />
              )}
              <DetailRow label="Created" value={new Date(enquiry.created_at).toLocaleDateString()} />
              {enquiry.resolved_at && (
                <DetailRow label="Resolved" value={new Date(enquiry.resolved_at).toLocaleDateString()} />
              )}

              {/* Attachments */}
              {attachments.length > 0 && (
                <div>
                  <p className="text-xs text-czaah-muted uppercase tracking-wider mb-2">Attachments</p>
                  <div className="space-y-1">
                    {attachments.map((att) => (
                      <button
                        key={att.id}
                        onClick={() => openFile(att.file_url)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
                        className="flex items-center gap-2 text-sm text-czaah-gold hover:underline"
                      >
                        <span className="truncate">{att.file_name}</span>
                        <span className="text-czaah-muted-dim shrink-0">&rarr;</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Resolve button */}
            {canResolve && (
              <div className="px-6 py-4 border-t border-czaah-border">
                <button
                  onClick={handleResolve}
                  disabled={resolving}
                  className="w-full bg-czaah-elevated border border-czaah-border text-czaah-muted hover:text-czaah-white hover:border-czaah-gold/30 font-semibold py-2.5 rounded text-sm transition-colors disabled:opacity-50"
                >
                  {resolving ? 'Resolving...' : 'Mark as Resolved'}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right: Chat panel */}
        <div className="lg:col-span-3">
          <div className="bg-czaah-card border border-czaah-border rounded-lg h-[600px] flex flex-col">
            <div className="px-6 py-3 border-b border-czaah-border">
              <h2 className="font-[family-name:var(--font-heading)] text-sm text-czaah-white">Chat</h2>
            </div>
            <div className="flex-1 min-h-0">
              <ChatPanel
                enquiryId={enquiryId}
                currentUserId={profile.id}
                currentUserName={profile.full_name}
                userRole={profile.role}
                enableCalls={!!assignedAdmin}
                targetUserId={assignedAdmin?.id}
                targetName={assignedAdmin?.full_name}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-czaah-muted uppercase tracking-wider mb-0.5">{label}</p>
      <p className="text-sm text-czaah-white whitespace-pre-wrap">{value}</p>
    </div>
  )
}
