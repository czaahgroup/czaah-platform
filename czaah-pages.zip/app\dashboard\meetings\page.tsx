'use client'

import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'

interface Participant {
  id: string
  user_id: string
  response: string
  profile: {
    id: string
    full_name: string
    email: string
    avatar_url: string | null
  } | null
}

interface Meeting {
  id: string
  title: string
  organizer_id: string
  scheduled_at: string
  duration_minutes: number
  meeting_type: string
  notes: string | null
  status: string
  created_at: string
  organizer: {
    id: string
    full_name: string
    email: string
    avatar_url: string | null
  } | null
  meeting_participants: Participant[]
}

interface MemberOption {
  id: string
  full_name: string
  email: string
}

const MEETING_TYPE_LABELS: Record<string, string> = {
  voice_call: 'Voice Call',
  video_call: 'Video Call',
  in_person: 'In Person',
}

const MEETING_TYPE_ICONS: Record<string, string> = {
  voice_call: 'tel',
  video_call: 'vid',
  in_person: 'loc',
}

const DURATION_OPTIONS = [
  { value: 15, label: '15 min' },
  { value: 30, label: '30 min' },
  { value: 45, label: '45 min' },
  { value: 60, label: '1 hour' },
]

export default function MeetingsPage() {
  const [meetings, setMeetings] = useState<Meeting[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [showPast, setShowPast] = useState(false)
  const [currentUserId, setCurrentUserId] = useState<string | null>(null)
  const [members, setMembers] = useState<MemberOption[]>([])
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  // Form state
  const [title, setTitle] = useState('')
  const [scheduledDate, setScheduledDate] = useState('')
  const [scheduledTime, setScheduledTime] = useState('')
  const [duration, setDuration] = useState(30)
  const [meetingType, setMeetingType] = useState('video_call')
  const [notes, setNotes] = useState('')
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([])

  const supabase = createClient()

  const loadMeetings = useCallback(async () => {
    const res = await fetch('/api/meetings')
    const result = await res.json()
    if (res.ok && result.data) {
      setMeetings(result.data)
    }
  }, [])

  useEffect(() => {
    async function init() {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        setCurrentUserId(user.id)
      }

      // Load members for participant selector
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .eq('status', 'approved')
        .order('full_name')

      if (profiles) {
        setMembers(profiles.filter(p => p.id !== user?.id))
      }

      await loadMeetings()
      setLoading(false)
    }
    init()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const now = new Date()
  const upcomingMeetings = meetings.filter(
    m => new Date(m.scheduled_at) >= now && m.status !== 'cancelled'
  )
  const pastMeetings = meetings.filter(
    m => new Date(m.scheduled_at) < now || m.status === 'cancelled'
  )

  async function handleCreateMeeting(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setSubmitting(true)

    const scheduledAt = new Date(`${scheduledDate}T${scheduledTime}`).toISOString()

    const res = await fetch('/api/meetings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        scheduledAt,
        durationMinutes: duration,
        meetingType,
        notes: notes || null,
        participantIds: selectedParticipants,
      }),
    })

    const result = await res.json()
    if (!res.ok) {
      setError(result.error || 'Failed to create meeting')
      setSubmitting(false)
      return
    }

    // Reset form
    setTitle('')
    setScheduledDate('')
    setScheduledTime('')
    setDuration(30)
    setMeetingType('video_call')
    setNotes('')
    setSelectedParticipants([])
    setShowModal(false)
    setSubmitting(false)

    await loadMeetings()
  }

  async function handleRespond(meetingId: string, response: string) {
    await fetch(`/api/meetings/${meetingId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ response }),
    })
    await loadMeetings()
  }

  async function handleCancel(meetingId: string) {
    await fetch(`/api/meetings/${meetingId}`, { method: 'DELETE' })
    await loadMeetings()
  }

  function toggleParticipant(id: string) {
    setSelectedParticipants(prev =>
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    )
  }

  function formatDateTime(iso: string) {
    const d = new Date(iso)
    return d.toLocaleDateString('en-GB', {
      weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
    }) + ' at ' + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
  }

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '80px 0' }}>
        <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: 'rgba(255,255,255,0.4)' }}>Loading...</div>
      </div>
    )
  }

  return (
    <>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
        <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: '24px', color: '#fff', margin: 0 }}>
          Meetings
        </h1>
        <button
          onClick={() => setShowModal(true)}
          style={{
            background: '#C9A84C', color: '#000', fontFamily: "'Raleway', sans-serif",
            fontWeight: 600, fontSize: '13px', padding: '10px 20px', borderRadius: '6px',
            border: 'none', cursor: 'pointer', transition: 'opacity 0.2s',
          }}
        >
          Schedule Meeting
        </button>
      </div>

      {/* Upcoming Meetings */}
      <div style={{ marginBottom: '40px' }}>
        <h2 style={{ fontFamily: "'Cinzel', serif", fontSize: '16px', color: '#C9A84C', marginBottom: '16px', letterSpacing: '1px' }}>
          Upcoming ({upcomingMeetings.length})
        </h2>

        {upcomingMeetings.length === 0 ? (
          <div style={{
            background: '#080808', border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: '8px', padding: '40px', textAlign: 'center',
          }}>
            <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: 'rgba(255,255,255,0.4)', margin: 0 }}>
              No upcoming meetings scheduled.
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {upcomingMeetings.map(meeting => (
              <MeetingCard
                key={meeting.id}
                meeting={meeting}
                currentUserId={currentUserId}
                onRespond={handleRespond}
                onCancel={handleCancel}
              />
            ))}
          </div>
        )}
      </div>

      {/* Past Meetings */}
      <div>
        <button
          onClick={() => setShowPast(!showPast)}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontFamily: "'Cinzel', serif", fontSize: '16px', color: 'rgba(255,255,255,0.4)',
            marginBottom: showPast ? '16px' : '0', display: 'flex', alignItems: 'center', gap: '8px',
            padding: 0, letterSpacing: '1px',
          }}
        >
          Past Meetings ({pastMeetings.length})
          <span style={{ fontSize: '12px', transition: 'transform 0.2s', transform: showPast ? 'rotate(180deg)' : 'rotate(0deg)' }}>
            &#9660;
          </span>
        </button>

        {showPast && pastMeetings.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '12px' }}>
            {pastMeetings.map(meeting => (
              <MeetingCard
                key={meeting.id}
                meeting={meeting}
                currentUserId={currentUserId}
                onRespond={handleRespond}
                onCancel={handleCancel}
                isPast
              />
            ))}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000,
          padding: '20px',
        }}>
          <div style={{
            background: '#080808', border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: '12px', width: '100%', maxWidth: '520px', maxHeight: '90vh',
            overflow: 'auto',
          }}>
            <div style={{
              padding: '20px 24px', borderBottom: '1px solid rgba(255,255,255,0.06)',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <h3 style={{ fontFamily: "'Cinzel', serif", fontSize: '18px', color: '#fff', margin: 0 }}>
                Schedule Meeting
              </h3>
              <button
                onClick={() => setShowModal(false)}
                style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.4)', cursor: 'pointer', fontSize: '20px' }}
              >
                x
              </button>
            </div>

            <form onSubmit={handleCreateMeeting} style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {/* Title */}
              <div>
                <label style={labelStyle}>Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  placeholder="Meeting title"
                  style={inputStyle}
                />
              </div>

              {/* Date & Time */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label style={labelStyle}>Date</label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    required
                    style={{ ...inputStyle, colorScheme: 'dark' }}
                  />
                </div>
                <div>
                  <label style={labelStyle}>Time</label>
                  <input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    required
                    style={{ ...inputStyle, colorScheme: 'dark' }}
                  />
                </div>
              </div>

              {/* Duration */}
              <div>
                <label style={labelStyle}>Duration</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  {DURATION_OPTIONS.map(opt => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setDuration(opt.value)}
                      style={{
                        flex: 1, padding: '8px 4px', borderRadius: '6px',
                        border: duration === opt.value ? '1px solid #C9A84C' : '1px solid rgba(255,255,255,0.06)',
                        background: duration === opt.value ? 'rgba(201,168,76,0.1)' : 'transparent',
                        color: duration === opt.value ? '#C9A84C' : 'rgba(255,255,255,0.5)',
                        fontFamily: "'Raleway', sans-serif", fontSize: '13px',
                        cursor: 'pointer', transition: 'all 0.2s',
                      }}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Type */}
              <div>
                <label style={labelStyle}>Meeting Type</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  {Object.entries(MEETING_TYPE_LABELS).map(([key, label]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setMeetingType(key)}
                      style={{
                        flex: 1, padding: '8px 4px', borderRadius: '6px',
                        border: meetingType === key ? '1px solid #C9A84C' : '1px solid rgba(255,255,255,0.06)',
                        background: meetingType === key ? 'rgba(201,168,76,0.1)' : 'transparent',
                        color: meetingType === key ? '#C9A84C' : 'rgba(255,255,255,0.5)',
                        fontFamily: "'Raleway', sans-serif", fontSize: '12px',
                        cursor: 'pointer', transition: 'all 0.2s',
                      }}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label style={labelStyle}>Notes (optional)</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="Add notes or agenda..."
                  style={{ ...inputStyle, resize: 'none' }}
                />
              </div>

              {/* Participants */}
              <div>
                <label style={labelStyle}>Participants</label>
                <div style={{
                  maxHeight: '160px', overflow: 'auto', border: '1px solid rgba(255,255,255,0.06)',
                  borderRadius: '6px', background: '#000',
                }}>
                  {members.length === 0 ? (
                    <div style={{ padding: '12px 16px', color: 'rgba(255,255,255,0.3)', fontSize: '13px', fontFamily: "'Raleway', sans-serif" }}>
                      No members found.
                    </div>
                  ) : (
                    members.map(member => (
                      <label
                        key={member.id}
                        style={{
                          display: 'flex', alignItems: 'center', gap: '10px',
                          padding: '8px 16px', cursor: 'pointer', transition: 'background 0.15s',
                          background: selectedParticipants.includes(member.id) ? 'rgba(201,168,76,0.05)' : 'transparent',
                          borderBottom: '1px solid rgba(255,255,255,0.03)',
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={selectedParticipants.includes(member.id)}
                          onChange={() => toggleParticipant(member.id)}
                          style={{ accentColor: '#C9A84C' }}
                        />
                        <div>
                          <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '13px', color: '#fff' }}>
                            {member.full_name}
                          </div>
                          <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '11px', color: 'rgba(255,255,255,0.3)' }}>
                            {member.email}
                          </div>
                        </div>
                      </label>
                    ))
                  )}
                </div>
                {selectedParticipants.length > 0 && (
                  <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '11px', color: 'rgba(201,168,76,0.6)', marginTop: '6px' }}>
                    {selectedParticipants.length} participant{selectedParticipants.length !== 1 ? 's' : ''} selected
                  </p>
                )}
              </div>

              {error && (
                <p style={{ color: '#ef4444', fontFamily: "'Raleway', sans-serif", fontSize: '12px', margin: 0 }}>{error}</p>
              )}

              <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
                <button
                  type="submit"
                  disabled={submitting}
                  style={{
                    flex: 1, background: '#C9A84C', color: '#000', fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600, fontSize: '14px', padding: '12px', borderRadius: '6px',
                    border: 'none', cursor: submitting ? 'not-allowed' : 'pointer',
                    opacity: submitting ? 0.5 : 1, transition: 'opacity 0.2s',
                  }}
                >
                  {submitting ? 'Creating...' : 'Schedule Meeting'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  style={{
                    padding: '12px 20px', borderRadius: '6px',
                    border: '1px solid rgba(255,255,255,0.06)', background: 'transparent',
                    color: 'rgba(255,255,255,0.5)', fontFamily: "'Raleway', sans-serif",
                    fontSize: '14px', cursor: 'pointer', transition: 'color 0.2s',
                  }}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}

// ── Meeting Card ──

function MeetingCard({
  meeting, currentUserId, onRespond, onCancel, isPast,
}: {
  meeting: Meeting
  currentUserId: string | null
  onRespond: (id: string, response: string) => void
  onCancel: (id: string) => void
  isPast?: boolean
}) {
  const isOrganizer = meeting.organizer_id === currentUserId
  const myParticipation = meeting.meeting_participants?.find(p => p.user_id === currentUserId)
  const isPending = myParticipation?.response === 'pending'

  return (
    <div style={{
      background: '#080808', border: '1px solid rgba(255,255,255,0.06)',
      borderRadius: '8px', padding: '20px', opacity: isPast ? 0.6 : 1,
      transition: 'border-color 0.2s',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
        <div>
          <h3 style={{ fontFamily: "'Raleway', sans-serif", fontSize: '16px', color: '#fff', margin: '0 0 4px 0', fontWeight: 600 }}>
            {meeting.title}
          </h3>
          <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '13px', color: 'rgba(255,255,255,0.5)', margin: 0 }}>
            {formatDateTimeStatic(meeting.scheduled_at)} -- {meeting.duration_minutes} min
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{
            fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '0.5px',
            padding: '4px 10px', borderRadius: '4px',
            background: meeting.status === 'cancelled' ? 'rgba(239,68,68,0.1)' : 'rgba(201,168,76,0.1)',
            color: meeting.status === 'cancelled' ? '#ef4444' : '#C9A84C',
            border: meeting.status === 'cancelled' ? '1px solid rgba(239,68,68,0.2)' : '1px solid rgba(201,168,76,0.2)',
            textTransform: 'uppercase',
          }}>
            {MEETING_TYPE_ICONS[meeting.meeting_type] || ''} {MEETING_TYPE_LABELS[meeting.meeting_type] || meeting.meeting_type}
          </span>
          {meeting.status === 'cancelled' && (
            <span style={{
              fontFamily: "'Raleway', sans-serif", fontSize: '11px',
              padding: '4px 10px', borderRadius: '4px',
              background: 'rgba(239,68,68,0.1)', color: '#ef4444',
              border: '1px solid rgba(239,68,68,0.2)', textTransform: 'uppercase',
            }}>
              Cancelled
            </span>
          )}
        </div>
      </div>

      {meeting.notes && (
        <p style={{
          fontFamily: "'Raleway', sans-serif", fontSize: '13px', color: 'rgba(255,255,255,0.35)',
          margin: '0 0 12px 0', lineHeight: 1.5,
        }}>
          {meeting.notes}
        </p>
      )}

      {/* Participants */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', flexWrap: 'wrap' }}>
        <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.3)' }}>
          Organizer:
        </span>
        <span style={{
          fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: '#C9A84C',
        }}>
          {meeting.organizer?.full_name || 'Unknown'}
        </span>

        {meeting.meeting_participants && meeting.meeting_participants.length > 0 && (
          <>
            <span style={{ fontFamily: "'Raleway', sans-serif", fontSize: '12px', color: 'rgba(255,255,255,0.2)', margin: '0 4px' }}>|</span>
            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
              {meeting.meeting_participants.map(p => (
                <span
                  key={p.id}
                  style={{
                    display: 'inline-flex', alignItems: 'center', gap: '4px',
                    fontFamily: "'Raleway', sans-serif", fontSize: '12px',
                    padding: '2px 8px', borderRadius: '10px',
                    background: p.response === 'accepted' ? 'rgba(34,197,94,0.1)' : p.response === 'declined' ? 'rgba(239,68,68,0.1)' : 'rgba(255,255,255,0.03)',
                    color: p.response === 'accepted' ? '#22c55e' : p.response === 'declined' ? '#ef4444' : 'rgba(255,255,255,0.5)',
                    border: `1px solid ${p.response === 'accepted' ? 'rgba(34,197,94,0.15)' : p.response === 'declined' ? 'rgba(239,68,68,0.15)' : 'rgba(255,255,255,0.05)'}`,
                  }}
                >
                  <span style={{
                    width: '6px', height: '6px', borderRadius: '50%',
                    background: p.response === 'accepted' ? '#22c55e' : p.response === 'declined' ? '#ef4444' : 'rgba(255,255,255,0.3)',
                  }} />
                  {p.profile?.full_name || 'Unknown'}
                </span>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Actions */}
      {!isPast && meeting.status !== 'cancelled' && (
        <div style={{ display: 'flex', gap: '8px' }}>
          {isPending && (
            <>
              <button
                onClick={() => onRespond(meeting.id, 'accepted')}
                style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '12px', fontWeight: 600,
                  padding: '6px 16px', borderRadius: '4px', border: '1px solid rgba(34,197,94,0.3)',
                  background: 'rgba(34,197,94,0.1)', color: '#22c55e', cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
              >
                Accept
              </button>
              <button
                onClick={() => onRespond(meeting.id, 'declined')}
                style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '12px', fontWeight: 600,
                  padding: '6px 16px', borderRadius: '4px', border: '1px solid rgba(239,68,68,0.3)',
                  background: 'rgba(239,68,68,0.1)', color: '#ef4444', cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
              >
                Decline
              </button>
            </>
          )}
          {isOrganizer && (
            <button
              onClick={() => onCancel(meeting.id)}
              style={{
                fontFamily: "'Raleway', sans-serif", fontSize: '12px',
                padding: '6px 16px', borderRadius: '4px',
                border: '1px solid rgba(255,255,255,0.06)', background: 'transparent',
                color: 'rgba(255,255,255,0.4)', cursor: 'pointer', transition: 'color 0.2s',
              }}
            >
              Cancel Meeting
            </button>
          )}
        </div>
      )}
    </div>
  )
}

function formatDateTimeStatic(iso: string) {
  const d = new Date(iso)
  return d.toLocaleDateString('en-GB', {
    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
  }) + ' at ' + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
}

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontFamily: "'Raleway', sans-serif",
  fontSize: '12px',
  letterSpacing: '0.05em',
  color: 'rgba(255,255,255,0.4)',
  textTransform: 'uppercase',
  marginBottom: '6px',
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  background: '#000',
  border: '1px solid rgba(255,255,255,0.06)',
  borderRadius: '6px',
  padding: '10px 14px',
  color: '#fff',
  fontFamily: "'Raleway', sans-serif",
  fontSize: '14px',
  outline: 'none',
  boxSizing: 'border-box',
  transition: 'border-color 0.2s',
}
