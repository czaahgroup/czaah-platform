'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

const destinations = [
  { name: 'Hunza Valley & Karakoram', interests: ['Mountains', 'Photography', 'Adventure', 'Heritage'], img: '/Tourism/Hunza-Valley.jpg' },
  { name: 'Skardu & Deosai Plateau', interests: ['Mountains', 'Adventure', 'Trekking', 'Wildlife', 'Photography'], img: '/Tourism/Skardu.jpg' },
  { name: 'Swat Valley', interests: ['Heritage', 'Adventure', 'Trekking'], img: '/Tourism/Swat-Valley.jpg' },
  { name: 'Lahore', interests: ['Heritage', 'Food & Culture', 'Photography', 'Luxury', 'Spiritual'], img: '/Tourism/Lahore.jpg' },
  { name: 'Makran Coast & Gwadar', interests: ['Beach', 'Adventure', 'Photography', 'Luxury'], img: '/Tourism/Gawadar.jpg' },
  { name: 'Fairy Meadows & Nanga Parbat', interests: ['Mountains', 'Trekking', 'Photography', 'Adventure'], img: '/Tourism/Fairy-Meadows.jpg' },
  { name: 'Islamabad', interests: ['Heritage', 'Luxury', 'Food & Culture'], img: 'https://placehold.co/160x120/1a1a1a/C9A84C?text=Islamabad' },
  { name: 'Taxila', interests: ['Heritage', 'Spiritual', 'Photography'], img: 'https://placehold.co/160x120/1a1a1a/C9A84C?text=Taxila' }
];

const interestOptions = ['Mountains', 'Adventure', 'Heritage', 'Wildlife', 'Food & Culture', 'Beach', 'Trekking', 'Photography', 'Luxury', 'Spiritual'];

export default function TourismPage() {
  const [selectedInterests, setSelectedInterests] = useState<Set<string>>(new Set());
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => { entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add('visible'); }); },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach((el) => { observerRef.current?.observe(el); });
    return () => observerRef.current?.disconnect();
  }, []);

  function toggleInterest(interest: string) {
    setSelectedInterests(prev => {
      const newSet = new Set(prev);
      if (newSet.has(interest)) newSet.delete(interest); else newSet.add(interest);
      return newSet;
    });
  }

  const scored = selectedInterests.size > 0
    ? destinations.map(d => {
        const matching = d.interests.filter(i => selectedInterests.has(i));
        return { ...d, matchCount: matching.length, matchingInterests: matching };
      }).filter(d => d.matchCount > 0).sort((a, b) => b.matchCount - a.matchCount)
    : [];

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Tourism.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Destination &amp; Hospitality Investment</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Tourism &amp;<br /><span className="gold">Hospitality.</span></h1>
              <p className="hero-enter hero-enter-delay-3">From the 8,000-metre peaks of the Karakoram to the ancient heritage of Gandhara &mdash; CZAAH facilitates hospitality investment, destination development, and luxury travel operations across Pakistan.</p>
              <a href="/contact?interest=Tourism%20%26%20Hospitality#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Explore Opportunities &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* DESTINATION SHOWCASE */}
        <section className="section fade-in">
          <h2 className="serif">Discover <span className="gold">Pakistan.</span></h2>
          <p className="subtitle">Six extraordinary destinations — each a world unto itself.</p>

          <style>{`
            .tr-showcase { display: flex; flex-direction: column; gap: 16px; margin-top: 48px; }
            .tr-dest-card { position: relative; width: 100%; height: 400px; border-radius: 8px; overflow: hidden; cursor: pointer; }
            .tr-dest-img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s var(--ease-smooth); }
            .tr-dest-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 40%, rgba(0,0,0,0.15) 100%); transition: background 0.6s var(--ease-smooth); z-index: 1; }
            .tr-dest-card:hover .tr-dest-img { transform: scale(1.05); }
            .tr-dest-content { position: absolute; bottom: 0; z-index: 2; padding: 40px; max-width: 650px; transition: transform 0.4s var(--ease-smooth); }
            .tr-dest-left .tr-dest-content { left: 0; text-align: left; }
            .tr-dest-right .tr-dest-content { right: 0; text-align: right; margin-left: auto; }
            .tr-dest-card:hover .tr-dest-content { transform: translateY(-6px); }
            .tr-dest-category { display: inline-block; font-family: 'Raleway', sans-serif; font-size: 11px; font-weight: 600; letter-spacing: 0.15em; text-transform: uppercase; color: var(--gold); margin-bottom: 10px; }
            .tr-dest-title { font-size: 32px; font-weight: 600; color: var(--white); margin-bottom: 12px; line-height: 1.15; }
            .tr-dest-desc { font-size: 14px; line-height: 1.7; color: var(--white); margin-bottom: 16px; }
            .tr-dest-stats { display: flex; gap: 24px; margin-bottom: 16px; flex-wrap: wrap; }
            .tr-dest-right .tr-dest-stats { justify-content: flex-end; }
            .tr-dest-stats span { font-family: 'Raleway', sans-serif; font-size: 12px; font-weight: 500; color: var(--gold); letter-spacing: 0.03em; white-space: nowrap; }
            .tr-dest-link { font-family: 'Raleway', sans-serif; font-size: 13px; font-weight: 500; color: var(--gold); text-decoration: none; letter-spacing: 0.05em; transition: color 0.3s; }
            .tr-dest-link:hover { color: var(--gold-light, #e0c06a); }
            .tr-pills { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 32px; justify-content: center; }
            .tr-pill { font-family: 'Raleway', sans-serif; font-size: 13px; font-weight: 500; padding: 10px 22px; border-radius: 100px; border: 1px solid var(--black-border, #2a2a2a); background: var(--black-card, #111); color: var(--white-dim, #999); cursor: pointer; transition: all 0.3s var(--ease-smooth); user-select: none; }
            .tr-pill:hover { border-color: var(--gold); color: var(--white-muted, #ccc); }
            .tr-pill.active { border-color: var(--gold); color: var(--gold); background: rgba(201, 168, 76, 0.08); }
            .tr-results-empty { text-align: center; font-family: 'Raleway', sans-serif; font-size: 14px; color: var(--white-dim, #999); padding: 40px 20px; font-style: italic; }
            .tr-results-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 16px; }
            .tr-result-card { display: flex; align-items: center; gap: 16px; padding: 16px; border: 1px solid var(--black-border, #2a2a2a); border-radius: 8px; background: var(--black-card, #111); transition: all 0.3s var(--ease-smooth); }
            .tr-result-card:hover { border-color: var(--gold); background: var(--black-elevated, #1a1a1a); }
            .tr-result-thumb { width: 80px; height: 60px; border-radius: 6px; object-fit: cover; flex-shrink: 0; }
            .tr-result-info { flex: 1; min-width: 0; }
            .tr-result-name { font-family: 'Cinzel', serif; font-size: 16px; font-weight: 600; color: var(--white); margin-bottom: 4px; }
            .tr-result-match { font-family: 'Raleway', sans-serif; font-size: 12px; color: var(--gold-dim, #b89a3e); line-height: 1.4; }
            .tr-result-count { font-family: 'Raleway', sans-serif; font-size: 11px; font-weight: 600; color: var(--gold); background: rgba(201, 168, 76, 0.1); padding: 4px 10px; border-radius: 100px; white-space: nowrap; flex-shrink: 0; }
            @media (max-width: 768px) { .tr-dest-card { height: 300px; } .tr-dest-content { padding: 24px; max-width: 100%; } .tr-dest-right .tr-dest-content { text-align: left; } .tr-dest-right .tr-dest-stats { justify-content: flex-start; } .tr-dest-title { font-size: 24px; } .tr-dest-desc { font-size: 13px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; } .tr-results-grid { grid-template-columns: 1fr; } }
          `}</style>

          <div className="tr-showcase">
            <div className="tr-dest-card tr-dest-left fade-in">
              <img src="/Tourism/Hunza-Valley.jpg" alt="Hunza Valley & Karakoram" className="tr-dest-img" />
              <div className="tr-dest-overlay"></div>
              <div className="tr-dest-content">
                <span className="tr-dest-category">Mountain &amp; Adventure</span>
                <h3 className="tr-dest-title serif">Hunza Valley &amp; Karakoram</h3>
                <p className="tr-dest-desc">Where the Silk Road meets the sky. Pakistan&apos;s crown jewel — terraced villages at 8,000ft, views of Rakaposhi (7,788m), the ancient Baltit Fort, and the turquoise Attabad Lake. Adventure tourism growing 50%+ annually.</p>
                <div className="tr-dest-stats"><span>7,788m Rakaposhi</span><span>300+ days sunshine</span><span>50%+ tourism growth</span></div>
                <a href="/contact" className="tr-dest-link">Explore &rarr;</a>
              </div>
            </div>
            <div className="tr-dest-card tr-dest-right fade-in">
              <img src="/Tourism/Skardu.jpg" alt="Skardu & Deosai Plateau" className="tr-dest-img" />
              <div className="tr-dest-overlay"></div>
              <div className="tr-dest-content">
                <span className="tr-dest-category">Wilderness &amp; Expedition</span>
                <h3 className="tr-dest-title serif">Skardu &amp; Deosai Plateau</h3>
                <p className="tr-dest-desc">The roof of the world — untouched. Gateway to K2 and the Karakoram&apos;s five 8,000m+ peaks. Deosai is the world&apos;s second-highest plateau — home to brown bears and an ecosystem found nowhere else. Expedition base camp and luxury glamping potential.</p>
                <div className="tr-dest-stats"><span>5 peaks over 8,000m</span><span>4,114m Deosai altitude</span><span>Expedition gateway</span></div>
                <a href="/contact" className="tr-dest-link">Explore &rarr;</a>
              </div>
            </div>
            <div className="tr-dest-card tr-dest-left fade-in">
              <img src="/Tourism/Swat-Valley.jpg" alt="Swat Valley" className="tr-dest-img" />
              <div className="tr-dest-overlay"></div>
              <div className="tr-dest-content">
                <span className="tr-dest-category">Heritage &amp; Nature</span>
                <h3 className="tr-dest-title serif">Swat Valley</h3>
                <p className="tr-dest-desc">The Switzerland of Pakistan. Buddhist heritage sites, emerald rivers, the Malam Jabba ski resort, and lush valley landscapes. Government-backed tourism investment zone with tax incentives. Accessible via motorway from Islamabad.</p>
                <div className="tr-dest-stats"><span>2 UNESCO sites nearby</span><span>Ski resort operational</span><span>4hr from Islamabad</span></div>
                <a href="/contact" className="tr-dest-link">Explore &rarr;</a>
              </div>
            </div>
            <div className="tr-dest-card tr-dest-right fade-in">
              <img src="/Tourism/Lahore.jpg" alt="Lahore — The Cultural Capital" className="tr-dest-img" />
              <div className="tr-dest-overlay"></div>
              <div className="tr-dest-content">
                <span className="tr-dest-category">Heritage &amp; Gastronomy</span>
                <h3 className="tr-dest-title serif">Lahore — The Cultural Capital</h3>
                <p className="tr-dest-desc">2,000 years of living history. Mughal architecture (Badshahi Mosque, Lahore Fort, Shalimar Gardens), the walled city, and Pakistan&apos;s undisputed food capital. Major MICE destination with growing international hotel demand.</p>
                <div className="tr-dest-stats"><span>3 UNESCO sites</span><span>$2B+ food economy</span><span>12M+ population</span></div>
                <a href="/contact" className="tr-dest-link">Explore &rarr;</a>
              </div>
            </div>
            <div className="tr-dest-card tr-dest-left fade-in">
              <img src="/Tourism/Gawadar.jpg" alt="Makran Coast & Gwadar" className="tr-dest-img" />
              <div className="tr-dest-overlay"></div>
              <div className="tr-dest-content">
                <span className="tr-dest-category">Coastal &amp; Resort</span>
                <h3 className="tr-dest-title serif">Makran Coast &amp; Gwadar</h3>
                <p className="tr-dest-desc">600km of untouched Arabian Sea. Pakistan&apos;s coastal frontier — pristine beaches, marine biodiversity, and the CPEC port city of Gwadar. Beach resort, marina, and eco-tourism development potential on a scale not seen since early Dubai.</p>
                <div className="tr-dest-stats"><span>600km coastline</span><span>CPEC connectivity</span><span>Marina potential</span></div>
                <a href="/contact" className="tr-dest-link">Explore &rarr;</a>
              </div>
            </div>
            <div className="tr-dest-card tr-dest-right fade-in">
              <img src="/Tourism/Fairy-Meadows.jpg" alt="Fairy Meadows & Nanga Parbat" className="tr-dest-img" />
              <div className="tr-dest-overlay"></div>
              <div className="tr-dest-content">
                <span className="tr-dest-category">Adventure &amp; Trekking</span>
                <h3 className="tr-dest-title serif">Fairy Meadows &amp; Nanga Parbat</h3>
                <p className="tr-dest-desc">The killer mountain&apos;s gentle meadow. The base camp meadow of Nanga Parbat (8,126m) — Pakistan&apos;s most photographed landscape. Alpine meadows, pine forests, and views of the world&apos;s 9th highest peak. Glamping and eco-lodge investment opportunities.</p>
                <div className="tr-dest-stats"><span>8,126m Nanga Parbat</span><span>Alpine meadow</span><span>Glamping potential</span></div>
                <a href="/contact" className="tr-dest-link">Explore &rarr;</a>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* TRIP INTEREST SELECTOR */}
        <section className="section fade-in">
          <h2 className="serif">Find your <span className="gold">Pakistan.</span></h2>
          <p className="subtitle">Select your interests to discover your perfect itinerary.</p>

          <div style={{ marginTop: '48px' }}>
            <div className="tr-pills">
              {interestOptions.map(interest => (
                <button key={interest} className={`tr-pill${selectedInterests.has(interest) ? ' active' : ''}`} onClick={() => toggleInterest(interest)}>{interest}</button>
              ))}
            </div>

            <div style={{ minHeight: '80px' }}>
              {selectedInterests.size === 0 ? (
                <div className="tr-results-empty">Select your interests to discover your perfect Pakistan itinerary</div>
              ) : scored.length === 0 ? (
                <div className="tr-results-empty">No destinations match your selection. Try different interests.</div>
              ) : (
                <div className="tr-results-grid">
                  {scored.map((d, i) => (
                    <div key={i} className="tr-result-card" style={{ animationDelay: `${i * 0.06}s` }}>
                      <img src={d.img} alt={d.name} className="tr-result-thumb" />
                      <div className="tr-result-info">
                        <div className="tr-result-name">{d.name}</div>
                        <div className="tr-result-match">{d.matchingInterests.join(' \u00B7 ')}</div>
                      </div>
                      <span className="tr-result-count">{d.matchCount} match{d.matchCount > 1 ? 'es' : ''}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* TWO PILLARS */}
        <section className="section fade-in-left">
          <div className="split">
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Hospitality Investment</div>
              <h3 className="serif">The hotel gap is a <span className="gold">golden opportunity.</span></h3>
              <p>Pakistan has fewer than 5,000 internationally branded hotel rooms for a country of 240 million people. Compare this to the UAE&apos;s 200,000+. The hospitality deficit is enormous — and so is the opportunity.</p>
              <p>CZAAH facilitates hotel development, resort investment, and hospitality management partnerships across Pakistan&apos;s most promising destinations: Islamabad, Lahore, Hunza, Swat, Skardu, and the Makran coast.</p>
              <p>We connect international hotel brands and hospitality investors with prime land, development partners, and the regulatory approvals needed to build world-class properties in an underserved market.</p>
            </div>
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Luxury Travel</div>
              <h3 className="serif">Curated experiences in an <span className="gold">undiscovered land.</span></h3>
              <p>Pakistan was named the world&apos;s #1 travel destination by Cond&eacute; Nast Traveller and has seen tourism numbers grow over 300% in recent years. Yet the luxury travel infrastructure remains nascent — creating a premium positioning opportunity.</p>
              <p>CZAAH operates curated travel experiences for high-net-worth individuals, corporate retreats, and diplomatic delegations — combining private aviation, security logistics, and exclusive access to Pakistan&apos;s most spectacular destinations.</p>
              <p>From helicopter tours over Fairy Meadows to private camping on Deosai Plateau and heritage walks through Mughal Lahore — we deliver travel experiences unavailable through any conventional operator.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Investment facilitation, destination development, and premium travel operations.</p>
          <div className="detail-grid stagger">
            <div className="detail-card"><div className="card-icon">&#9978;</div><h3>Hotel &amp; Resort Development</h3><p>Site identification, feasibility studies, and development facilitation for hotels, resorts, and eco-lodges. From prime urban locations to remote mountain destinations with tourism authority coordination.</p></div>
            <div className="detail-card"><div className="card-icon">&#9670;</div><h3>Brand Partnerships</h3><p>Facilitate management agreements and franchise partnerships between international hotel brands and Pakistani property developers. Market entry advisory for brands evaluating Pakistan&apos;s hospitality sector.</p></div>
            <div className="detail-card"><div className="card-icon">&#9632;</div><h3>Destination Management</h3><p>End-to-end destination management for corporate groups, VIP delegations, and luxury travellers. Itinerary design, ground logistics, security coordination, and local guide networks across all provinces.</p></div>
            <div className="detail-card"><div className="card-icon">&#9733;</div><h3>VIP &amp; Corporate Travel</h3><p>Bespoke travel programmes for executives, investor groups, and diplomatic visitors. Private aviation integration, armoured transport, premium accommodation, and 24/7 concierge throughout Pakistan.</p></div>
            <div className="detail-card"><div className="card-icon">&#43;</div><h3>Adventure &amp; Expedition</h3><p>K2 and Karakoram expeditions, Himalayan trekking, polo in Shandur, falconry in Balochistan, and heritage trails through Taxila, Mohenjo-daro, and Mughal-era Lahore — curated for discerning travellers.</p></div>
            <div className="detail-card"><div className="card-icon">&#8644;</div><h3>Tourism Infrastructure</h3><p>Investment facilitation for tourism infrastructure: ski resorts, cable cars, camping facilities, visitor centres, and adventure sports operations in northern Pakistan and coastal Balochistan.</p></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* DESTINATIONS */}
        <section className="section fade-in">
          <h2 className="serif">Key <span className="gold">destinations.</span></h2>
          <p className="subtitle">Pakistan&apos;s most compelling tourism and hospitality investment corridors.</p>
          <div className="relationships stagger">
            <div className="rel-card"><div className="rel-icon">&#9670;</div><div><h4>Gilgit-Baltistan &amp; Hunza</h4><p>Home to five 8,000m+ peaks, the ancient Silk Road, and some of the most dramatic mountain scenery on Earth. Skardu, Hunza Valley, and Fairy Meadows are seeing explosive tourism growth with minimal hospitality infrastructure.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9632;</div><div><h4>Swat &amp; KPK</h4><p>The &quot;Switzerland of the East&quot; — lush valleys, Buddhist heritage sites, and ski potential at Malam Jabba. Government is actively promoting tourism investment with incentives and improved road access.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9733;</div><div><h4>Makran Coast</h4><p>600km of undeveloped Arabian Sea coastline in Balochistan. Gwadar and Ormara present unique opportunities for beach resorts, marina development, and coastal tourism linked to CPEC infrastructure.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9881;</div><div><h4>Heritage Cities</h4><p>Lahore (Mughal architecture, food culture), Islamabad (modern capital, Margalla Hills), and Taxila (Gandhara civilisation) — urban tourism destinations demanding international-standard hotel capacity.</p></div></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <div className="stats-row stagger">
            <div className="stat-item"><div className="number">300%+</div><div className="label">Tourism growth (recent years)</div></div>
            <div className="stat-item"><div className="number">5</div><div className="label">Peaks above 8,000m</div></div>
            <div className="stat-item"><div className="number">6</div><div className="label">UNESCO World Heritage Sites</div></div>
            <div className="stat-item"><div className="number">#1</div><div className="label">Cond&eacute; Nast destination ranking</div></div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Pakistan&apos;s next frontier in <span className="gold">hospitality.</span></h2>
          <p>Hotel investment, destination development, and luxury travel operations across an extraordinary landscape.</p>
          <a href="/contact?interest=Tourism%20%26%20Hospitality#contact-form" className="btn-gold">Explore Opportunities &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
