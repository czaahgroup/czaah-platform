'use client';
// @ts-nocheck

import { useEffect, useRef, useState, useCallback } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface Connection {
  name: string;
  type: string;
  description: string;
  depth: number;
}

interface Category {
  name: string;
  icon: string;
  description: string;
  connections: Connection[];
}

const categories: Category[] = [
  {
    name: 'Government',
    icon: '\u25A0',
    description: "Direct access to Pakistan's federal and provincial government departments, regulatory agencies, and policy-making bodies. CZAAH maintains active relationships across all tiers of governance.",
    connections: [
      { name: 'Ministry of Commerce', type: '\u25A0', description: 'Trade policy, export facilitation, bilateral agreements', depth: 5 },
      { name: 'Board of Investment', type: '\u25A0', description: 'FDI approvals, investor facilitation, incentive packages', depth: 5 },
      { name: 'SECP', type: '\u25A0', description: 'Corporate registration, securities regulation, compliance', depth: 4 },
      { name: 'FBR', type: '\u25A0', description: 'Tax policy, customs facilitation, duty structures', depth: 4 },
      { name: 'Provincial Mines Depts', type: '\u25A0', description: 'Mining leases, exploration licenses, provincial regulation', depth: 5 },
      { name: 'Planning Commission', type: '\u25A0', description: 'National development projects, PSDP allocations', depth: 4 },
      { name: 'PPRA', type: '\u25A0', description: 'Public procurement regulation, tender compliance', depth: 3 },
      { name: 'IT Ministry', type: '\u25A0', description: 'Digital Pakistan initiatives, tech policy, e-governance', depth: 4 }
    ]
  },
  {
    name: 'Industry',
    icon: '\u2699',
    description: "Established relationships with Pakistan's leading industrial groups, manufacturers, and trade bodies across all major sectors.",
    connections: [
      { name: 'FPCCI', type: '\u2699', description: 'Federation of Pakistan Chambers of Commerce & Industry', depth: 5 },
      { name: 'Chambers of Commerce', type: '\u2699', description: 'LCCI, KCCI, ICCI \u2014 regional trade bodies', depth: 4 },
      { name: 'Mining Operators', type: '\u25C6', description: 'Active extraction companies across Balochistan and KPK', depth: 5 },
      { name: 'Textile Manufacturers', type: '\u2746', description: 'Export-oriented mills, garment producers, home textiles', depth: 4 },
      { name: 'Construction Firms', type: '\u26E8', description: 'Infrastructure contractors, real estate developers', depth: 4 },
      { name: 'Agricultural Cooperatives', type: '\u2618', description: 'Farming cooperatives, food processing, agri-export', depth: 3 }
    ]
  },
  {
    name: 'Financial',
    icon: '$',
    description: "Deep connections across Pakistan's banking sector, development finance institutions, and private capital markets for investment structuring and financing.",
    connections: [
      { name: 'HBL', type: '$', description: "Pakistan's largest private bank, corporate banking", depth: 4 },
      { name: 'UBL', type: '$', description: 'United Bank Limited, trade finance specialist', depth: 4 },
      { name: 'MCB', type: '$', description: 'MCB Bank, commercial and SME banking', depth: 3 },
      { name: 'IFC', type: '$', description: 'International Finance Corporation, development capital', depth: 4 },
      { name: 'ADB Pakistan', type: '$', description: 'Asian Development Bank, infrastructure financing', depth: 3 },
      { name: 'DFID', type: '$', description: 'UK development finance, governance programmes', depth: 3 },
      { name: 'Private Equity Firms', type: '$', description: 'Pakistan-focused PE and growth capital funds', depth: 4 },
      { name: 'Islamic Finance', type: '$', description: 'Shariah-compliant financing, sukuk structures', depth: 3 }
    ]
  },
  {
    name: 'Legal & Advisory',
    icon: '\u2696',
    description: "Vetted network of legal, tax, and advisory professionals with deep expertise in Pakistani corporate law, international transactions, and dispute resolution.",
    connections: [
      { name: 'Corporate Law Firms', type: '\u2696', description: 'M&A, corporate structuring, regulatory advisory', depth: 5 },
      { name: 'Tax Advisory', type: '\u2696', description: 'FBR compliance, transfer pricing, tax planning', depth: 4 },
      { name: 'IP Specialists', type: '\u2696', description: 'Trademark, patent, trade secret protection', depth: 3 },
      { name: 'Dispute Resolution', type: '\u2696', description: 'Commercial litigation, mediation, arbitration', depth: 4 },
      { name: 'International Arbitration', type: '\u2696', description: 'Cross-border dispute resolution, BIT claims', depth: 4 },
      { name: 'Accounting Firms', type: '\u2696', description: 'Audit, assurance, financial due diligence', depth: 4 }
    ]
  },
  {
    name: 'International',
    icon: '\u2691',
    description: "Active engagement with foreign diplomatic missions, trade promotion bodies, and multilateral organisations operating in Pakistan.",
    connections: [
      { name: 'Chinese Embassy', type: '\u2691', description: 'Commercial section, CPEC coordination, trade promotion', depth: 5 },
      { name: 'UAE Trade Offices', type: '\u2691', description: 'UAE-Pakistan trade facilitation, investment promotion', depth: 4 },
      { name: 'UK DIT', type: '\u2691', description: 'UK Department for International Trade, bilateral commerce', depth: 3 },
      { name: 'USAID', type: '\u2691', description: 'Development programmes, governance, economic growth', depth: 3 },
      { name: 'World Bank Pakistan', type: '\u2691', description: 'Development projects, policy reform, technical assistance', depth: 4 },
      { name: 'CPEC Authority', type: '\u2691', description: 'China-Pakistan Economic Corridor coordination body', depth: 5 }
    ]
  },
  {
    name: 'Military & Strategic',
    icon: '\u2605',
    description: "Awareness of Pakistan's strategic and defence-adjacent institutional landscape, including welfare trusts and logistics entities relevant to infrastructure and development projects.",
    connections: [
      { name: 'Fauji Foundation', type: '\u2605', description: 'Defence welfare conglomerate, industrial operations', depth: 4 },
      { name: 'Army Welfare Trust', type: '\u2605', description: 'Welfare investments, commercial operations', depth: 3 },
      { name: 'Defence Logistics', type: '\u2605', description: 'Supply chain, transport, facility management', depth: 3 },
      { name: 'Strategic Projects', type: '\u2605', description: 'Infrastructure and development project support', depth: 3 },
      { name: 'NLC', type: '\u2605', description: 'National Logistics Cell, transport and infrastructure', depth: 4 },
      { name: 'FWO', type: '\u2605', description: 'Frontier Works Organisation, construction and engineering', depth: 4 }
    ]
  }
];

export default function PartnershipDevelopmentPage() {
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const constellationRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const hubRef = useRef<HTMLDivElement>(null);
  const nodesRef = useRef<HTMLDivElement>(null);

  const drawLines = useCallback(() => {
    const constellation = constellationRef.current;
    const svg = svgRef.current;
    const hub = hubRef.current;
    const nodesContainer = nodesRef.current;
    if (!constellation || !svg || !hub || !nodesContainer) return;

    const rect = constellation.getBoundingClientRect();
    const hubRect = hub.getBoundingClientRect();
    const hx = hubRect.left - rect.left + hubRect.width / 2;
    const hy = hubRect.top - rect.top + hubRect.height / 2;

    svg.setAttribute('viewBox', `0 0 ${rect.width} ${rect.height}`);
    svg.innerHTML = '';

    const nodes = nodesContainer.querySelectorAll('.pn-node');
    nodes.forEach((node, i) => {
      const nr = node.getBoundingClientRect();
      const nx = nr.left - rect.left + nr.width / 2;
      const ny = nr.top - rect.top + nr.height / 2;
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', String(hx));
      line.setAttribute('y1', String(hy));
      line.setAttribute('x2', String(nx));
      line.setAttribute('y2', String(ny));
      if (i === activeIndex) line.classList.add('pn-line-active');
      svg.appendChild(line);
    });
  }, [activeIndex]);

  useEffect(() => {
    drawLines();
    window.addEventListener('resize', drawLines);
    return () => window.removeEventListener('resize', drawLines);
  }, [drawLines]);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const toggleCategory = (index: number) => {
    if (activeIndex === index) {
      setActiveIndex(-1);
    } else {
      setActiveIndex(index);
    }
  };

  const activeCat = activeIndex >= 0 ? categories[activeIndex] : null;

  return (
    <>
      <Navbar />

      <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Partnership-Development.jpg')" }}>
        <section className="v-hero">
          <div className="v-hero-text">
            <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
            <span className="gold-line hero-enter"></span>
            <div className="label hero-enter hero-enter-delay-1">Local Expertise</div>
            <h1 className="serif hero-enter hero-enter-delay-2">Partnership<br /><span className="gold">Development.</span></h1>
            <p className="hero-enter hero-enter-delay-3">CZAAH&apos;s deepest value is our network. We connect international investors with Pakistan&apos;s most relevant government departments, industry leaders, legal experts, financial institutions, and operational partners &mdash; curated introductions that accelerate your success.</p>
            <a href="/contact?interest=Partnership%20Development#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Build Partnerships &rarr;</a>
          </div>
        </section>
      </div>

      <div className="divider"></div>

      {/* NETWORK CONSTELLATION */}
      <section className="pn-section fade-in">
        <h2 className="pn-heading">Our network <span className="gold">constellation.</span></h2>
        <p className="pn-subtitle">Explore CZAAH&apos;s institutional relationships across Pakistan&apos;s government, industry, and financial landscape.</p>

        <div className="pn-constellation" id="pnConstellation" ref={constellationRef}>
          <svg className="pn-lines" ref={svgRef}></svg>
          <div className="pn-hub" ref={hubRef}>CZAAH</div>
          <div className="pn-nodes" ref={nodesRef}>
            {categories.map((cat, i) => (
              <div
                key={cat.name}
                className={`pn-node${activeIndex === i ? ' pn-active' : ''}`}
                data-index={i}
                onClick={() => toggleCategory(i)}
              >
                <span className="pn-node-icon" dangerouslySetInnerHTML={{ __html: cat.icon }} />
                <span className="pn-node-label">{cat.name}</span>
              </div>
            ))}
          </div>
        </div>

        <div className={`pn-detail${activeCat ? ' pn-detail-open' : ''}`}>
          {activeCat && (
            <div className="pn-detail-inner">
              <div className="pn-detail-header">
                <div className="pn-detail-name">{activeCat.name}</div>
                <div className="pn-detail-desc">{activeCat.description}</div>
              </div>
              <div className="pn-cards-grid">
                {activeCat.connections.map((conn) => (
                  <div className="pn-card" key={conn.name}>
                    <div className="pn-card-top">
                      <span className="pn-card-name">
                        <span className="pn-card-type-icon" dangerouslySetInnerHTML={{ __html: conn.type }} />
                        {conn.name}
                      </span>
                      <span className="pn-card-badge">Active</span>
                    </div>
                    <div className="pn-card-desc">{conn.description}</div>
                    <div className="pn-card-depth">
                      {[1, 2, 3, 4, 5].map(d => (
                        <span key={d} className={`pn-dot${d <= conn.depth ? ' pn-dot-filled' : ''}`}></span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      <div className="divider"></div>

      {/* SERVICES */}
      <section className="section fade-in">
        <h2 className="serif">Our <span className="gold">services.</span></h2>
        <p className="subtitle">Curated introductions and partnership structuring &mdash; connecting you with the right people at the right level across Pakistan&apos;s institutions.</p>

        <div className="detail-grid stagger">
          <div className="detail-card">
            <div className="card-icon">&#9632;</div>
            <h3>Government Liaison</h3>
            <p>Direct introductions to relevant federal and provincial departments, ministries, and regulatory bodies. We navigate Pakistan&apos;s government apparatus so you don&apos;t have to &mdash; opening doors that matter.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9670;</div>
            <h3>Industry Partnerships</h3>
            <p>Connections with established Pakistani companies, manufacturers, and service providers. We match your operational needs with vetted, capable partners who have the track record to deliver.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9733;</div>
            <h3>Legal &amp; Accounting</h3>
            <p>Access to vetted law firms, chartered accountants, and tax advisors with international experience. We connect you with professionals who understand both Pakistani law and international investor expectations.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#36;</div>
            <h3>Financial Institutions</h3>
            <p>Banking relationships, development finance institutions, private equity introductions. We facilitate access to Pakistan&apos;s financial ecosystem &mdash; from commercial banks to DFIs to private capital.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9881;</div>
            <h3>Developer &amp; Contractor Networks</h3>
            <p>Construction companies, real estate developers, and infrastructure contractors. When your investment requires physical execution, we connect you with contractors who deliver on time and on budget.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#43;</div>
            <h3>Joint Venture Structuring</h3>
            <p>Partner identification, JV negotiation support, partnership agreement frameworks. We help you find the right local partner and structure the relationship to protect your interests while enabling mutual success.</p>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* STATS */}
      <section className="section section-center fade-in-scale">
        <h2 className="serif">Partnership network <span className="gold">at a glance.</span></h2>
        <div className="stats-row stagger">
          <div className="stat-item">
            <div className="number">Cross-party</div>
            <div className="label">Political coverage</div>
          </div>
          <div className="stat-item">
            <div className="number">Federal+Provincial</div>
            <div className="label">Government access</div>
          </div>
          <div className="stat-item">
            <div className="number">Vetted</div>
            <div className="label">Partner network</div>
          </div>
          <div className="stat-item">
            <div className="number">Decades</div>
            <div className="label">Relationship depth</div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* WHY CZAAH */}
      <section className="section fade-in">
        <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
        <p className="subtitle">In Pakistan, relationships determine outcomes. Ours are the ones that move deals forward.</p>

        <div className="relationships stagger">
          <div className="rel-card">
            <div className="rel-icon">&#9670;</div>
            <div>
              <h4>Relationship Depth</h4>
              <p>Our network is built on years of direct engagement with Pakistan&apos;s government officials, industry leaders, and institutional stakeholders. These are not cold introductions &mdash; they are warm, trusted connections with established credibility.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9632;</div>
            <div>
              <h4>Cross-Party Access</h4>
              <p>Pakistan&apos;s political landscape shifts between administrations. CZAAH maintains relationships across all major political parties, ensuring your partnerships and projects have continuity regardless of who governs.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9733;</div>
            <div>
              <h4>Curated Introductions</h4>
              <p>We don&apos;t provide contact lists &mdash; we provide curated, purposeful introductions to the specific individuals who can advance your objectives. Every connection is selected for relevance, capability, and reliability.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#8644;</div>
            <div>
              <h4>Long-Term Partnership Approach</h4>
              <p>We invest in relationships that endure. CZAAH doesn&apos;t facilitate one-off introductions &mdash; we build partnership ecosystems that support your investment through every phase, from entry to expansion to exit.</p>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      <section className="cta-banner fade-in">
        <h2 className="serif">The relationships that <span className="gold">matter.</span></h2>
        <p>Government departments, industry leaders, legal experts, and institutional partners &mdash; curated introductions that accelerate outcomes.</p>
        <a href="/contact?interest=Partnership%20Development#contact-form" className="btn-gold">Discuss Your Objectives &rarr;</a>
      </section>

      <Footer />
    </>
  );
}