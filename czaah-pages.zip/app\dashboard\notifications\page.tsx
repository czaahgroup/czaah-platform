'use client'

import { useState, useEffect, useCallback } from 'react'

interface Notification {
  id: string
  title: string
  body: string
  type: string
  link: string | null
  is_read: boolean
  created_at: string
}

function timeAgo(dateStr: string): string {
  const now = Date.now()
  const date = new Date(dateStr).getTime()
  const diff = Math.floor((now - date) / 1000)
  if (diff < 60) return 'just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`
  return new Date(dateStr).toLocaleDateString()
}

function typeIcon(type: string): string {
  switch (type) {
    case 'enquiry': return '\u2709'
    case 'kyc': return '\u2611'
    case 'investment': return '$'
    case 'chat': return '\u2630'
    case 'system': return '\u2699'
    case 'broadcast': return '\u25C6'
    default: return '\u2022'
  }
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'unread'>('all')

  const fetchNotifications = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/notifications')
      if (res.ok) {
        const data = await res.json()
        setNotifications(data.data ?? [])
      }
    } catch { /* silent */ }
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchNotifications()
  }, [fetchNotifications])

  const markAllRead = async () => {
    try {
      await fetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ markAllRead: true }),
      })
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })))
    } catch { /* silent */ }
  }

  const markOneRead = async (id: string) => {
    try {
      await fetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationId: id }),
      })
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n))
    } catch { /* silent */ }
  }

  const handleClick = (n: Notification) => {
    if (!n.is_read) markOneRead(n.id)
    if (n.link) window.location.href = n.link
  }

  const filtered = filter === 'unread' ? notifications.filter(n => !n.is_read) : notifications
  const unreadCount = notifications.filter(n => !n.is_read).length

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '32px' }}>
        <div>
          <h1 style={{
            fontFamily: "'Cinzel', serif",
            fontSize: '24px',
            fontWeight: 600,
            color: '#fff',
            letterSpacing: '4px',
            margin: 0,
          }}>NOTIFICATIONS</h1>
          <p style={{
            fontFamily: "'Raleway', sans-serif",
            fontSize: '13px',
            color: 'rgba(255,255,255,0.4)',
            marginTop: '8px',
          }}>{unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}</p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={markAllRead}
            style={{
              background: 'rgba(201,168,76,0.1)',
              border: '1px solid rgba(201,168,76,0.3)',
              borderRadius: '6px',
              padding: '8px 16px',
              cursor: 'pointer',
              fontFamily: "'Raleway', sans-serif",
              fontSize: '12px',
              color: '#C9A84C',
              letterSpacing: '1px',
              transition: 'background 0.2s ease',
            }}
          >
            Mark All as Read
          </button>
        )}
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: '4px', marginBottom: '24px' }}>
        {(['all', 'unread'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            style={{
              background: filter === tab ? 'rgba(201,168,76,0.1)' : 'transparent',
              border: filter === tab ? '1px solid rgba(201,168,76,0.3)' : '1px solid rgba(255,255,255,0.06)',
              borderRadius: '6px',
              padding: '8px 20px',
              cursor: 'pointer',
              fontFamily: "'Raleway', sans-serif",
              fontSize: '12px',
              color: filter === tab ? '#C9A84C' : 'rgba(255,255,255,0.4)',
              letterSpacing: '1px',
              textTransform: 'uppercase',
              transition: 'all 0.2s ease',
            }}
          >
            {tab}{tab === 'unread' && unreadCount > 0 ? ` (${unreadCount})` : ''}
          </button>
        ))}
      </div>

      {/* Notifications list */}
      <div style={{
        background: '#080808',
        border: '1px solid rgba(255,255,255,0.06)',
        borderRadius: '8px',
        overflow: 'hidden',
      }}>
        {loading ? (
          <div style={{
            padding: '48px',
            textAlign: 'center',
            fontFamily: "'Raleway', sans-serif",
            fontSize: '13px',
            color: 'rgba(255,255,255,0.3)',
          }}>Loading notifications...</div>
        ) : filtered.length === 0 ? (
          <div style={{
            padding: '48px',
            textAlign: 'center',
            fontFamily: "'Raleway', sans-serif",
            fontSize: '13px',
            color: 'rgba(255,255,255,0.3)',
          }}>{filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}</div>
        ) : (
          filtered.map(n => (
            <div
              key={n.id}
              onClick={() => handleClick(n)}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '14px',
                padding: '16px 20px',
                borderLeft: n.is_read ? '3px solid transparent' : '3px solid #C9A84C',
                borderBottom: '1px solid rgba(255,255,255,0.03)',
                background: n.is_read ? 'transparent' : 'rgba(201,168,76,0.02)',
                cursor: n.link ? 'pointer' : 'default',
                transition: 'background 0.2s ease',
              }}
              onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.02)')}
              onMouseLeave={e => (e.currentTarget.style.background = n.is_read ? 'transparent' : 'rgba(201,168,76,0.02)')}
            >
              {/* Type icon */}
              <div style={{
                width: '36px',
                height: '36px',
                borderRadius: '8px',
                background: 'rgba(201,168,76,0.08)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '16px',
                flexShrink: 0,
                color: '#C9A84C',
                marginTop: '2px',
              }}>{typeIcon(n.type)}</div>

              {/* Content */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
                  <span style={{
                    fontFamily: "'Raleway', sans-serif",
                    fontSize: '13px',
                    fontWeight: n.is_read ? 400 : 600,
                    color: n.is_read ? 'rgba(255,255,255,0.6)' : 'rgba(255,255,255,0.9)',
                    lineHeight: 1.3,
                  }}>{n.title}</span>
                  <span style={{
                    fontFamily: "'Raleway', sans-serif",
                    fontSize: '10px',
                    color: 'rgba(255,255,255,0.2)',
                    flexShrink: 0,
                  }}>{timeAgo(n.created_at)}</span>
                </div>
                <div style={{
                  fontFamily: "'Raleway', sans-serif",
                  fontSize: '12px',
                  color: 'rgba(255,255,255,0.35)',
                  marginTop: '4px',
                  lineHeight: 1.5,
                }}>{n.body}</div>
              </div>

              {/* Unread dot + mark as read */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', flexShrink: 0 }}>
                {!n.is_read && (
                  <button
                    onClick={e => { e.stopPropagation(); markOneRead(n.id) }}
                    title="Mark as read"
                    style={{
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      padding: '4px',
                      fontSize: '10px',
                      color: 'rgba(255,255,255,0.3)',
                      fontFamily: "'Raleway', sans-serif",
                    }}
                  >
                    &#10003;
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
