import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'
import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-czaah-black flex flex-col">
      <Navbar />

      <main className="flex-1 flex items-center justify-center px-6">
        <div className="text-center max-w-lg">
          {/* Markhor Head SVG */}
          <div className="flex justify-center mb-10">
            <svg
              width="100"
              height="80"
              viewBox="-5 -12 100 80"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="nfHornGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8a6f2e" />
                  <stop offset="40%" stopColor="#c9a84c" />
                  <stop offset="60%" stopColor="#e8c97a" />
                  <stop offset="100%" stopColor="#8a6f2e" />
                </linearGradient>
                <linearGradient id="nfBodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#c9a84c" />
                  <stop offset="100%" stopColor="#8a6f2e" />
                </linearGradient>
              </defs>
              {/* Left horn */}
              <path
                d="M 38 38 C 34 30, 24 22, 20 12 C 17 4, 22 -2, 28 2 C 34 6, 36 16, 32 24 C 28 32, 22 34, 18 28 C 15 22, 18 14, 24 12"
                stroke="url(#nfHornGrad)"
                strokeWidth="2.5"
                fill="none"
                strokeLinecap="round"
              />
              <path
                d="M 35 36 C 30 28, 22 20, 22 12 C 22 7, 26 4, 29 6"
                stroke="url(#nfHornGrad)"
                strokeWidth="1.2"
                fill="none"
                strokeLinecap="round"
                opacity="0.6"
              />
              {/* Right horn */}
              <path
                d="M 52 36 C 56 28, 66 20, 70 10 C 73 2, 68 -4, 62 0 C 56 4, 54 14, 58 22 C 62 30, 68 32, 72 26 C 75 20, 72 12, 66 10"
                stroke="url(#nfHornGrad)"
                strokeWidth="2.5"
                fill="none"
                strokeLinecap="round"
              />
              <path
                d="M 55 34 C 60 26, 68 18, 68 10 C 68 5, 64 2, 61 4"
                stroke="url(#nfHornGrad)"
                strokeWidth="1.2"
                fill="none"
                strokeLinecap="round"
                opacity="0.6"
              />
              {/* Face */}
              <path
                d="M 34 38 C 32 42, 32 48, 36 52 L 38 58 C 40 64, 50 64, 52 58 L 54 52 C 58 48, 58 42, 56 38 C 54 34, 50 32, 45 32 C 40 32, 36 34, 34 38 Z"
                fill="url(#nfBodyGrad)"
                opacity="0.9"
              />
              {/* Eyes */}
              <circle cx="41" cy="44" r="1.5" fill="#e8c97a" opacity="0.9" />
              <circle cx="49" cy="44" r="1.5" fill="#e8c97a" opacity="0.9" />
            </svg>
          </div>

          {/* 404 */}
          <h1 className="font-[family-name:var(--font-heading)] text-7xl md:text-8xl text-czaah-gold tracking-wider mb-4">
            404
          </h1>

          {/* Subtitle */}
          <h2 className="font-[family-name:var(--font-heading)] text-2xl md:text-3xl text-czaah-white tracking-wide mb-4">
            Page Not Found
          </h2>

          {/* Description */}
          <p className="font-[family-name:var(--font-body)] text-czaah-muted text-base leading-relaxed mb-10">
            The page you&apos;re looking for doesn&apos;t exist or has been moved.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/"
              className="inline-block bg-czaah-gold text-czaah-black font-[family-name:var(--font-body)] font-semibold px-8 py-3 rounded hover:bg-czaah-gold-light transition-colors text-sm tracking-wide"
            >
              Return Home
            </Link>
            <Link
              href="/sectors"
              className="inline-block border border-czaah-gold/40 text-czaah-gold font-[family-name:var(--font-body)] font-semibold px-8 py-3 rounded hover:bg-czaah-gold/10 transition-colors text-sm tracking-wide"
            >
              Browse Sectors
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
