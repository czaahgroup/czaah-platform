'use client'
// @ts-nocheck

import { useEffect } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

export default function AboutPage() {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        {/* HERO */}
        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/About.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">About CZAAH</div>
              <h1 className="serif hero-enter hero-enter-delay-2">About <span className="gold">CZAAH.</span></h1>
              <p className="hero-enter hero-enter-delay-3">A diversified investment facilitation group headquartered in Islamabad with international reach across key markets &mdash; operating at the intersection of government, natural resources, and international capital.</p>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* MISSION & VISION */}
        <section className="section fade-in">
          <h2 className="serif">Mission &amp; <span className="gold">Vision.</span></h2>
          <p className="subtitle">The principles behind every decision, every partnership, and every investment we facilitate.</p>

          <div className="split" style={{ marginTop: 48 }}>
            <div className="fade-in-left">
              <h3 className="serif">Our <span className="gold">Mission</span></h3>
              <p>To serve as the institutional bridge between international capital and Pakistan&apos;s investment landscape &mdash; delivering access, transparency, and disciplined execution.</p>
              <p>Pakistan&apos;s markets hold extraordinary potential, but navigating them requires deep relationships, regulatory expertise, and permanent on-the-ground presence. CZAAH was built to provide all three.</p>
            </div>
            <div className="fade-in-right">
              <h3 className="serif">Our <span className="gold">Vision</span></h3>
              <p>To build the definitive private institution at the intersection of Pakistani government, natural resources, and international capital &mdash; in the tradition of groups like Tata, Al Futtaim, and Dangote in their respective markets.</p>
              <p>We are building an institution that outlasts any single deal, any single administration, and any single market cycle.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* OUR STRUCTURE */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">structure.</span></h2>
          <p className="subtitle">An institutional architecture designed for international investor confidence and operational efficiency.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>CZAAH Capital &amp; Ventures</h3>
              <p>SECP-registered holding company in Pakistan. Primary operating entity for government contracting, local deal facilitation, and on-the-ground investment management. Headquartered in Islamabad with reach across all provinces.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9632;</div>
              <h3>International Operations</h3>
              <p>Global reach across the Gulf, Europe, and Asia for international invoicing, multi-currency banking, commodities trading, and investor access. Structured for seamless cross-border transactions &mdash; trusted by Chinese, Gulf, and Western counterparties.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Deal-Level SPVs</h3>
              <p>Individual Special Purpose Vehicles created per major deal or project. Protects investors from cross-deal risk and allows sector-specific participation without exposure to the full group portfolio.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* WHY CHOOSE CZAAH */}
        <section className="section fade-in-left">
          <h2 className="serif">The CZAAH <span className="gold">difference.</span></h2>
          <p className="subtitle">In a market where access, relationships, and institutional discipline determine outcomes.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>Cross-Party Coverage</h4>
                <p>Relationships spanning PTI, PMLN, PPP. Business continuity regardless of which administration is in power. Your investments are protected through political transitions.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>On-the-Ground Presence</h4>
                <p>Headquartered in Islamabad with reach across all provinces. Physical due diligence, direct government access, real-time market intelligence &mdash; not remote advisory.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>Institutional Standards</h4>
                <p>International-grade compliance, transparent reporting, clean legal frameworks. We bring institutional discipline to an emerging market that demands it.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#8644;</div>
              <div>
                <h4>International Reach</h4>
                <p>Multi-market presence enables USD-denominated transactions, international investor comfort, and clean regulatory frameworks across key global markets.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">CZAAH at a <span className="gold">glance.</span></h2>

          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">13</div>
              <div className="label">Active sectors</div>
            </div>
            <div className="stat-item">
              <div className="number">4</div>
              <div className="label">International markets</div>
            </div>
            <div className="stat-item">
              <div className="number">6</div>
              <div className="label">Regional investor networks</div>
            </div>
            <div className="stat-item">
              <div className="number">3</div>
              <div className="label">Political administrations covered</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* CTA */}
        <section className="cta-banner fade-in">
          <h2 className="serif">The institutional partner for <span className="gold">Pakistan.</span></h2>
          <p>Market entry, capital deployment, or strategic partnership &mdash; one conversation is where it begins.</p>
          <Link href="/contact#contact-form" className="btn-gold">Request a Consultation &rarr;</Link>
        </section>

        <Footer />
      </div>
    </>
  )
}
