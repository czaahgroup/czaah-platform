'use client'

import { useEffect, useState, useCallback } from 'react'

interface SectorRef { id: string; name: string }
interface ServiceRef { id: string; name: string }

interface Product {
  id: string
  name: string
  slug: string
  description: string | null
  image_url: string | null
  sector_id: string | null
  service_id: string | null
  is_enquiry_enabled: boolean
  display_order: number
  is_active: boolean
  created_at: string
  sectors: SectorRef | null
  services: ServiceRef | null
}

interface FormData {
  name: string
  slug: string
  description: string
  image_url: string
  sector_id: string
  service_id: string
  is_enquiry_enabled: boolean
  display_order: number
  is_active: boolean
}

const empty: FormData = {
  name: '',
  slug: '',
  description: '',
  image_url: '',
  sector_id: '',
  service_id: '',
  is_enquiry_enabled: true,
  display_order: 0,
  is_active: true,
}

function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/-+/g, '-')
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [sectors, setSectors] = useState<SectorRef[]>([])
  const [services, setServices] = useState<ServiceRef[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [editId, setEditId] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState<FormData>(empty)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [autoSlug, setAutoSlug] = useState(true)

  const load = useCallback(async () => {
    try {
      const [prodRes, sectorRes, serviceRes] = await Promise.all([
        fetch('/api/admin/products'),
        fetch('/api/admin/sectors'),
        fetch('/api/admin/services'),
      ])

      if (!prodRes.ok) throw new Error('Failed to load products')
      const prodData = await prodRes.json()
      setProducts(prodData)

      if (sectorRes.ok) {
        const sectorData = await sectorRes.json()
        setSectors(sectorData.map((s: SectorRef & { slug?: string }) => ({ id: s.id, name: s.name })))
      }

      if (serviceRes.ok) {
        const serviceData = await serviceRes.json()
        setServices(serviceData.map((s: ServiceRef & { slug?: string }) => ({ id: s.id, name: s.name })))
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Load failed')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  function openAdd() {
    setEditId(null)
    setForm({ ...empty, display_order: products.length })
    setAutoSlug(true)
    setShowForm(true)
    setError(null)
  }

  function openEdit(product: Product) {
    setEditId(product.id)
    setForm({
      name: product.name,
      slug: product.slug,
      description: product.description || '',
      image_url: product.image_url || '',
      sector_id: product.sector_id || '',
      service_id: product.service_id || '',
      is_enquiry_enabled: product.is_enquiry_enabled,
      display_order: product.display_order,
      is_active: product.is_active,
    })
    setAutoSlug(false)
    setShowForm(true)
    setError(null)
  }

  function closeForm() {
    setShowForm(false)
    setEditId(null)
    setError(null)
  }

  function handleNameChange(name: string) {
    setForm((f) => ({
      ...f,
      name,
      slug: autoSlug ? slugify(name) : f.slug,
    }))
  }

  async function handleSave() {
    if (!form.name.trim() || !form.slug.trim()) {
      setError('Name and slug are required')
      return
    }
    setSaving(true)
    setError(null)

    try {
      const payload = {
        ...form,
        sector_id: form.sector_id || null,
        service_id: form.service_id || null,
      }

      const url = editId ? `/api/admin/products/${editId}` : '/api/admin/products'
      const method = editId ? 'PATCH' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Save failed')
      }

      closeForm()
      await load()
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Save failed')
    } finally {
      setSaving(false)
    }
  }

  async function handleToggle(product: Product) {
    try {
      const res = await fetch(`/api/admin/products/${product.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_active: !product.is_active }),
      })
      if (!res.ok) throw new Error('Toggle failed')
      await load()
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Toggle failed')
    }
  }

  async function handleDelete(id: string) {
    try {
      const res = await fetch(`/api/admin/products/${id}`, { method: 'DELETE' })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Delete failed')
      }
      setDeleteConfirm(null)
      await load()
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Delete failed')
      setDeleteConfirm(null)
    }
  }

  async function handleReorder(id: string, direction: 'up' | 'down') {
    const idx = products.findIndex((p) => p.id === id)
    if (idx < 0) return
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1
    if (swapIdx < 0 || swapIdx >= products.length) return

    const current = products[idx]
    const swap = products[swapIdx]

    try {
      await Promise.all([
        fetch(`/api/admin/products/${current.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ display_order: swap.display_order }),
        }),
        fetch(`/api/admin/products/${swap.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ display_order: current.display_order }),
        }),
      ])
      await load()
    } catch {
      setError('Reorder failed')
    }
  }

  if (loading) {
    return <div className="text-czaah-muted py-12 text-center">Loading products...</div>
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-[family-name:var(--font-heading)] text-2xl text-czaah-white">Products</h1>
        <button
          onClick={openAdd}
          className="bg-czaah-gold text-czaah-black font-semibold px-5 py-2 rounded text-sm hover:bg-czaah-gold/90 transition-colors"
        >
          + Add Product
        </button>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 mb-6">
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      {/* Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-czaah-card border border-czaah-border rounded-lg w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-czaah-border flex items-center justify-between sticky top-0 bg-czaah-card">
              <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
                {editId ? 'Edit Product' : 'Add Product'}
              </h2>
              <button onClick={closeForm} className="text-czaah-muted hover:text-czaah-white text-xl leading-none">&times;</button>
            </div>

            <div className="px-6 py-5 space-y-4">
              {error && (
                <div className="bg-red-500/10 border border-red-500/20 rounded px-3 py-2">
                  <p className="text-sm text-red-400">{error}</p>
                </div>
              )}

              <div>
                <label className="block text-sm text-czaah-muted mb-1.5">Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-czaah-white placeholder:text-czaah-muted-dim text-sm"
                  placeholder="e.g. Commercial Property Fund"
                />
              </div>

              <div>
                <label className="block text-sm text-czaah-muted mb-1.5">Slug *</label>
                <input
                  type="text"
                  value={form.slug}
                  onChange={(e) => { setAutoSlug(false); setForm((f) => ({ ...f, slug: e.target.value })) }}
                  className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-czaah-white placeholder:text-czaah-muted-dim text-sm"
                  placeholder="commercial-property-fund"
                />
              </div>

              <div>
                <label className="block text-sm text-czaah-muted mb-1.5">Description</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-czaah-white placeholder:text-czaah-muted-dim text-sm resize-none h-20"
                  placeholder="Brief description..."
                />
              </div>

              <div>
                <label className="block text-sm text-czaah-muted mb-1.5">Image URL</label>
                <input
                  type="text"
                  value={form.image_url}
                  onChange={(e) => setForm((f) => ({ ...f, image_url: e.target.value }))}
                  className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-czaah-white placeholder:text-czaah-muted-dim text-sm"
                  placeholder="https://..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-czaah-muted mb-1.5">Sector</label>
                  <select
                    value={form.sector_id}
                    onChange={(e) => setForm((f) => ({ ...f, sector_id: e.target.value }))}
                    className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-czaah-white text-sm"
                  >
                    <option value="">None</option>
                    {sectors.map((s) => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-czaah-muted mb-1.5">Service</label>
                  <select
                    value={form.service_id}
                    onChange={(e) => setForm((f) => ({ ...f, service_id: e.target.value }))}
                    className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-czaah-white text-sm"
                  >
                    <option value="">None</option>
                    {services.map((s) => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-czaah-muted mb-1.5">Display Order</label>
                  <input
                    type="number"
                    value={form.display_order}
                    onChange={(e) => setForm((f) => ({ ...f, display_order: parseInt(e.target.value) || 0 }))}
                    className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-czaah-white text-sm"
                  />
                </div>
                <div className="flex flex-col justify-end gap-2 pb-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={form.is_active}
                      onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
                      className="w-4 h-4 rounded border-czaah-border accent-czaah-gold"
                    />
                    <span className="text-sm text-czaah-muted">Active</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={form.is_enquiry_enabled}
                      onChange={(e) => setForm((f) => ({ ...f, is_enquiry_enabled: e.target.checked }))}
                      className="w-4 h-4 rounded border-czaah-border accent-czaah-gold"
                    />
                    <span className="text-sm text-czaah-muted">Enquiries Enabled</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 border-t border-czaah-border flex gap-3 justify-end sticky bottom-0 bg-czaah-card">
              <button
                onClick={closeForm}
                className="px-4 py-2 rounded text-sm text-czaah-muted hover:text-czaah-white border border-czaah-border hover:border-czaah-gold/50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="bg-czaah-gold text-czaah-black font-semibold px-5 py-2 rounded text-sm hover:bg-czaah-gold/90 transition-colors disabled:opacity-50"
              >
                {saving ? 'Saving...' : editId ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-czaah-card border border-czaah-border rounded-lg w-full max-w-sm mx-4 p-6">
            <h3 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white mb-2">Confirm Delete</h3>
            <p className="text-sm text-czaah-muted mb-6">
              Are you sure you want to delete this product? This action cannot be undone.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 rounded text-sm text-czaah-muted hover:text-czaah-white border border-czaah-border transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="bg-czaah-danger text-white font-semibold px-5 py-2 rounded text-sm hover:bg-czaah-danger/80 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      {products.length === 0 ? (
        <div className="bg-czaah-card border border-czaah-border rounded-lg px-6 py-16 text-center">
          <p className="text-czaah-muted">No products yet. Add your first product to get started.</p>
        </div>
      ) : (
        <div className="bg-czaah-card border border-czaah-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-czaah-border">
                  <th className="text-left px-5 py-3 text-czaah-muted font-medium text-xs uppercase tracking-wider">Order</th>
                  <th className="text-left px-5 py-3 text-czaah-muted font-medium text-xs uppercase tracking-wider">Name</th>
                  <th className="text-left px-5 py-3 text-czaah-muted font-medium text-xs uppercase tracking-wider">Slug</th>
                  <th className="text-left px-5 py-3 text-czaah-muted font-medium text-xs uppercase tracking-wider">Sector</th>
                  <th className="text-left px-5 py-3 text-czaah-muted font-medium text-xs uppercase tracking-wider">Service</th>
                  <th className="text-left px-5 py-3 text-czaah-muted font-medium text-xs uppercase tracking-wider">Status</th>
                  <th className="text-right px-5 py-3 text-czaah-muted font-medium text-xs uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product, idx) => (
                  <tr key={product.id} className="border-b border-czaah-border/50 hover:bg-czaah-black/30 transition-colors">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleReorder(product.id, 'up')}
                          disabled={idx === 0}
                          className="text-czaah-muted hover:text-czaah-white disabled:opacity-20 transition-colors p-0.5"
                          title="Move up"
                        >
                          &#9650;
                        </button>
                        <button
                          onClick={() => handleReorder(product.id, 'down')}
                          disabled={idx === products.length - 1}
                          className="text-czaah-muted hover:text-czaah-white disabled:opacity-20 transition-colors p-0.5"
                          title="Move down"
                        >
                          &#9660;
                        </button>
                        <span className="text-czaah-muted-dim ml-1">{product.display_order}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span className="text-czaah-white font-medium">{product.name}</span>
                      {product.is_enquiry_enabled && (
                        <span className="ml-2 text-[10px] bg-czaah-gold/20 text-czaah-gold px-1.5 py-0.5 rounded">ENQ</span>
                      )}
                    </td>
                    <td className="px-5 py-3 text-czaah-muted-dim font-mono text-xs">{product.slug}</td>
                    <td className="px-5 py-3 text-czaah-muted text-xs">{product.sectors?.name || '--'}</td>
                    <td className="px-5 py-3 text-czaah-muted text-xs">{product.services?.name || '--'}</td>
                    <td className="px-5 py-3">
                      <button
                        onClick={() => handleToggle(product)}
                        className={`text-xs px-2.5 py-1 rounded transition-colors ${
                          product.is_active
                            ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                            : 'bg-neutral-500/20 text-neutral-400 hover:bg-neutral-500/30'
                        }`}
                      >
                        {product.is_active ? 'Active' : 'Inactive'}
                      </button>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEdit(product)}
                          className="text-xs text-czaah-gold hover:text-czaah-gold/80 transition-colors px-2 py-1"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(product.id)}
                          className="text-xs text-czaah-danger/70 hover:text-czaah-danger transition-colors px-2 py-1"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
