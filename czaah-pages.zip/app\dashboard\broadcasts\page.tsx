'use client'

import { useEffect, useState, useCallback } from 'react'

interface Broadcast {
  id: string
  title: string
  content: string
  sent_by: string
  target_roles: string[]
  sent_at: string
  read_count: number
  total_targeted: number
  is_read: boolean
  sender_name: string
}

export default function DashboardBroadcastsPage() {
  const [broadcasts, setBroadcasts] = useState<Broadcast[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const loadBroadcasts = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/broadcasts')
      if (res.ok) {
        const json = await res.json()
        setBroadcasts(json.data || [])
      }
    } catch (err) {
      console.error('Failed to load broadcasts:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadBroadcasts()
  }, [loadBroadcasts])

  async function handleExpand(broadcastId: string) {
    setExpandedId((prev) => (prev === broadcastId ? null : broadcastId))

    // Mark as read
    const bc = broadcasts.find((b) => b.id === broadcastId)
    if (bc && !bc.is_read) {
      try {
        await fetch(`/api/admin/broadcasts/${broadcastId}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({}),
        })
        loadBroadcasts()
      } catch (err) {
        console.error('Failed to mark broadcast as read:', err)
      }
    }
  }

  function formatDate(dateStr: string) {
    const d = new Date(dateStr)
    return d.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' })
  }

  function formatTime(dateStr: string) {
    const d = new Date(dateStr)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24))
    if (diffDays === 0) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    if (diffDays === 1) return 'Yesterday'
    if (diffDays < 7) return d.toLocaleDateString([], { weekday: 'short' })
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' })
  }

  if (loading) {
    return (
      <div>
        <h1 style={{
          fontFamily: "'Cinzel', serif",
          fontSize: '24px',
          color: '#fff',
          margin: '0 0 8px 0',
          letterSpacing: '2px',
        }}>
          Broadcasts
        </h1>
        <p style={{
          fontFamily: "'Raleway', sans-serif",
          fontSize: '13px',
          color: 'rgba(255,255,255,0.4)',
          margin: '0 0 30px 0',
        }}>
          Loading broadcasts...
        </p>
      </div>
    )
  }

  return (
    <div>
      <h1 style={{
        fontFamily: "'Cinzel', serif",
        fontSize: '24px',
        color: '#fff',
        margin: '0 0 8px 0',
        letterSpacing: '2px',
      }}>
        Broadcasts
      </h1>
      <p style={{
        fontFamily: "'Raleway', sans-serif",
        fontSize: '13px',
        color: 'rgba(255,255,255,0.4)',
        margin: '0 0 30px 0',
      }}>
        Important announcements from the CZAAH team
      </p>

      {broadcasts.length === 0 ? (
        <div style={{
          background: '#080808',
          borderRadius: '8px',
          border: '1px solid rgba(255,255,255,0.06)',
          padding: '60px 40px',
          textAlign: 'center',
        }}>
          <p style={{
            fontFamily: "'Cinzel', serif",
            fontSize: '16px',
            color: 'rgba(255,255,255,0.5)',
            marginBottom: '8px',
          }}>
            No broadcasts
          </p>
          <p style={{
            fontFamily: "'Raleway', sans-serif",
            fontSize: '12px',
            color: 'rgba(255,255,255,0.3)',
          }}>
            Announcements from the team will appear here
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {broadcasts.map((bc) => {
            const isExpanded = expandedId === bc.id
            return (
              <div
                key={bc.id}
                style={{
                  background: '#080808',
                  borderRadius: '8px',
                  border: '1px solid rgba(255,255,255,0.06)',
                  borderLeft: !bc.is_read ? '3px solid #C9A84C' : '3px solid transparent',
                  overflow: 'hidden',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                }}
                onClick={() => handleExpand(bc.id)}
              >
                {/* Header */}
                <div style={{
                  padding: '18px 20px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
                      <h3 style={{
                        fontFamily: "'Cinzel', serif",
                        fontSize: '15px',
                        color: '#fff',
                        margin: 0,
                        letterSpacing: '0.5px',
                        fontWeight: bc.is_read ? 400 : 600,
                      }}>
                        {bc.title}
                      </h3>
                      {!bc.is_read && (
                        <span style={{
                          background: 'rgba(201,168,76,0.2)',
                          color: '#C9A84C',
                          fontSize: '9px',
                          fontWeight: 700,
                          padding: '2px 8px',
                          borderRadius: '10px',
                          fontFamily: "'Raleway', sans-serif",
                          letterSpacing: '1px',
                          textTransform: 'uppercase',
                          flexShrink: 0,
                        }}>
                          NEW
                        </span>
                      )}
                    </div>
                    {!isExpanded && (
                      <p style={{
                        fontFamily: "'Raleway', sans-serif",
                        fontSize: '12px',
                        color: 'rgba(255,255,255,0.4)',
                        margin: '4px 0 0 0',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}>
                        {bc.content.substring(0, 120)}{bc.content.length > 120 ? '...' : ''}
                      </p>
                    )}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '4px', marginLeft: '16px', flexShrink: 0 }}>
                    <span style={{
                      fontFamily: "'Raleway', sans-serif",
                      fontSize: '11px',
                      color: 'rgba(255,255,255,0.3)',
                    }}>
                      {formatTime(bc.sent_at)}
                    </span>
                    <span style={{
                      fontFamily: "'Raleway', sans-serif",
                      fontSize: '10px',
                      color: 'rgba(255,255,255,0.25)',
                    }}>
                      from {bc.sender_name}
                    </span>
                  </div>
                </div>

                {/* Expanded Content */}
                {isExpanded && (
                  <div style={{
                    padding: '0 20px 20px',
                    borderTop: '1px solid rgba(255,255,255,0.04)',
                  }}>
                    <div style={{
                      padding: '16px',
                      background: 'rgba(0,0,0,0.3)',
                      borderRadius: '6px',
                      marginTop: '16px',
                    }}>
                      <p style={{
                        fontFamily: "'Raleway', sans-serif",
                        fontSize: '14px',
                        color: 'rgba(255,255,255,0.8)',
                        margin: 0,
                        lineHeight: 1.7,
                        whiteSpace: 'pre-wrap',
                      }}>
                        {bc.content}
                      </p>
                    </div>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      marginTop: '12px',
                    }}>
                      <span style={{
                        fontFamily: "'Raleway', sans-serif",
                        fontSize: '11px',
                        color: 'rgba(255,255,255,0.3)',
                      }}>
                        Sent on {formatDate(bc.sent_at)}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
