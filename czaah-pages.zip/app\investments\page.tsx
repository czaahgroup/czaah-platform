'use client'
// @ts-nocheck

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

export default function InvestmentsPage() {
  const [activeFilter, setActiveFilter] = useState('all')
  const dealsRef = useRef<HTMLDivElement>(null)

  const deals = [
    { sector: 'minerals' },
    { sector: 'minerals' },
    { sector: 'realestate' },
    { sector: 'technology' },
    { sector: 'agriculture' },
    { sector: 'pharma' },
    { sector: 'textiles' },
    { sector: 'construction' },
    { sector: 'tourism' },
    { sector: 'minerals' },
  ]

  const visibleCount = activeFilter === 'all'
    ? deals.length
    : deals.filter(d => d.sector === activeFilter).length

  function filterDeals(filter: string) {
    setActiveFilter(filter)
  }

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible') })
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' })
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: `
    .iv-headline { text-align: center; margin-bottom: 12px; }
    .iv-headline h2 { font-family: 'Cinzel', serif; font-size: clamp(28px, 4vw, 42px); color: var(--white); }
    .iv-headline p { font-size: 15px; color: var(--white-muted); line-height: 1.7; max-width: 700px; margin: 16px auto 0; }

    /* Sector filter bar */
    .iv-filters { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-bottom: 40px; }
    .iv-filter {
      padding: 8px 18px; border: 1px solid var(--black-border); background: var(--black-card);
      border-radius: 20px; color: var(--white-muted); font-family: 'Raleway', sans-serif;
      font-size: 13px; cursor: pointer; transition: all 0.3s;
    }
    .iv-filter:hover { border-color: var(--gold-dim); color: var(--white); }
    .iv-filter.active { background: var(--gold); border-color: var(--gold); color: var(--black); font-weight: 500; }

    /* Deal cards */
    .iv-deals { display: flex; flex-direction: column; gap: 20px; }

    .iv-deal {
      display: grid; grid-template-columns: 1fr 340px;
      background: var(--black-card); border: 1px solid var(--black-border);
      border-radius: 10px; overflow: hidden;
      transition: all 0.4s var(--ease-smooth);
    }
    .iv-deal:hover { border-color: rgba(201, 168, 76, 0.35); box-shadow: 0 8px 40px rgba(201, 168, 76, 0.06); }
    .iv-deal.hidden { display: none; }

    .iv-deal-main { padding: 32px; display: flex; flex-direction: column; }
    .iv-deal-header { display: flex; align-items: flex-start; gap: 16px; margin-bottom: 16px; }
    .iv-deal-icon {
      width: 48px; height: 48px; border-radius: 10px; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      font-size: 22px; background: var(--gold-dim); color: var(--gold);
    }
    .iv-deal-header-text { flex: 1; }
    .iv-deal-sector { font-size: 11px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: var(--gold); margin-bottom: 4px; }
    .iv-deal-title { font-family: 'Cinzel', serif; font-size: 22px; font-weight: 600; color: var(--white); line-height: 1.3; }
    .iv-deal-status {
      padding: 5px 12px; border-radius: 4px; font-size: 10px; font-weight: 600;
      letter-spacing: 0.08em; text-transform: uppercase; white-space: nowrap; flex-shrink: 0; align-self: flex-start; margin-top: 2px;
    }
    .iv-status-open { background: rgba(76, 175, 80, 0.15); color: #4CAF50; border: 1px solid rgba(76, 175, 80, 0.3); }
    .iv-status-limited { background: rgba(201, 168, 76, 0.15); color: var(--gold); border: 1px solid rgba(201, 168, 76, 0.3); }
    .iv-status-coming { background: rgba(255, 255, 255, 0.08); color: var(--white-muted); border: 1px solid rgba(255, 255, 255, 0.15); }

    .iv-deal-desc { font-size: 14px; line-height: 1.7; color: var(--white-muted); margin-bottom: 20px; flex: 1; }

    .iv-deal-tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 20px; }
    .iv-deal-tag { padding: 4px 10px; border-radius: 3px; font-size: 10px; font-weight: 500; letter-spacing: 0.05em; text-transform: uppercase; background: rgba(255, 255, 255, 0.06); color: var(--white-dim); }

    .iv-deal-cta { font-size: 13px; font-weight: 500; color: var(--gold); text-decoration: none; display: inline-flex; align-items: center; gap: 6px; transition: all 0.3s; }
    .iv-deal-cta:hover { gap: 10px; color: var(--gold-light); }

    /* Deal metrics panel (right side) */
    .iv-deal-metrics {
      background: var(--black-elevated); padding: 32px; display: flex; flex-direction: column;
      justify-content: center; border-left: 1px solid var(--black-border);
    }
    .iv-metric { margin-bottom: 20px; }
    .iv-metric:last-child { margin-bottom: 0; }
    .iv-metric-label { font-size: 10px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: var(--white-muted); margin-bottom: 4px; }
    .iv-metric-value { font-size: 20px; font-weight: 600; color: var(--white); font-family: 'Raleway', sans-serif; }
    .iv-metric-value.gold { color: var(--gold); }
    .iv-metric-note { font-size: 11px; color: var(--white-muted); margin-top: 2px; }

    .iv-metric-bar { height: 4px; background: var(--black-border); border-radius: 2px; margin-top: 8px; overflow: hidden; }
    .iv-metric-bar-fill { height: 100%; border-radius: 2px; background: linear-gradient(90deg, var(--gold), #E8D48B); }

    /* Why Pakistan -- enhanced */
    .iv-thesis-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1px; background: var(--black-border); border: 1px solid var(--black-border); border-radius: 10px; overflow: hidden; margin-top: 40px; }
    .iv-thesis-card { background: var(--black-card); padding: 32px 24px; text-align: center; transition: all 0.3s; }
    .iv-thesis-card:hover { background: var(--black-elevated); }
    .iv-thesis-number { font-size: 36px; font-weight: 700; color: var(--gold); font-family: 'Cinzel', serif; margin-bottom: 4px; }
    .iv-thesis-label { font-size: 12px; color: var(--white-muted); line-height: 1.5; text-transform: uppercase; letter-spacing: 0.06em; }
    .iv-thesis-desc { font-size: 12px; color: var(--white-dim); margin-top: 8px; line-height: 1.5; }

    /* Investor profiles -- enhanced */
    .iv-profiles { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 32px; }
    .iv-profile {
      background: var(--black-card); border: 1px solid var(--black-border); border-radius: 10px;
      padding: 32px; transition: all 0.3s; position: relative; overflow: hidden;
    }
    .iv-profile::before {
      content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
      background: linear-gradient(90deg, var(--gold), transparent); opacity: 0; transition: opacity 0.3s;
    }
    .iv-profile:hover { border-color: rgba(201, 168, 76, 0.3); }
    .iv-profile:hover::before { opacity: 1; }
    .iv-profile-icon { font-size: 28px; margin-bottom: 16px; display: block; }
    .iv-profile h4 { font-family: 'Cinzel', serif; font-size: 18px; color: var(--white); margin-bottom: 8px; }
    .iv-profile p { font-size: 13px; color: var(--white-muted); line-height: 1.7; margin-bottom: 12px; }
    .iv-profile-structures { display: flex; gap: 6px; flex-wrap: wrap; }
    .iv-profile-tag { padding: 3px 8px; border-radius: 3px; font-size: 10px; font-weight: 500; letter-spacing: 0.05em; text-transform: uppercase; background: var(--gold-dim); color: var(--gold); }

    /* Investment approach -- process steps */
    .iv-process { display: grid; grid-template-columns: repeat(5, 1fr); gap: 1px; background: var(--black-border); border: 1px solid var(--black-border); border-radius: 10px; overflow: hidden; margin-top: 32px; }
    .iv-process-step { background: var(--black-card); padding: 28px 20px; text-align: center; transition: all 0.3s; position: relative; }
    .iv-process-step:hover { background: var(--black-elevated); }
    .iv-process-num { font-size: 32px; font-weight: 700; color: var(--gold); font-family: 'Cinzel', serif; margin-bottom: 8px; }
    .iv-process-name { font-size: 14px; font-weight: 600; color: var(--white); margin-bottom: 6px; }
    .iv-process-desc { font-size: 12px; color: var(--white-muted); line-height: 1.5; }
    .iv-process-step::after {
      content: '\\2192'; position: absolute; right: -8px; top: 50%; transform: translateY(-50%);
      font-size: 16px; color: var(--gold); z-index: 2;
    }
    .iv-process-step:last-child::after { display: none; }

    /* Count indicator */
    .iv-count { text-align: center; margin-bottom: 24px; font-size: 13px; color: var(--white-muted); }
    .iv-count span { color: var(--gold); font-weight: 500; }

    @media (max-width: 1024px) {
      .iv-deal { grid-template-columns: 1fr; }
      .iv-deal-metrics { border-left: none; border-top: 1px solid var(--black-border); flex-direction: row; flex-wrap: wrap; gap: 20px; }
      .iv-metric { margin-bottom: 0; flex: 1; min-width: 120px; }
      .iv-thesis-grid { grid-template-columns: repeat(2, 1fr); }
      .iv-process { grid-template-columns: repeat(3, 1fr); }
      .iv-process-step::after { display: none; }
    }
    @media (max-width: 768px) {
      .iv-deal-main { padding: 24px; }
      .iv-deal-metrics { padding: 24px; }
      .iv-profiles { grid-template-columns: 1fr; }
      .iv-thesis-grid { grid-template-columns: 1fr 1fr; }
      .iv-process { grid-template-columns: 1fr 1fr; }
      .iv-deal-header { flex-wrap: wrap; }
    }
    @media (max-width: 480px) {
      .iv-thesis-grid { grid-template-columns: 1fr; }
      .iv-process { grid-template-columns: 1fr; }
    }
      ` }} />
      <Navbar />
      <div className="page-wrap">

        {/* HERO */}
        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Investments.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <Link href="/" className="back-link hero-enter">&larr; Back to Overview</Link>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Investment Opportunities</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Investment <span className="gold">Opportunities.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Pre-vetted, legally structured opportunities across Pakistan&apos;s highest-growth sectors &mdash; each assessed for feasibility, regulatory compliance, and investor-ready execution.</p>
              <Link href="/contact#contact-form" className="btn-gold hero-enter hero-enter-delay-4">View Opportunities &rarr;</Link>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* FEATURED DEAL FLOW */}
        <section className="section" id="iv-dealflow">
          <div className="iv-headline">
            <h2 className="serif">Active deal <span className="gold">flow.</span></h2>
            <p>Pre-vetted, structured investment opportunities across Pakistan&apos;s highest-growth sectors. Each opportunity is assessed for regulatory compliance, financial viability, and defined exit strategy.</p>
          </div>

          <div className="iv-filters">
            <button className={`iv-filter${activeFilter === 'all' ? ' active' : ''}`} onClick={() => filterDeals('all')}>All Sectors</button>
            <button className={`iv-filter${activeFilter === 'minerals' ? ' active' : ''}`} onClick={() => filterDeals('minerals')}>Minerals</button>
            <button className={`iv-filter${activeFilter === 'realestate' ? ' active' : ''}`} onClick={() => filterDeals('realestate')}>Real Estate</button>
            <button className={`iv-filter${activeFilter === 'technology' ? ' active' : ''}`} onClick={() => filterDeals('technology')}>Technology</button>
            <button className={`iv-filter${activeFilter === 'agriculture' ? ' active' : ''}`} onClick={() => filterDeals('agriculture')}>Agriculture</button>
            <button className={`iv-filter${activeFilter === 'pharma' ? ' active' : ''}`} onClick={() => filterDeals('pharma')}>Pharma</button>
            <button className={`iv-filter${activeFilter === 'textiles' ? ' active' : ''}`} onClick={() => filterDeals('textiles')}>Textiles</button>
            <button className={`iv-filter${activeFilter === 'construction' ? ' active' : ''}`} onClick={() => filterDeals('construction')}>Construction</button>
            <button className={`iv-filter${activeFilter === 'tourism' ? ' active' : ''}`} onClick={() => filterDeals('tourism')}>Tourism</button>
          </div>

          <div className="iv-count">Showing <span>{visibleCount}</span> of 10 opportunities</div>

          <div className="iv-deals" ref={dealsRef}>

            {/* PLACER GOLD */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'minerals' ? ' hidden' : ''}`} data-sector="minerals">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9670;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Minerals &amp; Mining</div>
                    <div className="iv-deal-title">Indus-K Placer Gold Project &mdash; Riverine Gold Extraction</div>
                  </div>
                  <span className="iv-deal-status iv-status-open">Open</span>
                </div>
                <p className="iv-deal-desc">Placer gold extraction from Pakistan&apos;s Indus river system using indigenously engineered Indus-K processing units. For millennia, Himalayan, Karakoram, and Hindukush floods have deposited gold-bearing sediments across Pakistan&apos;s riverbeds. Each Indus-K unit processes 70 tons of material daily, yielding 25 grams of 22-karat gold. Operations deploy in scalable 10-unit sectors producing 250 grams of gold per sector daily. Geophysical and geochemical studies have identified thousands of high-yield hotspots. SPV-structured with 50/50 profit share after OPEX and projected full CAPEX recovery within 36 months.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">SPV Structure</span>
                  <span className="iv-deal-tag">Placer Gold</span>
                  <span className="iv-deal-tag">Indigenous Technology</span>
                  <span className="iv-deal-tag">Indus River System</span>
                </div>
                <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                  <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
                  <a href="/CZAAH-IndusK-Gold.pdf" download className="iv-deal-cta" style={{ background: 'rgba(201,168,76,0.1)', border: '1px solid var(--gold)', color: 'var(--gold)' }}>&#8681; Download Project PDF</a>
                </div>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Per Sector</div>
                  <div className="iv-metric-value gold">~$650K</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Total 10-Year Return</div>
                  <div className="iv-metric-value">$2.43M</div>
                  <div className="iv-metric-note">3.74x profit multiple</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Payback Period</div>
                  <div className="iv-metric-value">~2.7 years</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '50%' }}></div></div>
                  <div className="iv-metric-note">Medium &mdash; Proven resource, operational tech</div>
                </div>
              </div>
            </div>

            {/* MINERALS */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'minerals' ? ' hidden' : ''}`} data-sector="minerals">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9670;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Minerals &amp; Mining</div>
                    <div className="iv-deal-title">Copper-Gold Exploration Licenses &mdash; Balochistan</div>
                  </div>
                  <span className="iv-deal-status iv-status-open">Open</span>
                </div>
                <p className="iv-deal-desc">Joint venture opportunity for copper-gold exploration across three licensed blocks in the Chagai District, Balochistan &mdash; the same geological belt as Reko Diq. CZAAH holds facilitation rights with the provincial Mines &amp; Minerals Department. Geological surveys completed; partner sought for drill programme financing and operational execution.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Joint Venture</span>
                  <span className="iv-deal-tag">Exploration Stage</span>
                  <span className="iv-deal-tag">Balochistan</span>
                  <span className="iv-deal-tag">Provincial License</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$5M &ndash; $25M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Projected IRR</div>
                  <div className="iv-metric-value">25&ndash;40%</div>
                  <div className="iv-metric-note">Post-discovery valuation uplift</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Timeline to Discovery</div>
                  <div className="iv-metric-value">18&ndash;36 months</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '75%' }}></div></div>
                  <div className="iv-metric-note">High &mdash; Exploration stage</div>
                </div>
              </div>
            </div>

            {/* REAL ESTATE */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'realestate' ? ' hidden' : ''}`} data-sector="realestate">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#8962;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Real Estate</div>
                    <div className="iv-deal-title">CPEC Industrial Plots &mdash; Rashakai &amp; Allama Iqbal SEZ</div>
                  </div>
                  <span className="iv-deal-status iv-status-limited">Limited</span>
                </div>
                <p className="iv-deal-desc">Pre-allocated industrial plots in Pakistan&apos;s most advanced Special Economic Zones with 10-year tax holidays, customs duty exemptions, and one-window regulatory clearance. Ideal for manufacturing companies seeking to establish Pakistan operations, or investors seeking land appreciation with guaranteed tenant demand from Chinese and local firms.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Direct Purchase</span>
                  <span className="iv-deal-tag">SEZ Tax Holidays</span>
                  <span className="iv-deal-tag">KPK &amp; Punjab</span>
                  <span className="iv-deal-tag">CPEC Corridor</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$500K &ndash; $10M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Rental Yield</div>
                  <div className="iv-metric-value">6&ndash;8%</div>
                  <div className="iv-metric-note">+ 15&ndash;25% capital appreciation p.a.</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Tax Holiday</div>
                  <div className="iv-metric-value">10 years</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '35%' }}></div></div>
                  <div className="iv-metric-note">Low-Medium &mdash; Government-backed SEZ</div>
                </div>
              </div>
            </div>

            {/* TECHNOLOGY */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'technology' ? ' hidden' : ''}`} data-sector="technology">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9881;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Technology &amp; IT</div>
                    <div className="iv-deal-title">IT Export Company Acquisition &mdash; Staff Augmentation Platform</div>
                  </div>
                  <span className="iv-deal-status iv-status-open">Open</span>
                </div>
                <p className="iv-deal-desc">Acquisition opportunity in a profitable Pakistani IT services company with 150+ engineers, established US/EU client base, and $2M+ annual revenue. Dollar-denominated revenue with PKR cost base creates exceptional margin structure. Special Technology Zone registration provides additional tax benefits.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Acquisition</span>
                  <span className="iv-deal-tag">USD Revenue</span>
                  <span className="iv-deal-tag">Lahore STZ</span>
                  <span className="iv-deal-tag">Profitable</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$2M &ndash; $5M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Revenue Multiple</div>
                  <div className="iv-metric-value">1.5&ndash;2.5x</div>
                  <div className="iv-metric-note">Current annual revenue</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">EBITDA Margin</div>
                  <div className="iv-metric-value">30&ndash;35%</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '40%' }}></div></div>
                  <div className="iv-metric-note">Medium &mdash; Established business</div>
                </div>
              </div>
            </div>

            {/* AGRICULTURE */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'agriculture' ? ' hidden' : ''}`} data-sector="agriculture">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9752;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Agriculture</div>
                    <div className="iv-deal-title">Cold Chain &amp; Food Processing &mdash; Punjab Agri Corridor</div>
                  </div>
                  <span className="iv-deal-status iv-status-open">Open</span>
                </div>
                <p className="iv-deal-desc">Greenfield cold storage and food processing facility targeting Pakistan&apos;s $5B+ agricultural export market. 30&ndash;40% of Pakistani produce is wasted due to inadequate cold chain infrastructure &mdash; addressing this gap with modern blast freezing, controlled atmosphere storage, and export-grade packaging for rice, mangoes, citrus, and dairy.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Greenfield</span>
                  <span className="iv-deal-tag">Export-Oriented</span>
                  <span className="iv-deal-tag">Punjab</span>
                  <span className="iv-deal-tag">Infrastructure Gap</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$3M &ndash; $15M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Projected IRR</div>
                  <div className="iv-metric-value">18&ndash;28%</div>
                  <div className="iv-metric-note">Year 3 onwards at capacity</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Payback Period</div>
                  <div className="iv-metric-value">3&ndash;4 years</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '50%' }}></div></div>
                  <div className="iv-metric-note">Medium &mdash; Proven demand, new build</div>
                </div>
              </div>
            </div>

            {/* PHARMA */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'pharma' ? ' hidden' : ''}`} data-sector="pharma">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9764;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Pharmaceuticals</div>
                    <div className="iv-deal-title">Generic Drug Manufacturing JV &mdash; WHO GMP Certified Facility</div>
                  </div>
                  <span className="iv-deal-status iv-status-limited">Limited</span>
                </div>
                <p className="iv-deal-desc">Joint venture with an established Pakistani pharmaceutical manufacturer (WHO GMP certified, 800+ product registrations) seeking capital for capacity expansion and Africa/Central Asia export push. Factory operational, DRAP licenses active, distribution networks in place. Partner sought for $8M expansion programme to triple export capacity.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Joint Venture</span>
                  <span className="iv-deal-tag">WHO GMP</span>
                  <span className="iv-deal-tag">Export Expansion</span>
                  <span className="iv-deal-tag">Operational</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$5M &ndash; $12M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Market Growth</div>
                  <div className="iv-metric-value">12% p.a.</div>
                  <div className="iv-metric-note">$4B+ domestic market</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Export Target</div>
                  <div className="iv-metric-value">$25M by Y3</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '35%' }}></div></div>
                  <div className="iv-metric-note">Low-Medium &mdash; Operational facility</div>
                </div>
              </div>
            </div>

            {/* TEXTILES */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'textiles' ? ' hidden' : ''}`} data-sector="textiles">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#10070;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Textiles &amp; Trade</div>
                    <div className="iv-deal-title">Denim Export Trading House &mdash; GSP+ EU Market Access</div>
                  </div>
                  <span className="iv-deal-status iv-status-open">Open</span>
                </div>
                <p className="iv-deal-desc">Trading company aggregating Pakistani denim production for European buyers under GSP+ zero-duty access. Partner mills in Faisalabad and Lahore with combined capacity of 5M metres/month. OEKO-TEX and GOTS certified supply chain. Seeking investment to scale order book and establish EU distribution presence.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Trading Company</span>
                  <span className="iv-deal-tag">GSP+ Access</span>
                  <span className="iv-deal-tag">Internationally Structured</span>
                  <span className="iv-deal-tag">USD Revenue</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$1M &ndash; $5M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Trading Margin</div>
                  <div className="iv-metric-value">8&ndash;12%</div>
                  <div className="iv-metric-note">On USD-denominated orders</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Order Pipeline</div>
                  <div className="iv-metric-value">$15M+</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '30%' }}></div></div>
                  <div className="iv-metric-note">Low &mdash; Established mills, confirmed buyers</div>
                </div>
              </div>
            </div>

            {/* CONSTRUCTION */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'construction' ? ' hidden' : ''}`} data-sector="construction">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9960;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Construction</div>
                    <div className="iv-deal-title">Commercial Tower Development &mdash; Blue Area, Islamabad</div>
                  </div>
                  <span className="iv-deal-status iv-status-limited">Limited</span>
                </div>
                <p className="iv-deal-desc">Grade-A commercial tower in Islamabad&apos;s prime business district. 18-storey mixed-use development with pre-leasing interest from multinational tenants and embassy offices. CDA-approved plans, foundation works underway. Seeking co-investment for construction completion and anchor tenant fit-out.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Co-Investment</span>
                  <span className="iv-deal-tag">CDA Approved</span>
                  <span className="iv-deal-tag">Pre-Leased 40%</span>
                  <span className="iv-deal-tag">Blue Area</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$10M &ndash; $30M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Rental Yield</div>
                  <div className="iv-metric-value">7&ndash;9%</div>
                  <div className="iv-metric-note">Grade-A Islamabad rates</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Completion</div>
                  <div className="iv-metric-value">24 months</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '40%' }}></div></div>
                  <div className="iv-metric-note">Medium &mdash; Under construction, pre-leased</div>
                </div>
              </div>
            </div>

            {/* TOURISM */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'tourism' ? ' hidden' : ''}`} data-sector="tourism">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9978;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Tourism &amp; Hospitality</div>
                    <div className="iv-deal-title">Boutique Hotel &amp; Eco-Lodge &mdash; Hunza Valley</div>
                  </div>
                  <span className="iv-deal-status iv-status-coming">Coming Soon</span>
                </div>
                <p className="iv-deal-desc">Boutique hospitality development in Pakistan&apos;s most in-demand tourism destination. 40-room eco-lodge with panoramic Rakaposhi views, designed to international boutique hotel standards. Land secured, feasibility complete, architectural plans in progress. Pakistan&apos;s hotel deficit (under 5,000 branded rooms for 240M people) ensures strong occupancy.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Greenfield</span>
                  <span className="iv-deal-tag">Tourism Boom</span>
                  <span className="iv-deal-tag">Hunza Valley</span>
                  <span className="iv-deal-tag">Eco-Tourism</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Register Interest &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$2M &ndash; $8M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Tourism Growth</div>
                  <div className="iv-metric-value">300%+</div>
                  <div className="iv-metric-note">Recent years, accelerating</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Occupancy Target</div>
                  <div className="iv-metric-value">75%+ Y2</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '55%' }}></div></div>
                  <div className="iv-metric-note">Medium &mdash; New market, strong demand</div>
                </div>
              </div>
            </div>

            {/* MINERALS 2 */}
            <div className={`iv-deal${activeFilter !== 'all' && activeFilter !== 'minerals' ? ' hidden' : ''}`} data-sector="minerals">
              <div className="iv-deal-main">
                <div className="iv-deal-header">
                  <div className="iv-deal-icon">&#9670;</div>
                  <div className="iv-deal-header-text">
                    <div className="iv-deal-sector">Minerals &amp; Mining</div>
                    <div className="iv-deal-title">Marble &amp; Granite Quarry &mdash; Export-Grade Processing</div>
                  </div>
                  <span className="iv-deal-status iv-status-open">Open</span>
                </div>
                <p className="iv-deal-desc">Operational marble quarry in KPK with existing extraction license and road access. Investment sought for modern cutting and polishing plant to produce export-grade slabs for Gulf and European markets. Pakistan has the world&apos;s largest onyx reserves and significant marble deposits &mdash; currently exported mostly as raw blocks at minimal value-add.</p>
                <div className="iv-deal-tags">
                  <span className="iv-deal-tag">Operational Asset</span>
                  <span className="iv-deal-tag">Value-Add Processing</span>
                  <span className="iv-deal-tag">KPK</span>
                  <span className="iv-deal-tag">Export Revenue</span>
                </div>
                <Link href="/contact" className="iv-deal-cta">Request Information Memorandum &rarr;</Link>
              </div>
              <div className="iv-deal-metrics">
                <div className="iv-metric">
                  <div className="iv-metric-label">Investment Range</div>
                  <div className="iv-metric-value gold">$1M &ndash; $5M</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Projected IRR</div>
                  <div className="iv-metric-value">20&ndash;30%</div>
                  <div className="iv-metric-note">With processing plant</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Payback</div>
                  <div className="iv-metric-value">2&ndash;3 years</div>
                </div>
                <div className="iv-metric">
                  <div className="iv-metric-label">Risk Profile</div>
                  <div className="iv-metric-bar"><div className="iv-metric-bar-fill" style={{ width: '45%' }}></div></div>
                  <div className="iv-metric-note">Medium &mdash; Operational quarry, new plant</div>
                </div>
              </div>
            </div>

          </div>
        </section>

        <div className="divider"></div>

        {/* INVESTMENT PROCESS */}
        <section className="section fade-in">
          <div className="iv-headline">
            <h2 className="serif">Investment <span className="gold">process.</span></h2>
            <p>Every opportunity follows our rigorous five-stage pipeline &mdash; from initial identification through to exit strategy.</p>
          </div>

          <div className="iv-process stagger">
            <div className="iv-process-step">
              <div className="iv-process-num">01</div>
              <div className="iv-process-name">Source</div>
              <div className="iv-process-desc">Opportunity identification through our network, regulatory contacts, and sector intelligence</div>
            </div>
            <div className="iv-process-step">
              <div className="iv-process-num">02</div>
              <div className="iv-process-name">Assess</div>
              <div className="iv-process-desc">Financial modelling, legal due diligence, regulatory review, and risk assessment</div>
            </div>
            <div className="iv-process-step">
              <div className="iv-process-num">03</div>
              <div className="iv-process-name">Structure</div>
              <div className="iv-process-desc">SPV formation, investment terms, governance framework, and compliance architecture</div>
            </div>
            <div className="iv-process-step">
              <div className="iv-process-num">04</div>
              <div className="iv-process-name">Deploy</div>
              <div className="iv-process-desc">Capital deployment, operational launch, and ongoing performance monitoring</div>
            </div>
            <div className="iv-process-step">
              <div className="iv-process-num">05</div>
              <div className="iv-process-name">Report</div>
              <div className="iv-process-desc">Quarterly reporting, milestone tracking, and strategic exit planning</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* WHY PAKISTAN -- ENHANCED */}
        <section className="section section-center fade-in">
          <div className="iv-headline">
            <h2 className="serif">Why <span className="gold">Pakistan.</span></h2>
            <p>A convergence of untapped resources, demographic scale, preferential trade access, and infrastructure investment is creating a generational opportunity.</p>
          </div>

          <div className="iv-thesis-grid stagger">
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">$1T+</div>
              <div className="iv-thesis-label">Mineral Reserves</div>
              <div className="iv-thesis-desc">Copper, gold, rare earths, coal &mdash; largely unexplored</div>
            </div>
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">240M</div>
              <div className="iv-thesis-label">Consumer Market</div>
              <div className="iv-thesis-desc">5th largest population, growing middle class</div>
            </div>
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">GSP+</div>
              <div className="iv-thesis-label">EU Market Access</div>
              <div className="iv-thesis-desc">Zero-duty exports to the European Union</div>
            </div>
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">$65B</div>
              <div className="iv-thesis-label">CPEC Investment</div>
              <div className="iv-thesis-desc">9 Special Economic Zones, motorways, ports</div>
            </div>
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">64%</div>
              <div className="iv-thesis-label">Under 30</div>
              <div className="iv-thesis-desc">One of the world&apos;s youngest workforces</div>
            </div>
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">$3.2B</div>
              <div className="iv-thesis-label">IT Exports</div>
              <div className="iv-thesis-desc">Growing 20%+ annually, dollar-denominated</div>
            </div>
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">300%</div>
              <div className="iv-thesis-label">Tourism Growth</div>
              <div className="iv-thesis-desc">World&apos;s next frontier destination</div>
            </div>
            <div className="iv-thesis-card">
              <div className="iv-thesis-number">10M+</div>
              <div className="iv-thesis-label">Housing Deficit</div>
              <div className="iv-thesis-desc">Massive construction and real estate demand</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* INVESTOR PROFILES -- ENHANCED */}
        <section className="section fade-in">
          <div className="iv-headline">
            <h2 className="serif">Who we <span className="gold">serve.</span></h2>
            <p>We structure opportunities for a range of investor profiles, each with tailored access, structures, and reporting.</p>
          </div>

          <div className="iv-profiles stagger">
            <div className="iv-profile">
              <span className="iv-profile-icon">&#9670;</span>
              <h4>Institutional Investors</h4>
              <p>Sovereign funds, PE firms, and family offices seeking structured emerging market exposure with institutional-grade governance, quarterly reporting, and defined exit timelines.</p>
              <div className="iv-profile-structures">
                <span className="iv-profile-tag">SPV Structures</span>
                <span className="iv-profile-tag">Pooled Vehicles</span>
                <span className="iv-profile-tag">Board Seats</span>
              </div>
            </div>
            <div className="iv-profile">
              <span className="iv-profile-icon">&#9632;</span>
              <h4>Multinational Corporations</h4>
              <p>Companies evaluating Pakistan market entry or supply chain diversification with on-the-ground facilitation, regulatory navigation, and JV partnership structuring.</p>
              <div className="iv-profile-structures">
                <span className="iv-profile-tag">Joint Ventures</span>
                <span className="iv-profile-tag">Direct Investment</span>
                <span className="iv-profile-tag">Market Entry</span>
              </div>
            </div>
            <div className="iv-profile">
              <span className="iv-profile-icon">&#9733;</span>
              <h4>Diaspora Investors</h4>
              <p>Overseas Pakistanis (UAE, UK, US, Gulf) seeking home market investment with international standards, transparent reporting, and USD-denominated structures through our international operations.</p>
              <div className="iv-profile-structures">
                <span className="iv-profile-tag">Internationally Structured</span>
                <span className="iv-profile-tag">Deal-by-Deal</span>
                <span className="iv-profile-tag">USD Denominated</span>
              </div>
            </div>
            <div className="iv-profile">
              <span className="iv-profile-icon">&#36;</span>
              <h4>High-Net-Worth Individuals</h4>
              <p>Private investors seeking portfolio diversification into Pakistan&apos;s high-growth sectors with curated deal flow, dedicated advisory, and flexible entry sizes.</p>
              <div className="iv-profile-structures">
                <span className="iv-profile-tag">Direct Investment</span>
                <span className="iv-profile-tag">Co-Investment</span>
                <span className="iv-profile-tag">Streaming Deals</span>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* CTA */}
        <section className="cta-banner fade-in">
          <h2 className="serif">Explore the current <span className="gold">pipeline.</span></h2>
          <p>Institutional capital or private portfolio &mdash; each opportunity is structured with the access, oversight, and compliance your investment requires.</p>
          <Link href="/contact#contact-form" className="btn-gold">Request Deal Access &rarr;</Link>
        </section>

        <Footer />
      </div>
    </>
  )
}
