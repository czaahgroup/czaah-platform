'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { openFile } from '@/lib/utils/openFile'

interface KycDocument {
  id: string
  document_type: string
  file_url: string
  status: string
  created_at: string
}

interface SharedDocument {
  id: string
  title: string
  file_url: string
  shared_at: string
  enquiry_id: string | null
  enquiries?: { reference_number: string } | null
}

const DOC_STATUS: Record<string, string> = {
  pending: 'bg-yellow-500/20 text-yellow-400',
  approved: 'bg-green-500/20 text-green-400',
  rejected: 'bg-red-500/20 text-red-400',
}

export default function DocumentsPage() {
  const [kycDocs, setKycDocs] = useState<KycDocument[]>([])
  const [sharedDocs, setSharedDocs] = useState<SharedDocument[]>([])
  const [loading, setLoading] = useState(true)
  const [viewingDoc, setViewingDoc] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/login'); return }

      // Load KYC documents
      const { data: kyc } = await supabase
        .from('kyc_documents')
        .select('id, document_type, file_url, status, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      setKycDocs(kyc || [])

      // Load shared documents
      const { data: shared } = await supabase
        .from('shared_documents')
        .select('id, title, file_url, shared_at, enquiry_id, enquiries(reference_number)')
        .eq('shared_with', user.id)
        .order('shared_at', { ascending: false })

      setSharedDocs((shared as unknown as SharedDocument[]) || [])

      setLoading(false)
    }
    load()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  async function viewKycDocument(fileUrl: string) {
    setViewingDoc(fileUrl)
    try {
      await openFile(fileUrl, 'kyc-documents')
    } catch {
      // silently fail
    } finally {
      setViewingDoc(null)
    }
  }

  function formatDocType(type: string) {
    return type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-czaah-muted">Loading...</div>
      </div>
    )
  }

  return (
    <>
      <div className="mb-6">
        <h1 className="font-[family-name:var(--font-heading)] text-2xl text-czaah-white">
          Documents
        </h1>
      </div>

      <div className="space-y-8">
        {/* KYC Documents */}
        <div className="bg-czaah-card border border-czaah-border rounded-lg">
          <div className="px-6 py-4 border-b border-czaah-border">
            <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
              KYC Documents
            </h2>
          </div>

          {kycDocs.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <p className="text-czaah-muted">No KYC documents uploaded.</p>
            </div>
          ) : (
            <div className="divide-y divide-czaah-border">
              {kycDocs.map((doc) => (
                <div key={doc.id} className="px-6 py-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-czaah-white">
                      {formatDocType(doc.document_type)}
                    </p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className={`text-xs px-2 py-0.5 rounded ${DOC_STATUS[doc.status] || 'bg-czaah-muted-dim text-czaah-muted'}`}>
                        {doc.status}
                      </span>
                      <span className="text-xs text-czaah-muted-dim">
                        Uploaded {new Date(doc.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => viewKycDocument(doc.file_url)}
                    disabled={viewingDoc === doc.file_url}
                    className="text-sm bg-czaah-elevated border border-czaah-border text-czaah-muted hover:text-czaah-white px-4 py-1.5 rounded transition-colors disabled:opacity-50"
                  >
                    {viewingDoc === doc.file_url ? 'Opening...' : 'View'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Shared Documents */}
        <div className="bg-czaah-card border border-czaah-border rounded-lg">
          <div className="px-6 py-4 border-b border-czaah-border">
            <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
              Shared Documents
            </h2>
          </div>

          {sharedDocs.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <p className="text-czaah-muted">No documents have been shared with you yet.</p>
            </div>
          ) : (
            <div className="divide-y divide-czaah-border">
              {sharedDocs.map((doc) => (
                <div key={doc.id} className="px-6 py-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-czaah-white">
                      {doc.title}
                    </p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-czaah-muted-dim">
                      {doc.enquiries?.reference_number && (
                        <>
                          <span>Enquiry: {doc.enquiries.reference_number}</span>
                          <span>·</span>
                        </>
                      )}
                      <span>Shared {new Date(doc.shared_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => openFile(doc.file_url)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
                    className="text-sm bg-czaah-elevated border border-czaah-border text-czaah-muted hover:text-czaah-white px-4 py-1.5 rounded transition-colors"
                  >
                    View
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
