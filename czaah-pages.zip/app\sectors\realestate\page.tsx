'use client';
// @ts-nocheck

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';
import { createClient } from '@/lib/supabase/client';

interface LiveProperty {
  id: string;
  title: string;
  property_type: string;
  listing_type: string;
  price: number | null;
  currency: string;
  location: string;
  city: string;
  area_sqft: number | null;
  bedrooms: number | null;
  bathrooms: number | null;
  description: string | null;
  features: string[];
  images: string[];
}

export default function RealEstatePage() {
  const router = useRouter();
  const supabase = createClient();
  const [liveProperties, setLiveProperties] = useState<LiveProperty[]>([]);
  const [liveLoading, setLiveLoading] = useState(true);
  const [filterCity, setFilterCity] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterMinPrice, setFilterMinPrice] = useState('');
  const [filterMaxPrice, setFilterMaxPrice] = useState('');

  useEffect(() => {
    async function fetchLive() {
      try {
        const params = new URLSearchParams();
        if (filterCity) params.set('city', filterCity);
        if (filterType) params.set('type', filterType);
        if (filterMinPrice) params.set('min_price', filterMinPrice);
        if (filterMaxPrice) params.set('max_price', filterMaxPrice);
        const res = await fetch(`/api/public/properties?${params.toString()}`);
        const json = await res.json();
        if (res.ok) setLiveProperties(json.data || []);
      } catch (err) {
        console.error('Failed to load live properties:', err);
      } finally {
        setLiveLoading(false);
      }
    }
    fetchLive();
  }, [filterCity, filterType, filterMinPrice, filterMaxPrice]);

  async function handleEnquire(propertyId: string) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) {
      router.push('/register');
      return;
    }
    try {
      const res = await fetch('/api/property-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId }),
      });
      const json = await res.json();
      if (res.ok && json.data?.id) {
        router.push(`/dashboard/property-chats?id=${json.data.id}`);
      } else {
        alert(json.error || 'Failed to start enquiry. Please try again.');
      }
    } catch {
      alert('Failed to start enquiry. Please try again.');
    }
  }

  useEffect(() => {
    // Intersection Observer for fade-in sections
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
          entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
        }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
        document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    
        // Property search & filter
        const searchInput = document.getElementById('propertySearch');
        const filterLocation = document.getElementById('filterLocation');
        const filterType = document.getElementById('filterType');
        const filterStatus = document.getElementById('filterStatus');
        const filterPrice = document.getElementById('filterPrice');
        const clearBtn = document.getElementById('clearFilters');
        const resultsCount = document.getElementById('resultsCount');
        const grid = document.getElementById('propertiesGrid');
        const cards = grid.querySelectorAll('.property-card');
    
        function filterProperties() {
          const query = searchInput.value.toLowerCase().trim();
          const loc = filterLocation.value.toLowerCase();
          const type = filterType.value.toLowerCase();
          const status = filterStatus.value.toLowerCase();
          const priceRange = filterPrice.value;
    
          let visible = 0;
    
          cards.forEach(card => {
            const cardLoc = card.dataset.location;
            const cardType = card.dataset.type;
            const cardStatus = card.dataset.status;
            const cardPrice = parseInt(card.dataset.price);
            const cardKeywords = card.dataset.keywords;
            const cardText = card.textContent.toLowerCase();
    
            let show = true;
    
            // Text search
            if (query && !cardText.includes(query) && !cardKeywords.includes(query)) {
              show = false;
            }
    
            // Location filter
            if (loc && cardLoc !== loc) {
              show = false;
            }
    
            // Type filter
            if (type && cardType !== type) {
              show = false;
            }
    
            // Status filter
            if (status && cardStatus !== status) {
              show = false;
            }
    
            // Price filter
            if (priceRange) {
              const [min, max] = priceRange.split('-').map(Number);
              if (cardPrice < min || cardPrice > max) {
                show = false;
              }
            }
    
            card.classList.toggle('hidden', !show);
            if (show) visible++;
          });
    
          resultsCount.innerHTML = '<span>' + visible + '</span> propert' + (visible === 1 ? 'y' : 'ies') + ' found';
    
          // Show no results message
          const existing = grid.querySelector('.no-results');
          if (existing) existing.remove();
    
          if (visible === 0) {
            const msg = document.createElement('div');
            msg.className = 'no-results';
            msg.innerHTML = '<h3>No properties match your criteria</h3><p>Try adjusting your filters or search terms.</p>';
            grid.appendChild(msg);
          }
        }
    
        searchInput.addEventListener('input', filterProperties);
        filterLocation.addEventListener('change', filterProperties);
        filterType.addEventListener('change', filterProperties);
        filterStatus.addEventListener('change', filterProperties);
        filterPrice.addEventListener('change', filterProperties);
    
        clearBtn.addEventListener('click', () => {
          searchInput.value = '';
          filterLocation.value = '';
          filterType.value = '';
          filterStatus.value = '';
          filterPrice.value = '';
          filterProperties();
        });
  }, []);

  return (
    <>
      <Navbar />
      <style dangerouslySetInnerHTML={{ __html: `
    .properties-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
      margin-top: 48px;
    }

    .property-card {
      background: var(--black-card);
      border: 1px solid var(--black-border);
      border-radius: 16px;
      overflow: hidden;
      transition: all 0.5s var(--ease-smooth);
      display: flex;
      flex-direction: column;
    }

    .property-card:hover {
      border-color: rgba(201, 168, 76, 0.2);
      transform: translateY(-4px);
      box-shadow: 0 16px 48px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(201, 168, 76, 0.08);
    }

    .property-img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      background: rgba(255,255,255,0.03);
    }

    .property-body {
      padding: 24px;
      display: flex;
      flex-direction: column;
      flex-grow: 1;
    }

    .property-tags {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-bottom: 14px;
    }

    .property-type {
      padding: 3px 10px;
      border: 1px solid rgba(201, 168, 76, 0.3);
      color: var(--gold);
      font-size: 10px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      border-radius: 4px;
      font-weight: 500;
    }

    .property-location {
      padding: 3px 10px;
      border: 1px solid var(--black-border);
      color: var(--white-muted);
      font-size: 10px;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      border-radius: 4px;
      font-weight: 500;
    }

    .property-body h3 {
      font-size: 17px;
      font-weight: 600;
      margin-bottom: 8px;
      letter-spacing: -0.01em;
      line-height: 1.35;
    }

    .property-body p {
      font-size: 13px;
      line-height: 1.65;
      color: var(--white-muted);
      margin-bottom: 18px;
      flex-grow: 1;
    }

    .property-stats {
      display: flex;
      gap: 20px;
      padding-top: 16px;
      border-top: 1px solid var(--black-border);
      margin-bottom: 18px;
    }

    .property-stat {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .property-stat-value {
      font-size: 15px;
      font-weight: 600;
      color: var(--gold);
    }

    .property-stat-label {
      font-size: 10px;
      color: var(--white-muted);
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }

    .property-cta {
      font-size: 13px;
      font-weight: 500;
      color: var(--gold);
      text-decoration: none;
      transition: all 0.3s var(--ease-out);
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .property-cta:hover {
      gap: 10px;
      color: var(--gold-light);
    }

    .property-status {
      position: absolute;
      top: 16px;
      left: 16px;
      padding: 4px 12px;
      border-radius: 4px;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }

    .status-available {
      background: rgba(34, 197, 94, 0.15);
      color: #22c55e;
      border: 1px solid rgba(34, 197, 94, 0.3);
    }

    .status-limited {
      background: rgba(234, 179, 8, 0.15);
      color: #eab308;
      border: 1px solid rgba(234, 179, 8, 0.3);
    }

    .status-coming {
      background: rgba(59, 130, 246, 0.15);
      color: #3b82f6;
      border: 1px solid rgba(59, 130, 246, 0.3);
    }

    .property-img-wrapper {
      position: relative;
    }

    @media (max-width: 1024px) {
      .properties-grid { grid-template-columns: repeat(2, 1fr); }
    }

    @media (max-width: 640px) {
      .properties-grid { grid-template-columns: 1fr; }
      .search-filters { flex-direction: column; }
      .search-bar { min-width: 100%; }
    }

    /* Search & Filters */
    .search-panel {
      margin-top: 36px;
      margin-bottom: 12px;
    }

    .search-bar-row {
      display: flex;
      gap: 12px;
      margin-bottom: 16px;
    }

    .search-bar {
      flex: 1;
      background: rgba(255,255,255,0.03);
      border: 1px solid var(--black-border);
      border-radius: 10px;
      padding: 14px 18px 14px 44px;
      color: var(--white);
      font-family: 'Raleway', sans-serif;
      font-size: 14px;
      outline: none;
      transition: border-color 0.3s ease;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='rgba(255,255,255,0.25)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cline x1='21' y1='21' x2='16.65' y2='16.65'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: 16px center;
    }

    .search-bar:focus {
      border-color: var(--gold);
    }

    .search-bar::placeholder {
      color: rgba(255,255,255,0.25);
    }

    .search-filters {
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
    }

    .filter-select {
      background: rgba(255,255,255,0.03);
      border: 1px solid var(--black-border);
      border-radius: 8px;
      padding: 10px 36px 10px 14px;
      color: var(--white);
      font-family: 'Raleway', sans-serif;
      font-size: 12px;
      letter-spacing: 0.03em;
      outline: none;
      cursor: pointer;
      transition: border-color 0.3s ease;
      appearance: none;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='rgba(201,168,76,0.6)' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 12px center;
    }

    .filter-select:focus {
      border-color: var(--gold);
    }

    .filter-select option {
      background: #0F0F0F;
      color: var(--white);
    }

    .search-results-count {
      font-size: 12px;
      color: var(--white-muted);
      margin-top: 8px;
    }

    .search-results-count span {
      color: var(--gold);
      font-weight: 600;
    }

    .property-card.hidden {
      display: none;
    }

    .no-results {
      grid-column: 1 / -1;
      text-align: center;
      padding: 60px 20px;
      color: var(--white-muted);
    }

    .no-results h3 {
      color: var(--gold);
      margin-bottom: 8px;
      font-size: 18px;
    }

    .clear-filters {
      background: none;
      border: 1px solid var(--black-border);
      border-radius: 8px;
      padding: 10px 18px;
      color: var(--white-muted);
      font-family: 'Raleway', sans-serif;
      font-size: 12px;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .clear-filters:hover {
      border-color: var(--gold);
      color: var(--gold);
    }
  ` }} />
      <div className="v-hero-wrapper" style={{backgroundImage: "url('/Images/Real-Estate.jpg')"}}>
        <section className="v-hero">
          <div className="v-hero-text">
            <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
            <span className="gold-line hero-enter"></span>
            <div className="label hero-enter hero-enter-delay-1">Investment Advisory & Facilitation</div>
            <h1 className="serif hero-enter hero-enter-delay-2">Real<br /><span className="gold">Estate.</span></h1>
            <p className="hero-enter hero-enter-delay-3">Pakistan's real estate market is valued at over $300 billion — and CPEC is creating entirely new growth corridors. CZAAH provides structured, transparent access for international and diaspora investors seeking Pakistan's highest-growth property opportunities.</p>
            <a href="/contact?interest=Real%20Estate#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Investment Enquiries &rarr;</a>
          </div>
        </section>
        </div>
      
        <div className="divider"></div>

        {/*  AVAILABLE PROPERTIES (Live from partners)  */}
        {(!liveLoading && liveProperties.length > 0) && (
          <>
            <section className="section fade-in">
              <h2 className="serif">Available <span className="gold">properties.</span></h2>
              <p className="subtitle">Browse approved property listings from our verified real estate partners. Enquire directly to start a conversation.</p>

              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginTop: '24px', marginBottom: '24px' }}>
                <select className="filter-select" value={filterCity} onChange={(e) => setFilterCity(e.target.value)}>
                  <option value="">All Cities</option>
                  <option value="Islamabad">Islamabad</option>
                  <option value="Lahore">Lahore</option>
                  <option value="Karachi">Karachi</option>
                  <option value="Gwadar">Gwadar</option>
                  <option value="Peshawar">Peshawar</option>
                </select>
                <select className="filter-select" value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                  <option value="">All Types</option>
                  <option value="residential">Residential</option>
                  <option value="commercial">Commercial</option>
                  <option value="industrial">Industrial</option>
                  <option value="land">Land</option>
                  <option value="mixed_use">Mixed Use</option>
                </select>
                <input
                  type="number"
                  placeholder="Min Price"
                  value={filterMinPrice}
                  onChange={(e) => setFilterMinPrice(e.target.value)}
                  className="filter-select"
                  style={{ width: '130px' }}
                />
                <input
                  type="number"
                  placeholder="Max Price"
                  value={filterMaxPrice}
                  onChange={(e) => setFilterMaxPrice(e.target.value)}
                  className="filter-select"
                  style={{ width: '130px' }}
                />
              </div>

              <div className="properties-grid">
                {liveProperties.map((prop) => (
                  <div key={prop.id} className="property-card">
                    <div className="property-img-wrapper">
                      {prop.images && prop.images.length > 0 ? (
                        <img className="property-img" src={`${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/platform-files/${prop.images[0]}`} alt={prop.title} />
                      ) : (
                        <div className="property-img" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(255,255,255,0.15)', fontSize: '32px' }}>&#8962;</div>
                      )}
                      <span className="property-status status-available" style={{ textTransform: 'capitalize' }}>{prop.listing_type}</span>
                    </div>
                    <div className="property-body">
                      <div className="property-tags">
                        <span className="property-type">{prop.property_type.replace('_', ' ')}</span>
                        <span className="property-location">{prop.city}</span>
                      </div>
                      <h3>{prop.title}</h3>
                      {prop.description && <p>{prop.description.length > 140 ? prop.description.slice(0, 140) + '...' : prop.description}</p>}
                      <div className="property-stats">
                        {prop.area_sqft && (
                          <div className="property-stat">
                            <span className="property-stat-value">{prop.area_sqft.toLocaleString()} ft&sup2;</span>
                            <span className="property-stat-label">Area</span>
                          </div>
                        )}
                        {prop.bedrooms != null && (
                          <div className="property-stat">
                            <span className="property-stat-value">{prop.bedrooms}</span>
                            <span className="property-stat-label">Beds</span>
                          </div>
                        )}
                        {prop.bathrooms != null && (
                          <div className="property-stat">
                            <span className="property-stat-value">{prop.bathrooms}</span>
                            <span className="property-stat-label">Baths</span>
                          </div>
                        )}
                        <div className="property-stat">
                          <span className="property-stat-value">{prop.price ? `${prop.currency} ${prop.price.toLocaleString()}` : 'On Request'}</span>
                          <span className="property-stat-label">Price</span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleEnquire(prop.id)}
                        className="property-cta"
                        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, textAlign: 'left' }}
                      >
                        Enquire Now &rarr;
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <div className="divider"></div>
          </>
        )}

        {/*  FEATURED PROPERTIES  */}
        <section className="section fade-in">
          <h2 className="serif">Featured <span className="gold">properties.</span></h2>
          <p className="subtitle">Hand-selected investment opportunities across Pakistan's highest-growth real estate corridors. Each listing is pre-vetted, title-verified, and investment-ready.</p>
      
          <div className="search-panel">
            <div className="search-bar-row">
              <input type="text" className="search-bar" id="propertySearch" placeholder="Search by name, location, or keyword..." />
            </div>
            <div className="search-filters">
              <select className="filter-select" id="filterLocation">
                <option value="">All Locations</option>
                <option value="islamabad">Islamabad</option>
                <option value="lahore">Lahore</option>
                <option value="karachi">Karachi</option>
                <option value="gwadar">Gwadar</option>
                <option value="cpec sez">CPEC SEZ</option>
              </select>
              <select className="filter-select" id="filterType">
                <option value="">All Types</option>
                <option value="commercial">Commercial</option>
                <option value="industrial">Industrial</option>
                <option value="mixed-use">Mixed-Use</option>
                <option value="commercial plot">Commercial Plot</option>
              </select>
              <select className="filter-select" id="filterStatus">
                <option value="">All Status</option>
                <option value="available">Available</option>
                <option value="limited">Limited Units</option>
                <option value="coming">Coming Soon</option>
              </select>
              <select className="filter-select" id="filterPrice">
                <option value="">Any Price</option>
                <option value="0-1000000">Under $1M</option>
                <option value="1000000-2000000">$1M &ndash; $2M</option>
                <option value="2000000-99999999">$2M+</option>
              </select>
              <button className="clear-filters" id="clearFilters">Clear All</button>
            </div>
            <div className="search-results-count" id="resultsCount"><span>6</span> properties found</div>
          </div>
      
          <div className="properties-grid" id="propertiesGrid">
      
            <div className="property-card" data-location="islamabad" data-type="commercial" data-status="available" data-price="1800000" data-keywords="blue area office tower full floor grade-a margalla hills">
              <div className="property-img-wrapper">
                <img className="property-img" src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&h=400&fit=crop" alt="Commercial Tower" />
                <span className="property-status status-available">Available</span>
              </div>
              <div className="property-body">
                <div className="property-tags">
                  <span className="property-type">Commercial</span>
                  <span className="property-location">Islamabad</span>
                </div>
                <h3>Blue Area Office Tower &mdash; Full Floor</h3>
                <p>Premium Grade-A office space in Islamabad's prime Blue Area district. 12,000 sq ft full floor with panoramic Margalla Hills views, fitted to international standards.</p>
                <div className="property-stats">
                  <div className="property-stat">
                    <span className="property-stat-value">12,000 ft&sup2;</span>
                    <span className="property-stat-label">Area</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">7.2%</span>
                    <span className="property-stat-label">Yield</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">$1.8M</span>
                    <span className="property-stat-label">Price</span>
                  </div>
                </div>
                <a href="/contact#contact-form" className="property-cta">Request Details &rarr;</a>
              </div>
            </div>
      
            <div className="property-card" data-location="lahore" data-type="industrial" data-status="available" data-price="2400000" data-keywords="sundar industrial estate warehouse complex logistics motorway">
              <div className="property-img-wrapper">
                <img className="property-img" src="https://images.unsplash.com/photo-1565008447742-97f6f38c985c?w=600&h=400&fit=crop" alt="Industrial Warehouse" />
                <span className="property-status status-available">Available</span>
              </div>
              <div className="property-body">
                <div className="property-tags">
                  <span className="property-type">Industrial</span>
                  <span className="property-location">Lahore</span>
                </div>
                <h3>Sundar Industrial Estate &mdash; Warehouse Complex</h3>
                <p>Modern logistics and warehousing facility on the Lahore&ndash;Karachi motorway corridor. 40,000 sq ft with loading docks, 24/7 security, and CPEC freight connectivity.</p>
                <div className="property-stats">
                  <div className="property-stat">
                    <span className="property-stat-value">40,000 ft&sup2;</span>
                    <span className="property-stat-label">Area</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">8.5%</span>
                    <span className="property-stat-label">Yield</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">$2.4M</span>
                    <span className="property-stat-label">Price</span>
                  </div>
                </div>
                <a href="/contact#contact-form" className="property-cta">Request Details &rarr;</a>
              </div>
            </div>
      
            <div className="property-card" data-location="karachi" data-type="mixed-use" data-status="limited" data-price="1200000" data-keywords="clifton commercial centre retail office mixed-use">
              <div className="property-img-wrapper">
                <img className="property-img" src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&h=400&fit=crop" alt="Mixed-Use Development" />
                <span className="property-status status-limited">Limited Units</span>
              </div>
              <div className="property-body">
                <div className="property-tags">
                  <span className="property-type">Mixed-Use</span>
                  <span className="property-location">Karachi</span>
                </div>
                <h3>Clifton Commercial Centre &mdash; Retail &amp; Office</h3>
                <p>Prime mixed-use development in Karachi's Clifton district. Ground-floor retail with upper office floors, high footfall location near major residential communities.</p>
                <div className="property-stats">
                  <div className="property-stat">
                    <span className="property-stat-value">8,500 ft&sup2;</span>
                    <span className="property-stat-label">Area</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">6.8%</span>
                    <span className="property-stat-label">Yield</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">$1.2M</span>
                    <span className="property-stat-label">Price</span>
                  </div>
                </div>
                <a href="/contact#contact-form" className="property-cta">Request Details &rarr;</a>
              </div>
            </div>
      
            <div className="property-card" data-location="gwadar" data-type="commercial plot" data-status="coming" data-price="850000" data-keywords="gwadar free zone commercial plot port cpec tax-free">
              <div className="property-img-wrapper">
                <img className="property-img" src="https://images.unsplash.com/photo-1590846406792-0adc7f938f1d?w=600&h=400&fit=crop" alt="Gwadar Port Area" />
                <span className="property-status status-coming">Coming Soon</span>
              </div>
              <div className="property-body">
                <div className="property-tags">
                  <span className="property-type">Commercial Plot</span>
                  <span className="property-location">Gwadar</span>
                </div>
                <h3>Gwadar Free Zone &mdash; Commercial Plot</h3>
                <p>Strategic commercial plot within Gwadar Free Zone Phase II. Tax-exempt zone with direct port access, positioned for the next wave of CPEC-driven development.</p>
                <div className="property-stats">
                  <div className="property-stat">
                    <span className="property-stat-value">2 Acres</span>
                    <span className="property-stat-label">Area</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">Tax-Free</span>
                    <span className="property-stat-label">Zone</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">$850K</span>
                    <span className="property-stat-label">Price</span>
                  </div>
                </div>
                <a href="/contact#contact-form" className="property-cta">Register Interest &rarr;</a>
              </div>
            </div>
      
            <div className="property-card" data-location="cpec sez" data-type="industrial" data-status="available" data-price="1600000" data-keywords="rashakai sez manufacturing unit kpk tax holiday motorway">
              <div className="property-img-wrapper">
                <img className="property-img" src="https://images.unsplash.com/photo-1587293852726-70cdb56c2866?w=600&h=400&fit=crop" alt="SEZ Industrial" />
                <span className="property-status status-available">Available</span>
              </div>
              <div className="property-body">
                <div className="property-tags">
                  <span className="property-type">Industrial</span>
                  <span className="property-location">CPEC SEZ</span>
                </div>
                <h3>Rashakai SEZ &mdash; Manufacturing Unit</h3>
                <p>Ready-to-operate manufacturing unit in the Rashakai Special Economic Zone, KPK. Incentivised tax structure, Chinese JV-ready infrastructure, and direct M-1 motorway access.</p>
                <div className="property-stats">
                  <div className="property-stat">
                    <span className="property-stat-value">25,000 ft&sup2;</span>
                    <span className="property-stat-label">Area</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">10-yr</span>
                    <span className="property-stat-label">Tax Holiday</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">$1.6M</span>
                    <span className="property-stat-label">Price</span>
                  </div>
                </div>
                <a href="/contact#contact-form" className="property-cta">Request Details &rarr;</a>
              </div>
            </div>
      
            <div className="property-card" data-location="islamabad" data-type="commercial" data-status="limited" data-price="620000" data-keywords="f-7 markaz premium office suites diplomatic zone parking">
              <div className="property-img-wrapper">
                <img className="property-img" src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=400&fit=crop" alt="Corporate Office" />
                <span className="property-status status-limited">Limited Units</span>
              </div>
              <div className="property-body">
                <div className="property-tags">
                  <span className="property-type">Commercial</span>
                  <span className="property-location">Islamabad</span>
                </div>
                <h3>F-7 Markaz &mdash; Premium Office Suites</h3>
                <p>Boutique office suites in Islamabad's F-7 Markaz, ideal for corporate HQs and embassy-area presence. Fully fitted, 24/7 access, underground parking, diplomatic zone proximity.</p>
                <div className="property-stats">
                  <div className="property-stat">
                    <span className="property-stat-value">3,200 ft&sup2;</span>
                    <span className="property-stat-label">Area</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">7.5%</span>
                    <span className="property-stat-label">Yield</span>
                  </div>
                  <div className="property-stat">
                    <span className="property-stat-value">$620K</span>
                    <span className="property-stat-label">Price</span>
                  </div>
                </div>
                <a href="/contact#contact-form" className="property-cta">Request Details &rarr;</a>
              </div>
            </div>
      
          </div>
        </section>
      
        <div className="divider"></div>
      
        {/*  SERVICES  */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Full-lifecycle real estate advisory and facilitation &mdash; from opportunity identification to asset management.</p>
      
          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>Investment Advisory</h3>
              <p>Market analysis, opportunity identification, and investment structuring for institutional and private investors evaluating Pakistan's real estate market.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9632;</div>
              <h3>CPEC Corridor Properties</h3>
              <p>Access to commercial and industrial properties in CPEC Special Economic Zones — Gwadar, Rashakai, Allama Iqbal, and Dhabeji SEZs — where infrastructure investment is driving rapid appreciation.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8644;</div>
              <h3>Diaspora Investment Gateway</h3>
              <p>Structured investment vehicles for overseas Pakistanis — from the UAE, UK, US, and Gulf — seeking home market real estate exposure with international-standard transparency and reporting.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Due Diligence & Title Verification</h3>
              <p>Comprehensive property due diligence, title verification, legal review, and risk assessment. We eliminate the opacity that deters international investors from Pakistani real estate.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9881;</div>
              <h3>Property Management</h3>
              <p>Ongoing asset management, tenant coordination, rental collection, and maintenance supervision for investors who want hands-off ownership with full visibility.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#36;</div>
              <h3>Structured Investment Vehicles</h3>
              <p>Deal-by-deal or pooled investment structures with clean legal frameworks, regular reporting, and defined exit mechanisms — the institutional approach to Pakistan real estate.</p>
            </div>
          </div>
        </section>
      
        <div className="divider"></div>
      
        {/*  CPEC FOCUS  */}
        <section className="section fade-in">
          <div className="split fade-in-left">
            <div>
              <h3 className="serif">CPEC corridor <span className="gold">opportunity.</span></h3>
              <p>The China-Pakistan Economic Corridor is creating 9 Special Economic Zones across the country — from Gwadar port in the south to Rashakai in the north. Each zone brings new infrastructure, industrial capacity, and commercial demand.</p>
              <p>Commercial properties — warehousing, logistics facilities, office space, and worker housing — are severely underbuilt relative to projected demand. Early positioning in these zones offers significant appreciation potential alongside strong rental yields of 6&ndash;8% annually.</p>
              <p>CZAAH's on-the-ground presence and regulatory expertise allows investors to access these opportunities before they reach the broader market.</p>
            </div>
            <div>
              <h3 className="serif">Target <span className="gold">locations.</span></h3>
              <div style={{marginTop: '8px'}}>
                <span className="tag">Islamabad</span>
                <span className="tag">Lahore</span>
                <span className="tag">Karachi</span>
                <span className="tag">Gwadar</span>
                <span className="tag">CPEC Industrial Zones</span>
              </div>
              <p style={{marginTop: '16px', fontSize: '14px', lineHeight: '1.7', color: 'var(--white-dim)'}}>Our focus is commercial and industrial properties in high-growth corridors — tangible assets with rental yield and appreciation upside, not speculative residential plots.</p>
            </div>
          </div>
        </section>
      
        <div className="divider"></div>
      
        {/*  DIASPORA  */}
        <section className="section fade-in">
          <h2 className="serif">Diaspora & international <span className="gold">investors.</span></h2>
          <p className="subtitle">Millions of overseas Pakistanis and international investors want Pakistan real estate exposure — but lack trusted, structured access. We solve that.</p>
      
          <div className="process-list stagger">
            <div className="process-item">
              <div>
                <h4>UAE & Gulf Investors</h4>
                <p>Invest through our international frameworks with familiar jurisdiction, USD-denominated transactions, and international-standard legal frameworks. No need to navigate Pakistan's property registration system directly.</p>
              </div>
            </div>
            <div className="process-item">
              <div>
                <h4>UK & US Diaspora</h4>
                <p>Structured access for Western-based investors who want Pakistan real estate exposure without the friction of direct local transactions, land title complexities, and regulatory navigation.</p>
              </div>
            </div>
            <div className="process-item">
              <div>
                <h4>Institutional Investors</h4>
                <p>Professional fund-style structures, regular reporting, independent valuations, clean title verification, and defined exit mechanisms — the institutional approach to Pakistan real estate that the market needs.</p>
              </div>
            </div>
            <div className="process-item">
              <div>
                <h4>Flexible Participation</h4>
                <p>Invest in specific properties on a deal-by-deal basis or through pooled vehicles — flexibility to match your risk appetite, capital allocation preferences, and desired level of involvement.</p>
              </div>
            </div>
          </div>
        </section>
      
        <div className="divider"></div>
      
        {/*  STATS  */}
        <section className="section section-center fade-in-scale">
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">$300B+</div>
              <div className="label">Pakistan real estate market value</div>
            </div>
            <div className="stat-item">
              <div className="number">9</div>
              <div className="label">CPEC Special Economic Zones</div>
            </div>
            <div className="stat-item">
              <div className="number">9M+</div>
              <div className="label">Overseas Pakistanis worldwide</div>
            </div>
            <div className="stat-item">
              <div className="number">6&ndash;8%</div>
              <div className="label">Prime commercial rental yields</div>
            </div>
          </div>
        </section>
      
        <div className="divider"></div>
      
        {/*  WHY CZAAH  */}
        <section className="section fade-in">
          <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
          <p className="subtitle">What makes us different from every other real estate firm in Pakistan.</p>
      
          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>On-the-Ground Expertise</h4>
                <p>Headquartered in Islamabad with presence across Pakistan's key property markets. We conduct physical due diligence, verify titles in person, and maintain direct relationships with developers and authorities.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>End-to-End Due Diligence</h4>
                <p>Title verification, legal review, market valuation, and risk assessment — we remove the opacity and uncertainty that has historically deterred international investment in Pakistani real estate.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>CPEC Corridor Intelligence</h4>
                <p>Deep knowledge of CPEC development timelines, SEZ progress, and infrastructure rollout — allowing our investors to position ahead of the market in the highest-growth corridors.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#8644;</div>
              <div>
                <h4>Institutional-Grade Structures</h4>
                <p>Clean legal frameworks, regular reporting, independent valuations, and defined exit mechanisms. We bring institutional discipline to a market that has traditionally lacked it.</p>
              </div>
            </div>
          </div>
        </section>
      
        <div className="divider"></div>
      
        <section className="cta-banner fade-in">
          <h2 className="serif">Position your capital in <span className="gold">Pakistan's growth corridors.</span></h2>
          <p>CPEC corridors, commercial hubs, and structured diaspora access &mdash; through a single institutional counterparty.</p>
          <a href="/contact?interest=Real%20Estate#contact-form" className="btn-gold">Discuss Opportunities &rarr;</a>
        </section>
      <Footer />
    </>
  );
}
