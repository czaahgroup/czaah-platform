'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

const serviceData = [
  {
    desc: 'Comprehensive engineering consultancy for commercial, industrial, and infrastructure projects. Our engineering teams deliver structural analysis, mechanical design, electrical systems planning, and project management from concept through commissioning.',
    deliverables: ['Structural engineering & analysis', 'MEP system design', 'Engineering project management', 'Technical specifications & BOQs', 'Compliance with Pakistan Building Code'],
    stat: 'Full-spectrum engineering \u2014 structural, mechanical, electrical, environmental'
  },
  {
    desc: 'Design, supply, installation, and maintenance of heating, ventilation, and air conditioning systems. From high-rise commercial towers to industrial facilities and hospitals \u2014 we deliver climate control solutions engineered for Pakistan\u2019s demanding environment.',
    deliverables: ['HVAC system design & load calculation', 'Ductwork design & installation', 'Chiller plant engineering', 'Building Management System (BMS) integration', 'Preventive maintenance contracts'],
    stat: 'Commercial, industrial & healthcare \u2014 systems designed for 45\u00B0C+ climates'
  },
  {
    desc: 'Supply, installation, and maintenance of passenger and freight elevator systems for commercial buildings, residential towers, hospitals, and industrial facilities. We partner with leading global manufacturers to deliver reliable vertical transportation.',
    deliverables: ['Elevator system design & specification', 'Supply from global OEMs (Otis, Schindler, KONE)', 'Installation & commissioning', 'Annual maintenance contracts (AMC)', 'Modernisation of existing systems'],
    stat: 'From 4-stop residential to 50+ floor high-rise \u2014 all capacities covered'
  },
  {
    desc: 'Escalator and moving walkway systems for shopping malls, airports, metro stations, and commercial complexes. Engineered for Pakistan\u2019s high-traffic environments with robust safety systems and energy-efficient operation.',
    deliverables: ['Traffic flow analysis & system sizing', 'Escalator supply & installation', 'Moving walkway solutions', 'Safety compliance & inspection', 'Service & maintenance contracts'],
    stat: 'Malls, airports, metro \u2014 designed for 10,000+ daily passengers'
  },
  {
    desc: 'Design, supply, and commissioning of power generation systems for commercial, industrial, and infrastructure projects. From backup generators to captive power plants \u2014 we deliver reliable electricity where the grid cannot.',
    deliverables: ['Power plant design & feasibility', 'Generator supply (Caterpillar, Cummins, Perkins)', 'HT/LT switchgear & distribution', 'Synchronisation & load management', 'Operations & maintenance support'],
    stat: '100 kVA to 50 MW \u2014 backup, captive & independent power solutions'
  },
  {
    desc: 'Ground-up civil engineering and construction services \u2014 earthworks, foundations, structural concrete, drainage systems, and site development. We execute civil works for commercial, residential, and infrastructure projects with quality assurance at every stage.',
    deliverables: ['Site preparation & earthworks', 'Foundation engineering (piling, raft, strip)', 'Structural concrete & reinforcement', 'Drainage & water management', 'Road works & external development'],
    stat: 'From site clearing to structural handover \u2014 complete civil execution'
  },
  {
    desc: 'End-to-end solar photovoltaic solutions \u2014 from rooftop installations for commercial buildings to utility-scale solar farms. Pakistan receives 300+ sunny days per year, making solar the most compelling renewable energy investment in the country.',
    deliverables: ['Solar feasibility & energy yield analysis', 'PV system design & engineering', 'Panel supply (Tier-1 manufacturers)', 'Installation & grid interconnection', 'Net metering application & approval'],
    stat: '300+ sunny days \u2014 Pakistan\u2019s solar potential: 2.9 million MW'
  },
  {
    desc: 'Complete air conditioning solutions for offices, retail spaces, hotels, hospitals, and industrial facilities. We design and install central AC plants, VRF/VRV systems, split units, and chiller-based cooling systems optimised for energy efficiency.',
    deliverables: ['Cooling load assessment', 'Central plant design (chilled water systems)', 'VRF/VRV multi-zone systems', 'Split & ductless solutions', 'Energy optimisation & controls'],
    stat: 'Energy-efficient cooling \u2014 20\u201340% savings with modern inverter technology'
  },
  {
    desc: 'End-to-end oil and gas engineering services spanning upstream exploration support, midstream pipeline infrastructure, and downstream refinery and processing operations. Pakistan\u2019s growing energy demands and strategic pipeline corridors \u2014 including TAPI and Pakistan Stream \u2014 create significant opportunities across the hydrocarbon value chain.',
    deliverables: ['Upstream exploration & production support', 'Pipeline design, construction & integrity management', 'Refinery & processing plant engineering', 'LPG & LNG terminal infrastructure', 'HSE compliance & environmental management', 'Gas compression & metering stations'],
    stat: 'Upstream to downstream \u2014 full hydrocarbon value chain engineering'
  }
];

export default function EngineeringPage() {
  const [activeIdx, setActiveIdx] = useState<number>(-1);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('visible');
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach((el) => {
      observerRef.current?.observe(el);
    });
    return () => observerRef.current?.disconnect();
  }, []);

  function getRowPanel(idx: number): number {
    if (idx < 4) return 1;
    if (idx < 8) return 2;
    return 3;
  }

  function handleCardClick(idx: number) {
    if (idx === activeIdx) {
      setActiveIdx(-1);
    } else {
      setActiveIdx(idx);
    }
  }

  function renderExpanded(rowStart: number, rowEnd: number) {
    if (activeIdx < rowStart || activeIdx >= rowEnd) return null;
    const d = serviceData[activeIdx];
    return (
      <div className={`eg-expanded ${activeIdx >= rowStart && activeIdx < rowEnd ? 'eg-open' : ''}`} style={{ gridColumn: '1 / -1' }}>
        <div className="eg-expanded-inner">
          <p className="eg-expanded-desc">{d.desc}</p>
          <div className="eg-expanded-columns">
            <div className="eg-expanded-col">
              <h4>Key Deliverables</h4>
              <ul className="eg-deliverables">
                {d.deliverables.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
          <div className="eg-stat-row">
            <span className="eg-stat-text">{d.stat}</span>
            <a href="/contact" className="eg-detail-link">Enquire &rarr;</a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Engineering.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">MEP &amp; Energy Solutions</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Engineering &amp;<br /><span className="gold">Energy.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Integrated engineering and energy solutions across Pakistan &mdash; HVAC systems, elevator installations, solar power, civil engineering, industrial air conditioning, and oil &amp; gas infrastructure, delivered through global OEM partnerships.</p>
              <a href="/contact?interest=Engineering%20%26%20Energy#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Discuss a Project &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* SERVICE SHOWCASE */}
        <style>{`
          .eg-section { max-width: 1100px; margin: 0 auto; padding: 80px 32px; }
          .eg-section-title { font-family: 'Cinzel', serif; font-size: 2rem; color: var(--white); margin-bottom: 8px; }
          .eg-section-subtitle { color: var(--white-muted); font-size: 1rem; margin-bottom: 48px; line-height: 1.6; }
          .eg-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
          .eg-card { background: var(--black-card); border: 1px solid var(--black-border); border-radius: 10px; padding: 32px 24px; text-align: center; cursor: pointer; transition: border-color 0.3s var(--ease-smooth), box-shadow 0.3s var(--ease-smooth), transform 0.2s var(--ease-out); position: relative; overflow: hidden; }
          .eg-card::after { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 2px; background: var(--gold); transform: scaleX(0); transition: transform 0.3s var(--ease-smooth); }
          .eg-card:hover::after { transform: scaleX(1); }
          .eg-card:hover { border-color: rgba(201,168,76,0.4); transform: translateY(-2px); }
          .eg-card.eg-active { border-color: var(--gold); box-shadow: 0 0 24px rgba(201,168,76,0.15); transform: translateY(-3px); }
          .eg-card.eg-active::after { transform: scaleX(1); }
          .eg-card-icon { font-size: 2.5rem; color: var(--white-muted); transition: color 0.3s, text-shadow 0.3s; line-height: 1; margin-bottom: 12px; }
          .eg-card.eg-active .eg-card-icon { color: var(--gold); text-shadow: 0 0 16px rgba(201,168,76,0.4); }
          .eg-card-name { font-family: 'Cinzel', serif; font-size: 1.1rem; color: var(--white); font-weight: 600; margin-bottom: 6px; }
          .eg-card-tagline { font-size: 0.8rem; color: var(--white-dim); line-height: 1.4; }
          .eg-expanded { max-height: 0; overflow: hidden; opacity: 0; transition: max-height 0.5s var(--ease-smooth), opacity 0.4s var(--ease-smooth), margin 0.4s var(--ease-smooth); background: var(--black-elevated); border: 1px solid var(--black-border); border-radius: 10px; margin-top: 0; grid-column: 1 / -1; }
          .eg-expanded.eg-open { max-height: 600px; opacity: 1; margin-top: 8px; }
          .eg-expanded-inner { padding: 40px; }
          .eg-expanded-desc { color: var(--white-muted); font-size: 0.95rem; line-height: 1.7; margin-bottom: 28px; }
          .eg-expanded-columns { display: flex; gap: 48px; margin-bottom: 28px; }
          .eg-expanded-col { flex: 1; }
          .eg-expanded-col h4 { font-family: 'Cinzel', serif; color: var(--white); font-size: 1rem; margin-bottom: 14px; }
          .eg-deliverables { list-style: none; padding: 0; margin: 0; }
          .eg-deliverables li { position: relative; padding-left: 18px; color: var(--white-muted); font-size: 0.88rem; line-height: 1.6; margin-bottom: 8px; }
          .eg-deliverables li::before { content: ''; position: absolute; left: 0; top: 8px; width: 6px; height: 6px; background: var(--gold); border-radius: 50%; }
          .eg-stat-row { display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--black-border); padding-top: 20px; }
          .eg-stat-text { font-family: 'Cinzel', serif; color: var(--gold); font-size: 1rem; letter-spacing: 0.02em; }
          .eg-detail-link { color: var(--gold); text-decoration: none; font-size: 0.9rem; font-weight: 500; transition: opacity 0.2s; }
          .eg-detail-link:hover { opacity: 0.75; }
          @media (max-width: 900px) { .eg-grid { grid-template-columns: repeat(2, 1fr); } .eg-expanded-columns { flex-direction: column; gap: 24px; } }
          @media (max-width: 540px) { .eg-grid { grid-template-columns: 1fr; } .eg-section { padding: 56px 20px; } .eg-expanded-inner { padding: 24px; } }
        `}</style>

        <section className="eg-section fade-in">
          <h2 className="eg-section-title">Our <span className="gold">services.</span></h2>
          <p className="eg-section-subtitle">Nine integrated engineering and energy service lines — select a service to explore our capabilities.</p>

          <div className="eg-grid" id="egGrid">
            {[
              { icon: '\u2692', name: 'Engineering', tagline: 'Structural, mechanical & electrical' },
              { icon: '\u2744', name: 'HVAC', tagline: 'Climate control for any scale' },
              { icon: '\u2B06', name: 'Elevators', tagline: 'Passenger & freight solutions' },
              { icon: '\u2197', name: 'Escalators', tagline: 'High-traffic movement systems' },
            ].map((card, i) => (
              <div
                key={i}
                className={`eg-card${activeIdx === i ? ' eg-active' : ''}`}
                onClick={() => handleCardClick(i)}
              >
                <div className="eg-card-icon">{card.icon}</div>
                <div className="eg-card-name">{card.name}</div>
                <div className="eg-card-tagline">{card.tagline}</div>
              </div>
            ))}
            {renderExpanded(0, 4)}

            {[
              { icon: '\u26A1', name: 'Power Generation', tagline: 'Diesel, gas & hybrid systems' },
              { icon: '\u26C8', name: 'Civil Works', tagline: 'Foundations to finishing' },
              { icon: '\u2600', name: 'Solar Panels', tagline: 'Rooftop to utility-scale' },
              { icon: '\u2746', name: 'Air Conditioning', tagline: 'Central, split & VRF systems' },
            ].map((card, i) => (
              <div
                key={i + 4}
                className={`eg-card${activeIdx === i + 4 ? ' eg-active' : ''}`}
                onClick={() => handleCardClick(i + 4)}
              >
                <div className="eg-card-icon">{card.icon}</div>
                <div className="eg-card-name">{card.name}</div>
                <div className="eg-card-tagline">{card.tagline}</div>
              </div>
            ))}
            {renderExpanded(4, 8)}

            <div
              className={`eg-card${activeIdx === 8 ? ' eg-active' : ''}`}
              onClick={() => handleCardClick(8)}
            >
              <div className="eg-card-icon">&#9906;</div>
              <div className="eg-card-name">Oil &amp; Gas</div>
              <div className="eg-card-tagline">Upstream, downstream &amp; pipeline</div>
            </div>
            {renderExpanded(8, 9)}
          </div>
        </section>

        <div className="divider"></div>

        {/* OUR CAPABILITIES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">capabilities.</span></h2>
          <p className="subtitle">Comprehensive engineering and energy project delivery.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9632;</div>
              <h3>Project Management</h3>
              <p>End-to-end engineering project management — from initial concept and feasibility through detailed design, procurement, installation, and commissioning. Independent oversight protecting timelines and budgets.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>Design &amp; Engineering</h3>
              <p>In-house design capabilities across structural, mechanical, electrical, and plumbing disciplines. Detailed engineering drawings, specifications, and BOQs prepared to international standards.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9881;</div>
              <h3>Supply Chain</h3>
              <p>Partnerships with global OEMs — Otis, Schindler, KONE, Caterpillar, Cummins, Daikin, Carrier, and Tier-1 solar panel manufacturers. Competitive procurement and import facilitation.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Installation &amp; Commissioning</h3>
              <p>Professional installation teams for MEP systems, elevators, escalators, power plants, and solar arrays. Testing, balancing, and commissioning to ensure optimal performance from day one.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#43;</div>
              <h3>Maintenance &amp; AMC</h3>
              <p>Ongoing Annual Maintenance Contracts for all installed systems. Preventive maintenance schedules, emergency response, spare parts management, and performance monitoring.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8644;</div>
              <h3>Compliance</h3>
              <p>Full compliance with Pakistan Building Code, NEPRA regulations, PEC standards, and international safety certifications. Documentation, inspection coordination, and regulatory liaison.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">9</div>
              <div className="label">Service lines</div>
            </div>
            <div className="stat-item">
              <div className="number">3</div>
              <div className="label">Sectors served — commercial, industrial, infrastructure</div>
            </div>
            <div className="stat-item">
              <div className="number">Global</div>
              <div className="label">OEM partnerships</div>
            </div>
            <div className="stat-item">
              <div className="number">National</div>
              <div className="label">Pakistan-wide coverage</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* KEY SECTORS WE SERVE */}
        <section className="section fade-in">
          <h2 className="serif">Key sectors <span className="gold">we serve.</span></h2>
          <p className="subtitle">Engineering and energy solutions tailored to each sector&apos;s demands.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9962;</div>
              <div>
                <h4>Commercial Real Estate</h4>
                <p>Towers, shopping malls, office complexes, and mixed-use developments. Full MEP engineering, elevator and escalator systems, central HVAC, and backup power generation for high-rise and large-format commercial projects.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9881;</div>
              <div>
                <h4>Industrial &amp; Manufacturing</h4>
                <p>Factories, warehouses, processing plants, and Special Economic Zones. Industrial HVAC, freight elevators, captive power generation, solar installations, and heavy civil works for manufacturing environments.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9764;</div>
              <div>
                <h4>Healthcare</h4>
                <p>Hospitals, clinics, and pharmaceutical facilities. Medical-grade HVAC with clean room capabilities, hospital elevator systems, emergency backup power, and specialised MEP engineering for healthcare compliance.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>Infrastructure &amp; Government</h4>
                <p>Public buildings, transport terminals, metro stations, and utility infrastructure. Escalator systems for mass transit, solar farms for government facilities, power distribution, and large-scale civil engineering.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* CTA */}
        <section className="cta-banner fade-in">
          <h2 className="serif">Integrated engineering, <span className="gold">delivered.</span></h2>
          <p>HVAC, power generation, solar, elevator systems, civil engineering, and oil &amp; gas &mdash; from concept through commissioning.</p>
          <a href="/contact?interest=Engineering%20%26%20Energy#contact-form" className="btn-gold">Discuss Requirements &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
