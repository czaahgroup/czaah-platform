'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface TradeRoute {
  name: string;
  nameHtml: React.ReactNode;
  stats: { value: string; label: string }[];
  exportFlow: string;
  importFlow: string;
  agreementLabel: string;
  agreementValue: string;
  ports: React.ReactNode;
  docs: string[];
  facilitation: string;
}

const tradeRoutes: Record<string, TradeRoute> = {
  eu: {
    name: 'European Union (GSP+)',
    nameHtml: <>European Union <span>(GSP+)</span></>,
    stats: [
      { value: '$8.5B+', label: 'Exports' },
      { value: '$4.2B', label: 'Imports' },
      { value: 'Surplus', label: 'Balance' }
    ],
    exportFlow: 'Textiles (70%), rice, leather, surgical instruments, sports goods',
    importFlow: 'Machinery, chemicals, pharmaceuticals, vehicles',
    agreementLabel: 'Trade Agreement',
    agreementValue: 'GSP+ \u2014 zero duty on 6,200+ tariff lines',
    ports: <><strong>Key Ports:</strong> Karachi &#8594; Rotterdam, Hamburg, Antwerp</>,
    docs: ['EUR.1 Certificate', 'GSP Form A', 'Certificate of Origin', 'Bill of Lading', 'Commercial Invoice', 'Packing List', 'Phytosanitary Certificate (food)'],
    facilitation: 'GSP+ documentation, compliance certification, EU buyer matching'
  },
  uae: {
    name: 'United Arab Emirates',
    nameHtml: <>United Arab <span>Emirates</span></>,
    stats: [
      { value: '$1.8B', label: 'Exports' },
      { value: '$7.5B', label: 'Imports' },
      { value: 'Deficit', label: 'Balance' }
    ],
    exportFlow: 'Rice, textiles, fruits, vegetables, meat, gems',
    importFlow: 'Petroleum, gold, machinery, electronics',
    agreementLabel: 'Trade Agreement',
    agreementValue: 'Bilateral FTA (under negotiation)',
    ports: <><strong>Key Ports:</strong> Karachi / Port Qasim &#8594; Jebel Ali, Sharjah</>,
    docs: ['Certificate of Origin', 'Commercial Invoice', 'Bill of Lading', 'Halal Certificate (food)', 'FIRS Certificate'],
    facilitation: 'Trade facilitation, re-export coordination, Gulf buyer network'
  },
  saudi: {
    name: 'Saudi Arabia',
    nameHtml: <>Saudi <span>Arabia</span></>,
    stats: [
      { value: '$2.1B', label: 'Exports' },
      { value: '$3.8B', label: 'Imports' },
      { value: 'Deficit', label: 'Balance' }
    ],
    exportFlow: 'Rice (Basmati), textiles, meat, cement, surgical instruments',
    importFlow: 'Petroleum, plastics, chemicals',
    agreementLabel: 'Trade Agreement',
    agreementValue: 'OIC Trade Preferential System',
    ports: <><strong>Key Ports:</strong> Karachi &#8594; Jeddah, Dammam</>,
    docs: ['SASO Conformity Certificate', 'Halal Certificate', 'Certificate of Origin', 'Bill of Lading', 'Commercial Invoice'],
    facilitation: 'Saudi compliance (SASO/SABER), halal certification, buyer connections'
  },
  china: {
    name: 'China',
    nameHtml: <><span>China</span></>,
    stats: [
      { value: '$3.2B', label: 'Exports' },
      { value: '$14.5B', label: 'Imports' },
      { value: 'Deficit', label: 'Balance' }
    ],
    exportFlow: 'Rice, cotton yarn, copper ore, seafood, leather',
    importFlow: 'Machinery, electronics, steel, vehicles, chemicals',
    agreementLabel: 'Trade Agreement',
    agreementValue: 'China-Pakistan FTA Phase II \u2014 reduced tariffs on 313 lines',
    ports: <><strong>Key Ports:</strong> Karachi / Gwadar &#8594; Shanghai, Shenzhen, Ningbo</>,
    docs: ['FTA Certificate of Origin', 'CIQ Inspection Certificate', 'Bill of Lading', 'Commercial Invoice', 'Packing List'],
    facilitation: 'CPEC trade facilitation, Chinese buyer matching, Gwadar port coordination'
  },
  us: {
    name: 'United States',
    nameHtml: <>United <span>States</span></>,
    stats: [
      { value: '$5.3B', label: 'Exports' },
      { value: '$2.1B', label: 'Imports' },
      { value: 'Surplus', label: 'Balance' }
    ],
    exportFlow: 'Textiles, surgical instruments, rice, leather goods, IT services',
    importFlow: 'Cotton, machinery, aircraft parts, soybeans',
    agreementLabel: 'Trade Agreement',
    agreementValue: 'No FTA \u2014 standard MFN tariffs',
    ports: <><strong>Key Ports:</strong> Karachi &#8594; Los Angeles, New York / New Jersey</>,
    docs: ['Commercial Invoice', 'Packing List', 'Bill of Lading', 'ISF (10+2) Filing', 'FDA Registration (food)', 'CPSC Certification (consumer goods)'],
    facilitation: 'US compliance, FDA/CPSC navigation, logistics coordination'
  },
  uk: {
    name: 'United Kingdom',
    nameHtml: <>United <span>Kingdom</span></>,
    stats: [
      { value: '$2.1B', label: 'Exports' },
      { value: '$0.9B', label: 'Imports' },
      { value: 'Surplus', label: 'Balance' }
    ],
    exportFlow: 'Textiles, rice, surgical instruments, leather, sports goods',
    importFlow: 'Machinery, vehicles, pharmaceuticals',
    agreementLabel: 'Trade Agreement',
    agreementValue: 'UK DCTS \u2014 zero duty, post-Brexit GSP equivalent',
    ports: <><strong>Key Ports:</strong> Karachi &#8594; Felixstowe, Southampton</>,
    docs: ['UK DCTS Certificate', 'Certificate of Origin', 'Bill of Lading', 'UKCA Marking (applicable goods)'],
    facilitation: 'Post-Brexit trade structuring, UK buyer network, DCTS documentation'
  },
  africa: {
    name: 'Africa',
    nameHtml: <>Africa <span>(Kenya, Nigeria, South Africa)</span></>,
    stats: [
      { value: '$2.8B', label: 'Exports' },
      { value: '$0.5B', label: 'Imports' },
      { value: 'Surplus', label: 'Balance' }
    ],
    exportFlow: 'Rice, pharmaceuticals, textiles, cement, surgical instruments',
    importFlow: 'Tea, coffee, raw minerals, sesame',
    agreementLabel: 'Trade Agreement',
    agreementValue: 'Various bilateral agreements',
    ports: <><strong>Key Ports:</strong> Karachi &#8594; Mombasa, Lagos, Durban</>,
    docs: ['Certificate of Origin', 'Commercial Invoice', 'SON Conformity (Nigeria)', 'KEBS Certificate (Kenya)', 'Pre-shipment Inspection'],
    facilitation: 'African market entry, pharma distribution, rice export facilitation'
  }
};

const destOrder = ['eu', 'uae', 'saudi', 'china', 'us', 'uk', 'africa'];

export default function ImportExportPage() {
  const [activeDest, setActiveDest] = useState('eu');
  const wrapperRef = useRef<HTMLDivElement>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('visible');
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => {
      observerRef.current?.observe(el);
    });

    return () => observerRef.current?.disconnect();
  }, []);

  const route = tradeRoutes[activeDest];

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Import-Export.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">International Trade</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Import &amp;<br /><span className="gold">Export.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Trade facilitation through CZAAH&apos;s international trade network &mdash; customs clearance, trade documentation, logistics coordination, supplier connections, and export management.</p>
              <a href="/contact?interest=Import%20%26%20Export#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Facilitate Trade &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* TRADE ROUTE EXPLORER */}
        <section className="section fade-in">
          <h2 className="serif">Trade Route <span className="gold">Explorer.</span></h2>
          <p className="subtitle">Select a destination to explore Pakistan&apos;s trade profile — volumes, key products, required documentation, and how CZAAH facilitates each corridor.</p>

          <style>{`
            .ie-dest-row {
              display: flex; gap: 10px; overflow-x: auto; padding-bottom: 12px; margin-bottom: 32px;
              scrollbar-width: thin; scrollbar-color: var(--gold) transparent;
            }
            .ie-dest-row::-webkit-scrollbar { height: 4px; }
            .ie-dest-row::-webkit-scrollbar-thumb { background: var(--gold); border-radius: 2px; }
            .ie-dest-btn {
              flex-shrink: 0; padding: 12px 24px; border: 1px solid var(--black-border);
              background: var(--black-card); color: var(--white-muted); font-family: 'Raleway', sans-serif;
              font-size: 0.85rem; font-weight: 500; letter-spacing: 0.04em; cursor: pointer;
              border-radius: 4px; transition: all 0.3s var(--ease-smooth); white-space: nowrap;
            }
            .ie-dest-btn:hover { border-color: var(--gold); color: var(--white); }
            .ie-dest-btn.ie-active {
              background: var(--gold); color: #000; border-color: var(--gold); font-weight: 600;
            }
            .ie-panel-inner {
              display: grid; grid-template-columns: 1fr 1fr; gap: 32px;
              background: var(--black-card); border: 1px solid var(--black-border);
              border-radius: 8px; padding: 32px;
            }
            @media (max-width: 768px) {
              .ie-panel-inner { grid-template-columns: 1fr; padding: 24px; }
            }
            .ie-left h3 {
              font-family: 'Cinzel', serif; font-size: 1.5rem; color: var(--white); margin-bottom: 20px;
            }
            .ie-left h3 span { color: var(--gold); }
            .ie-trade-stats {
              display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-bottom: 24px;
            }
            .ie-stat {
              background: var(--black-elevated); border-radius: 6px; padding: 16px; text-align: center;
            }
            .ie-stat-value {
              font-family: 'Raleway', sans-serif; font-size: 1.25rem; font-weight: 600;
              color: var(--gold); margin-bottom: 4px;
            }
            .ie-stat-label {
              font-size: 0.75rem; color: var(--white-dim); text-transform: uppercase; letter-spacing: 0.06em;
            }
            .ie-flow {
              display: flex; align-items: center; gap: 12px; background: var(--black-elevated);
              border-radius: 6px; padding: 14px 18px; margin-bottom: 16px; font-size: 0.85rem;
              color: var(--white-muted);
            }
            .ie-flow-arrow { color: var(--gold); font-size: 1.1rem; flex-shrink: 0; }
            .ie-flow-label { font-weight: 600; color: var(--white); min-width: 56px; }
            .ie-agreement {
              background: var(--black-elevated); border-left: 3px solid var(--gold);
              padding: 14px 18px; border-radius: 0 6px 6px 0; margin-bottom: 16px;
            }
            .ie-agreement-label {
              font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em;
              color: var(--gold-dim); margin-bottom: 4px;
            }
            .ie-agreement-value { font-size: 0.9rem; color: var(--white); font-weight: 500; }
            .ie-ports { font-size: 0.85rem; color: var(--white-muted); margin-bottom: 0; }
            .ie-ports strong { color: var(--white); font-weight: 500; }
            .ie-right h4 {
              font-family: 'Raleway', sans-serif; font-size: 0.75rem; text-transform: uppercase;
              letter-spacing: 0.1em; color: var(--gold); margin-bottom: 10px; margin-top: 0;
            }
            .ie-right h4:not(:first-child) { margin-top: 20px; }
            .ie-doc-list { display: grid; gap: 8px; list-style: none; padding: 0; margin: 0; }
            .ie-doc-item { display: flex; align-items: center; gap: 10px; font-size: 0.85rem; color: var(--white-muted); }
            .ie-doc-check { color: var(--gold); font-size: 0.9rem; flex-shrink: 0; }
            .ie-role {
              background: linear-gradient(135deg, rgba(201,168,76,0.08), rgba(201,168,76,0.03));
              border: 1px solid rgba(201,168,76,0.2); border-radius: 6px; padding: 16px 18px; margin-top: 20px;
            }
            .ie-role-label {
              font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em;
              color: var(--gold); margin-bottom: 6px;
            }
            .ie-role-text { font-size: 0.85rem; color: var(--white-muted); line-height: 1.6; }
            .ie-cta {
              display: block; text-align: center; margin-top: 24px; padding: 14px 32px;
              background: var(--gold); color: #000; font-family: 'Raleway', sans-serif;
              font-weight: 600; font-size: 0.9rem; letter-spacing: 0.04em; border-radius: 4px;
              text-decoration: none; transition: opacity 0.3s var(--ease-smooth);
            }
            .ie-cta:hover { opacity: 0.88; }
          `}</style>

          <div className="ie-dest-row">
            {destOrder.map(key => (
              <button
                key={key}
                className={`ie-dest-btn${activeDest === key ? ' ie-active' : ''}`}
                onClick={() => setActiveDest(key)}
              >
                {tradeRoutes[key].name}
              </button>
            ))}
          </div>

          <div ref={wrapperRef}>
            <div className="ie-panel-inner">
              <div className="ie-left">
                <h3>{route.nameHtml}</h3>
                <div className="ie-trade-stats">
                  {route.stats.map((s, i) => (
                    <div key={i} className="ie-stat">
                      <div className="ie-stat-value">{s.value}</div>
                      <div className="ie-stat-label">{s.label}</div>
                    </div>
                  ))}
                </div>
                <div className="ie-flow">
                  <span className="ie-flow-label">Export</span><span className="ie-flow-arrow">&#10140;</span> {route.exportFlow}
                </div>
                <div className="ie-flow">
                  <span className="ie-flow-label">Import</span><span className="ie-flow-arrow">&#10140;</span> {route.importFlow}
                </div>
                <div className="ie-agreement">
                  <div className="ie-agreement-label">{route.agreementLabel}</div>
                  <div className="ie-agreement-value">{route.agreementValue}</div>
                </div>
                <p className="ie-ports">{route.ports}</p>
              </div>
              <div className="ie-right">
                <h4>Required Documents</h4>
                <ul className="ie-doc-list">
                  {route.docs.map((doc, i) => (
                    <li key={i} className="ie-doc-item">
                      <span className="ie-doc-check">&#10003;</span> {doc}
                    </li>
                  ))}
                </ul>
                <div className="ie-role">
                  <div className="ie-role-label">CZAAH Facilitation</div>
                  <div className="ie-role-text">{route.facilitation}</div>
                </div>
              </div>
            </div>
            <a href="/contact" className="ie-cta">Facilitate This Route &rarr;</a>
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Complete trade facilitation — from customs clearance and documentation to logistics and market access.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>Customs Clearance</h3>
              <p>WeBOC processing, duty optimization strategies, clearance acceleration, and customs liaison. We ensure your goods move through Pakistan&apos;s ports efficiently and cost-effectively.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9881;</div>
              <h3>Trade Documentation</h3>
              <p>Letters of credit, bills of lading, certificates of origin, phytosanitary certificates, and all required trade documentation — prepared accurately and processed on time.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Logistics Coordination</h3>
              <p>Freight forwarding, shipping line coordination, warehousing, and last-mile delivery management. We orchestrate the entire supply chain from origin to destination.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8644;</div>
              <h3>Supplier Matching</h3>
              <p>Access our vetted network of manufacturers and suppliers across Pakistan. We match your product requirements with reliable producers — quality-assured and compliance-verified.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#36;</div>
              <h3>Export Management</h3>
              <p>GSP+ documentation for EU market access, US and Gulf compliance requirements, quality assurance protocols, and complete export management for Pakistani goods entering global markets.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#43;</div>
              <h3>Trade Finance</h3>
              <p>Letter of credit facilitation, payment structuring between buyers and suppliers, foreign exchange management, and trade finance solutions that protect all parties in the transaction.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">Trade capabilities <span className="gold">at a glance.</span></h2>
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">6+</div>
              <div className="label">International trade corridors</div>
            </div>
            <div className="stat-item">
              <div className="number">GSP+</div>
              <div className="label">EU market access</div>
            </div>
            <div className="stat-item">
              <div className="number">150+</div>
              <div className="label">Trade routes</div>
            </div>
            <div className="stat-item">
              <div className="number">$16B+</div>
              <div className="label">Pakistan textile exports alone</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* WHY CZAAH */}
        <section className="section fade-in">
          <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
          <p className="subtitle">Our international network and deep trade expertise make us uniquely positioned to facilitate Pakistan&apos;s international commerce.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>International Reach</h4>
                <p>CZAAH&apos;s international trade network enables USD invoicing, clean international payments, and efficient cross-border transactions for importers and exporters across global markets.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>Port &amp; Customs Relationships</h4>
                <p>Established relationships with customs authorities, port operators, and clearing agents at Karachi Port, Port Qasim, and Gwadar. We accelerate clearance and resolve issues before they become delays.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>Gulf Trade Network</h4>
                <p>Our network provides direct access to Gulf buyers, re-export channels, and commodities trading ecosystems — connecting Pakistani products to one of the world&apos;s largest trading hubs.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#8644;</div>
              <div>
                <h4>Compliance Expertise</h4>
                <p>Deep knowledge of GSP+ requirements, EU product standards, US import regulations, and Gulf market specifications. We ensure every shipment meets destination market compliance requirements.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Trade across borders, <span className="gold">structured.</span></h2>
          <p>Customs, documentation, logistics, and supplier connections &mdash; through our international trade network.</p>
          <a href="/contact?interest=Import%20%26%20Export#contact-form" className="btn-gold">Discuss Trade Requirements &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
