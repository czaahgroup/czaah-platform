'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

const fleetData = [
  { category: 'sedan', classLabel: 'Executive Sedan', name: 'Mercedes-Benz S-Class', specs: ['4 passengers', 'Chauffeur driven', 'Wi-Fi & privacy glass'], desc: "The global standard for executive travel. Latest S-Class with premium interior, rear entertainment, and complete discretion. Available across Islamabad, Lahore, and Karachi.", img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=Mercedes+S-Class' },
  { category: 'sedan', classLabel: 'Executive Sedan', name: 'BMW 7 Series', specs: ['4 passengers', 'Executive lounge rear', 'Night vision'], desc: 'Ultimate driving comfort meets executive presence. Extended wheelbase with rear executive lounge seating, Bowers & Wilkins surround, and gesture control.', img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=BMW+7+Series' },
  { category: 'suv', classLabel: 'Luxury SUV', name: 'Toyota Land Cruiser 300', specs: ['6 passengers', 'All-terrain', 'Inter-city capable'], desc: "Pakistan's most trusted luxury SUV. Engineered for every road condition — from Islamabad's diplomatic enclave to Balochistan's mine sites. The vehicle of choice for corporate inter-city travel.", img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=Land+Cruiser+300' },
  { category: 'suv', classLabel: 'Luxury SUV', name: 'Range Rover Autobiography', specs: ['4 passengers', 'Meridian audio', 'Executive 4-seat config'], desc: "British luxury meets all-terrain capability. The Autobiography's executive 4-seat configuration transforms inter-city journeys into first-class experiences.", img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=Range+Rover' },
  { category: 'suv', classLabel: 'Prestige SUV', name: 'Mercedes GLS 600 Maybach', specs: ['4 passengers', 'Maybach luxury', 'Champagne cooler'], desc: 'The pinnacle of SUV luxury. Maybach-grade interior with individual rear seats, champagne cooler, and noise-cancelling cabin. For when presence must be absolute.', img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=Mercedes+Maybach+GLS' },
  { category: 'armoured', classLabel: 'Armoured Vehicle', name: 'Armoured Land Cruiser (B6+)', specs: ['4 passengers', 'B6+ protection', 'Run-flat tyres'], desc: 'Certified ballistic protection to B6+ standard. Armoured body panels, ballistic glass, run-flat tyres, and emergency communications. Maintained and re-certified annually. Security driver included.', img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=Armoured+LC300' },
  { category: 'armoured', classLabel: 'Armoured Sedan', name: 'Armoured Mercedes S-Guard', specs: ['3 passengers', 'B6+ protection', 'Discreet profile'], desc: 'Executive protection without the convoy look. Factory-armoured Mercedes S-Guard maintains a civilian profile while delivering military-grade ballistic protection. Ideal for diplomatic and corporate principals.', img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=Mercedes+S-Guard' },
  { category: 'prestige', classLabel: 'Prestige', name: 'Rolls-Royce Phantom', specs: ['3 passengers', 'Event & occasion', 'Advance booking only'], desc: 'Reserved for moments that demand the extraordinary. Weddings, state-level hospitality, and occasions where the vehicle IS the statement. Limited availability — advance booking essential.', img: 'https://placehold.co/700x320/0a0a0a/C9A84C?text=Rolls-Royce+Phantom' },
];

export default function LuxuryRentalsPage() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [quoteSubmitted, setQuoteSubmitted] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => { entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add('visible'); }); },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach((el) => { observerRef.current?.observe(el); });
    return () => observerRef.current?.disconnect();
  }, []);

  function handleQuoteSubmit(e: React.FormEvent) {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const selects = form.querySelectorAll('.lx-form-select') as NodeListOf<HTMLSelectElement>;
    const dateInput = form.querySelector('#lxDate') as HTMLInputElement;
    let valid = true;
    selects.forEach(sel => {
      if (!sel.value) { sel.style.borderColor = '#c0392b'; valid = false; } else { sel.style.borderColor = ''; }
    });
    if (dateInput && !dateInput.value) { dateInput.style.borderColor = '#c0392b'; valid = false; } else if (dateInput) { dateInput.style.borderColor = ''; }
    if (!valid) return;
    setQuoteSubmitted(true);
  }

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/LuxuryCars.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Executive Ground Transport</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Luxury Car<br /><span className="gold">Rental Fleets.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Premium and armoured vehicle fleets for executives, delegations, and high-profile clients across Pakistan and the Gulf &mdash; from daily executive transport to long-term corporate fleet programmes.</p>
              <a href="/contact?interest=Luxury%20Car%20Rentals#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Reserve a Vehicle &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* FLEET GALLERY */}
        <style>{`
          .lx-gallery { max-width: 1200px; margin: 0 auto; padding: 80px 32px; }
          .lx-gallery-title { font-family: 'Cinzel', serif; font-size: 40px; color: var(--white); margin-bottom: 8px; }
          .lx-gallery-subtitle { color: var(--white-muted); font-size: 15px; margin-bottom: 40px; }
          .lx-filters { display: flex; gap: 12px; margin-bottom: 48px; flex-wrap: wrap; }
          .lx-filter-pill { background: transparent; border: 1px solid var(--black-border); color: var(--white-muted); padding: 10px 24px; border-radius: 100px; cursor: pointer; font-family: 'Raleway', sans-serif; font-size: 13px; font-weight: 500; letter-spacing: 0.05em; text-transform: uppercase; transition: all 0.3s var(--ease-smooth); }
          .lx-filter-pill:hover { border-color: var(--gold-dim); color: var(--white); }
          .lx-filter-pill.active { background: var(--gold); border-color: var(--gold); color: #000; }
          .lx-fleet-list { display: flex; flex-direction: column; gap: 28px; }
          .lx-vehicle-card { display: flex; border: 1px solid var(--black-border); border-radius: 12px; overflow: hidden; background: var(--black-card); height: 320px; transition: border-color 0.3s var(--ease-smooth), box-shadow 0.3s var(--ease-smooth); }
          .lx-vehicle-card.lx-hidden { display: none; }
          .lx-vehicle-card:hover { border-color: var(--gold-dim); box-shadow: 0 0 30px rgba(201, 168, 76, 0.08); }
          .lx-vehicle-img { width: 55%; position: relative; overflow: hidden; }
          .lx-vehicle-img img { width: 100%; height: 100%; object-fit: cover; transition: filter 0.4s var(--ease-smooth), transform 0.4s var(--ease-smooth); }
          .lx-vehicle-card:hover .lx-vehicle-img img { filter: brightness(1.1); transform: scale(1.02); }
          .lx-vehicle-img::after { content: ''; position: absolute; top: 0; right: 0; bottom: 0; width: 80px; background: linear-gradient(to right, transparent, var(--black-card)); }
          .lx-vehicle-info { width: 45%; padding: 40px 36px; display: flex; flex-direction: column; justify-content: center; }
          .lx-vehicle-class { font-size: 11px; letter-spacing: 0.15em; text-transform: uppercase; color: var(--gold); font-weight: 500; margin-bottom: 12px; }
          .lx-vehicle-name { font-family: 'Cinzel', serif; font-size: 30px; color: var(--white); margin-bottom: 16px; line-height: 1.2; }
          .lx-vehicle-specs { display: flex; gap: 20px; margin-bottom: 18px; flex-wrap: wrap; }
          .lx-vehicle-specs span { font-size: 12px; color: var(--white-dim); letter-spacing: 0.03em; padding: 5px 12px; background: var(--black-elevated); border-radius: 6px; white-space: nowrap; }
          .lx-vehicle-desc { font-size: 14px; color: var(--white-muted); line-height: 1.7; margin-bottom: 24px; }
          .lx-reserve-link { font-size: 13px; color: var(--gold); text-decoration: none; font-weight: 500; letter-spacing: 0.05em; transition: color 0.3s; }
          .lx-reserve-link:hover { color: var(--gold-light); }
          .lx-quote-section { max-width: 1200px; margin: 0 auto; padding: 80px 32px; }
          .lx-quote-title { font-family: 'Cinzel', serif; font-size: 36px; color: var(--white); margin-bottom: 8px; }
          .lx-quote-subtitle { color: var(--white-muted); font-size: 15px; margin-bottom: 40px; }
          .lx-quote-card { background: var(--black-card); border: 1px solid var(--black-border); border-radius: 12px; padding: 40px; border-top: 2px solid var(--gold); }
          .lx-quote-form { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
          .lx-form-group { display: flex; flex-direction: column; }
          .lx-form-group.lx-full-width { grid-column: 1 / -1; }
          .lx-form-label { font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--gold); margin-bottom: 8px; font-weight: 500; }
          .lx-form-input, .lx-form-select { background: var(--black-elevated); border: 1px solid var(--black-border); color: var(--white); padding: 14px 16px; border-radius: 8px; font-family: 'Raleway', sans-serif; font-size: 14px; transition: border-color 0.3s var(--ease-smooth); outline: none; width: 100%; box-sizing: border-box; }
          .lx-form-input:focus, .lx-form-select:focus { border-color: var(--gold); }
          .lx-quote-submit { display: inline-flex; align-items: center; gap: 8px; background: var(--gold); color: #000; border: none; padding: 16px 36px; border-radius: 8px; font-family: 'Raleway', sans-serif; font-size: 14px; font-weight: 600; letter-spacing: 0.05em; cursor: pointer; transition: background 0.3s var(--ease-smooth), transform 0.2s; margin-top: 8px; }
          .lx-quote-submit:hover { background: var(--gold-light); transform: translateY(-1px); }
          .lx-quote-note { font-size: 12px; color: var(--white-dim); margin-top: 20px; }
          .lx-quote-success { display: none; text-align: center; padding: 48px 24px; }
          .lx-quote-success.lx-visible { display: block; }
          .lx-quote-success-icon { font-size: 48px; margin-bottom: 16px; color: var(--gold); }
          .lx-quote-success h3 { font-family: 'Cinzel', serif; font-size: 28px; color: var(--white); margin-bottom: 12px; }
          .lx-quote-success p { color: var(--white-muted); font-size: 15px; }
          @media (max-width: 1024px) { .lx-vehicle-card { height: auto; } .lx-vehicle-img { width: 45%; min-height: 280px; } .lx-vehicle-info { width: 55%; padding: 32px 28px; } .lx-vehicle-name { font-size: 26px; } }
          @media (max-width: 768px) { .lx-gallery { padding: 60px 20px; } .lx-gallery-title { font-size: 30px; } .lx-vehicle-card { flex-direction: column; height: auto; } .lx-vehicle-img { width: 100%; height: 200px; min-height: auto; } .lx-vehicle-img::after { display: none; } .lx-vehicle-info { width: 100%; padding: 24px 20px; } .lx-vehicle-name { font-size: 24px; } .lx-vehicle-specs { gap: 8px; } .lx-quote-section { padding: 60px 20px; } .lx-quote-form { grid-template-columns: 1fr; } .lx-quote-card { padding: 28px 20px; } .lx-filters { gap: 8px; } .lx-filter-pill { padding: 8px 16px; font-size: 12px; } }
        `}</style>

        <section className="lx-gallery fade-in">
          <h2 className="lx-gallery-title">The <span className="gold">Fleet.</span></h2>
          <p className="lx-gallery-subtitle">Eight classes of vehicle. One standard of excellence.</p>

          <div className="lx-filters">
            {[{ label: 'All', val: 'all' }, { label: 'Executive Sedans', val: 'sedan' }, { label: 'Luxury SUVs', val: 'suv' }, { label: 'Armoured', val: 'armoured' }, { label: 'Prestige', val: 'prestige' }].map(f => (
              <button key={f.val} className={`lx-filter-pill${activeFilter === f.val ? ' active' : ''}`} onClick={() => setActiveFilter(f.val)}>{f.label}</button>
            ))}
          </div>

          <div className="lx-fleet-list">
            {fleetData.map((v, i) => (
              <div key={i} className={`lx-vehicle-card${activeFilter !== 'all' && v.category !== activeFilter ? ' lx-hidden' : ''}`}>
                <div className="lx-vehicle-img">
                  <img src={v.img} alt={v.name} loading="lazy" />
                </div>
                <div className="lx-vehicle-info">
                  <div className="lx-vehicle-class">{v.classLabel}</div>
                  <div className="lx-vehicle-name">{v.name}</div>
                  <div className="lx-vehicle-specs">
                    {v.specs.map((s, j) => (<span key={j}>{s}</span>))}
                  </div>
                  <p className="lx-vehicle-desc">{v.desc}</p>
                  <a href="/contact" className="lx-reserve-link">Reserve &rarr;</a>
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="divider"></div>

        {/* QUICK QUOTE */}
        <section className="lx-quote-section fade-in">
          <h2 className="lx-quote-title">Quick <span className="gold">Quote.</span></h2>
          <p className="lx-quote-subtitle">Tell us what you need. We will respond with availability and pricing.</p>

          <div className="lx-quote-card">
            {!quoteSubmitted ? (
              <form className="lx-quote-form" onSubmit={handleQuoteSubmit}>
                <div className="lx-form-group">
                  <label className="lx-form-label" htmlFor="lxVehicleClass">Vehicle Class</label>
                  <select className="lx-form-select" id="lxVehicleClass" required defaultValue="">
                    <option value="" disabled>Select vehicle class</option>
                    <option value="Executive Sedan">Executive Sedan</option>
                    <option value="Luxury SUV">Luxury SUV</option>
                    <option value="Armoured Vehicle">Armoured Vehicle</option>
                    <option value="Prestige / Occasion">Prestige / Occasion</option>
                    <option value="Full Fleet (Multiple Vehicles)">Full Fleet (Multiple Vehicles)</option>
                  </select>
                </div>
                <div className="lx-form-group">
                  <label className="lx-form-label" htmlFor="lxServiceType">Service Type</label>
                  <select className="lx-form-select" id="lxServiceType" required defaultValue="">
                    <option value="" disabled>Select service type</option>
                    <option value="Airport Transfer">Airport Transfer</option>
                    <option value="Daily Chauffeur">Daily Chauffeur</option>
                    <option value="Multi-Day Hire">Multi-Day Hire</option>
                    <option value="Corporate Contract">Corporate Contract</option>
                    <option value="Event / Wedding">Event / Wedding</option>
                    <option value="Self-Drive">Self-Drive</option>
                  </select>
                </div>
                <div className="lx-form-group">
                  <label className="lx-form-label" htmlFor="lxCity">City</label>
                  <select className="lx-form-select" id="lxCity" required defaultValue="">
                    <option value="" disabled>Select city</option>
                    <option value="Islamabad">Islamabad</option>
                    <option value="Lahore">Lahore</option>
                    <option value="Karachi">Karachi</option>
                    <option value="Peshawar">Peshawar</option>
                    <option value="Inter-City">Inter-City</option>
                    <option value="Gulf (Dubai/Abu Dhabi)">Gulf (Dubai/Abu Dhabi)</option>
                  </select>
                </div>
                <div className="lx-form-group">
                  <label className="lx-form-label" htmlFor="lxDuration">Duration</label>
                  <select className="lx-form-select" id="lxDuration" required defaultValue="">
                    <option value="" disabled>Select duration</option>
                    <option value="Single Trip">Single Trip</option>
                    <option value="Full Day (8hrs)">Full Day (8hrs)</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Custom">Custom</option>
                  </select>
                </div>
                <div className="lx-form-group">
                  <label className="lx-form-label" htmlFor="lxDate">Date Required</label>
                  <input type="date" className="lx-form-input" id="lxDate" required />
                </div>
                <div className="lx-form-group">
                  <label className="lx-form-label" htmlFor="lxRequirements">Special Requirements</label>
                  <input type="text" className="lx-form-input" id="lxRequirements" placeholder="e.g. security driver, child seat, multiple vehicles..." />
                </div>
                <div className="lx-form-group lx-full-width" style={{ alignItems: 'flex-start' }}>
                  <button type="submit" className="lx-quote-submit">Request Quote &rarr;</button>
                  <p className="lx-quote-note">Quotes typically returned within 2 hours during business hours.</p>
                </div>
              </form>
            ) : (
              <div className="lx-quote-success lx-visible">
                <div className="lx-quote-success-icon">&#10003;</div>
                <h3>Quote Request <span className="gold">Received.</span></h3>
                <p>Our fleet team will review your requirements and respond with availability and pricing shortly.</p>
              </div>
            )}
          </div>
        </section>

        <div className="divider"></div>

        {/* TWO PILLARS */}
        <section className="section fade-in-left">
          <div className="split">
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Executive Fleet</div>
              <h3 className="serif">Arrive like you <span className="gold">mean business.</span></h3>
              <p>Our executive fleet includes the latest models from Mercedes-Benz, BMW, Audi, Land Rover, and Toyota Land Cruiser — maintained to international standards and available with professional chauffeurs across Islamabad, Lahore, Karachi, and Gulf cities.</p>
              <p>Whether it&apos;s airport transfers, multi-day business trips, or full corporate fleet contracts, every vehicle is presented immaculately with real-time tracking, backup vehicle guarantee, and 24/7 dispatch capability.</p>
              <p>For visiting executives, investor delegations, and diplomatic parties, our fleet ensures your ground transport matches the professionalism of your operations.</p>
            </div>
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Armoured &amp; Security</div>
              <h3 className="serif">Protection on <span className="gold">every route.</span></h3>
              <p>For clients requiring enhanced security — mining executives in Balochistan, diplomatic personnel, or high-profile corporate visitors — CZAAH provides armoured vehicle services with trained security drivers and route planning.</p>
              <p>Our armoured fleet includes B6 and B6+ certified vehicles from leading manufacturers, maintained to ballistic protection standards with regular certification. Integrated with our security services division for comprehensive protection packages.</p>
              <p>Route reconnaissance, convoy coordination, and secure parking arrangements are standard. We operate where others can&apos;t — safely and discreetly.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">fleet services.</span></h2>
          <p className="subtitle">Comprehensive luxury ground transport for every requirement.</p>
          <div className="detail-grid stagger">
            <div className="detail-card"><div className="card-icon">&#9733;</div><h3>Executive Chauffeur</h3><p>Professional chauffeur-driven luxury vehicles for daily executive transport, airport transfers, and business travel. Vetted drivers with security clearance, city knowledge, and discretion as standard.</p></div>
            <div className="detail-card"><div className="card-icon">&#9670;</div><h3>Corporate Fleet Contracts</h3><p>Long-term vehicle leasing and fleet management for corporations operating in Pakistan. Dedicated vehicles, assigned drivers, maintenance, insurance, and fleet administration handled end-to-end.</p></div>
            <div className="detail-card"><div className="card-icon">&#9632;</div><h3>Armoured Transport</h3><p>B6/B6+ armoured SUVs and sedans with trained protection drivers. Route planning, convoy operations, and integration with close protection teams for high-risk environments.</p></div>
            <div className="detail-card"><div className="card-icon">&#9992;</div><h3>VIP Delegation Fleets</h3><p>Multi-vehicle coordination for visiting delegations, investor tours, and corporate events. Matching vehicles, uniformed drivers, and real-time fleet tracking across multiple cities simultaneously.</p></div>
            <div className="detail-card"><div className="card-icon">&#43;</div><h3>Self-Drive Luxury</h3><p>Self-drive rental of premium vehicles for clients who prefer independence. Late-model luxury SUVs and sedans with comprehensive insurance, roadside assistance, and GPS navigation.</p></div>
            <div className="detail-card"><div className="card-icon">&#8644;</div><h3>Wedding &amp; Event Fleets</h3><p>Prestige vehicle fleets for weddings, corporate galas, and high-profile events. Rolls-Royce, Bentley, and Mercedes S-Class available for special occasions with decorated presentation.</p></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* FLEET */}
        <section className="section fade-in">
          <h2 className="serif">The <span className="gold">fleet.</span></h2>
          <p className="subtitle">Premium vehicles maintained to international standards.</p>
          <div className="relationships stagger">
            <div className="rel-card"><div className="rel-icon">&#9733;</div><div><h4>Executive Sedans</h4><p>Mercedes S-Class, BMW 7 Series, Audi A8 — the standard for executive business travel. Latest models with premium interiors, Wi-Fi, and privacy glass.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9670;</div><div><h4>Luxury SUVs</h4><p>Toyota Land Cruiser 300, Range Rover, Mercedes GLS, BMW X7 — capable on any terrain, comfortable on every road. Essential for site visits and inter-city travel across Pakistan.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9632;</div><div><h4>Armoured Vehicles</h4><p>B6/B6+ certified Toyota Land Cruiser and Mercedes S-Guard. Ballistic glass, run-flat tyres, reinforced body panels, and communications equipment. Regularly re-certified to protection standards.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9881;</div><div><h4>Prestige &amp; Occasion</h4><p>Rolls-Royce, Bentley, Mercedes-Maybach — available for weddings, diplomatic events, and occasions where presence matters. Limited availability, advance booking required.</p></div></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <div className="stats-row stagger">
            <div className="stat-item"><div className="number">24/7</div><div className="label">Dispatch availability</div></div>
            <div className="stat-item"><div className="number">3</div><div className="label">Cities covered</div></div>
            <div className="stat-item"><div className="number">B6+</div><div className="label">Armoured protection level</div></div>
            <div className="stat-item"><div className="number">VIP</div><div className="label">Delegation capability</div></div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Ground transport, <span className="gold">elevated.</span></h2>
          <p>Premium vehicles, professional chauffeurs, and security logistics &mdash; across Pakistan&apos;s major cities.</p>
          <a href="/contact?interest=Luxury%20Car%20Rentals#contact-form" className="btn-gold">Reserve a Vehicle &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
