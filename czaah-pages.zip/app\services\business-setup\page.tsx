'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

const entities: Record<string, {
  steps: string[];
  docs: string[];
  timeline: string;
  jurisdiction: string;
  keyInfo: string;
  description: string;
}> = {
  plc: {
    steps: ['Name reservation (SECP)', 'Digital filing & incorporation', 'NTN & tax registration (FBR)', 'Bank account opening', 'Registered office setup', 'Compliance infrastructure'],
    docs: ['Passport copies', 'Power of Attorney', 'MOA/AOA drafts', 'Proof of address', 'Director details'],
    timeline: '7\u201315 business days',
    jurisdiction: 'Pakistan (SECP)',
    keyInfo: 'Min. 2 directors, min. 1 shareholder, PKR 100K min. capital',
    description: 'Private Limited Company'
  },
  smc: {
    steps: ['Name reservation', 'SMC incorporation (SECP)', 'FBR registration', 'Bank account', 'Office setup'],
    docs: ['Passport / CNIC', 'Address proof', 'Nominee director details'],
    timeline: '5\u201310 business days',
    jurisdiction: 'Pakistan (SECP)',
    keyInfo: '1 member only, limited liability, annual compliance required',
    description: 'Single Member Company'
  },
  branch: {
    steps: ['BOI permission application', 'SBP approval (if needed)', 'SECP registration', 'FBR registration', 'Office establishment', 'Reporting setup'],
    docs: ['Parent company incorporation docs', 'Board resolution', 'Financial statements', 'Power of Attorney'],
    timeline: '30\u201360 business days (BOI approval)',
    jurisdiction: 'Pakistan (BOI + SECP)',
    keyInfo: 'Cannot trade directly (liaison), repatriation of profits (branch), annual audit required',
    description: 'Branch / Liaison Office'
  },
  jv: {
    steps: ['Partner identification & vetting', 'JV agreement negotiation', 'SPV incorporation (SECP)', 'Tax & regulatory setup', 'Operational launch', 'Governance framework'],
    docs: ['JV agreement', 'Shareholder agreement', 'MOA/AOA', 'Partner due diligence package'],
    timeline: '30\u201390 days (depending on complexity)',
    jurisdiction: 'Pakistan (cross-border options available)',
    keyInfo: 'Equity split negotiation, board composition, profit sharing, exit mechanisms',
    description: 'Joint Venture Structure'
  },
  spv: {
    steps: ['Structure design', 'SPV incorporation', 'Investment agreement', 'Regulatory filings', 'Capital deployment', 'Reporting & governance'],
    docs: ['Investment agreement', 'Trust deed (if applicable)', 'Regulatory filings', 'Compliance framework'],
    timeline: '10\u201320 business days',
    jurisdiction: 'Pakistan (international options available)',
    keyInfo: 'Asset isolation, investor protection, defined exit, project-specific governance',
    description: 'Special Purpose Vehicle (SPV)'
  },
  dmcc: {
    steps: ['Jurisdiction assessment', 'License selection (trade/service)', 'Visa allocation', 'Office / flexi-desk setup', 'Bank account (USD)', 'Pakistan entity linkage'],
    docs: ['Passport copies', 'Business plan', 'Proof of address', 'Bank reference letter'],
    timeline: '10\u201320 business days',
    jurisdiction: 'International Free Zone',
    keyInfo: 'Tax-efficient structure, 100% ownership, USD banking, repatriation freedom, commodities hub',
    description: 'International Entity'
  }
};

export default function BusinessSetupPage() {
  const [activeEntity, setActiveEntity] = useState<string | null>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('visible');
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => {
      observerRef.current?.observe(el);
    });

    return () => observerRef.current?.disconnect();
  }, []);

  const handleCardClick = (key: string) => {
    if (activeEntity === key) {
      setActiveEntity(null);
    } else {
      setActiveEntity(key);
    }
  };

  const data = activeEntity ? entities[activeEntity] : null;

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Business-Setup.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Setup &amp; Registration</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Business<br /><span className="gold">Setup.</span></h1>
              <p className="hero-enter hero-enter-delay-3">CZAAH guides international and diaspora investors through every step of establishing a business presence in Pakistan — from SECP registration and corporate structuring to legal documentation, bank account opening, and office establishment. Your market entry, managed from formation through operations.</p>
              <a href="/contact?interest=Business%20Setup#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Start Your Setup &rarr;</a>
            </div>
          </section>
        </div>

        {/* ENTITY TYPE CONFIGURATOR */}
        <style>{`
          .bs-configurator { max-width: 1200px; margin: 0 auto; padding: 80px 24px; }
          .bs-configurator h2 { text-align: center; margin-bottom: 12px; }
          .bs-configurator .bs-subtitle {
            text-align: center; color: var(--white-muted); font-family: 'Raleway', sans-serif;
            font-size: 1.08rem; line-height: 1.7; max-width: 640px; margin: 0 auto 48px;
          }
          .bs-grid {
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 32px;
          }
          .bs-card {
            background: var(--black-card); border: 1px solid var(--black-border); border-radius: 12px;
            padding: 28px 24px; cursor: pointer; transition: border-color 0.3s var(--ease-smooth),
            box-shadow 0.3s var(--ease-smooth), transform 0.2s var(--ease-out);
            display: flex; flex-direction: column; gap: 8px;
          }
          .bs-card:hover { border-color: var(--gold-dim); transform: translateY(-2px); }
          .bs-card.bs-active {
            border-color: var(--gold); box-shadow: 0 0 24px rgba(201, 168, 76, 0.15);
            transform: translateY(-2px);
          }
          .bs-card-icon {
            font-size: 1.6rem; color: var(--gold); line-height: 1; margin-bottom: 4px;
          }
          .bs-card-name {
            font-family: 'Cinzel', serif; font-size: 1.15rem; font-weight: 600;
            color: var(--white);
          }
          .bs-card-tagline {
            font-family: 'Raleway', sans-serif; font-size: 0.88rem; color: var(--white-muted);
            line-height: 1.5;
          }
          .bs-card-best {
            font-family: 'Raleway', sans-serif; font-size: 0.78rem; color: var(--gold-light);
            margin-top: 4px; font-weight: 500; letter-spacing: 0.02em;
          }
          .bs-prompt {
            text-align: center; color: var(--white-dim); font-family: 'Raleway', sans-serif;
            font-size: 0.95rem; padding: 40px 0;
          }
          .bs-detail {
            max-height: 0; overflow: hidden; transition: max-height 0.5s var(--ease-smooth),
            opacity 0.4s var(--ease-smooth); opacity: 0;
          }
          .bs-detail.bs-open { max-height: 800px; opacity: 1; }
          .bs-detail-inner {
            background: var(--black-elevated); border: 1px solid var(--black-border);
            border-radius: 14px; padding: 36px 32px; display: grid;
            grid-template-columns: 1fr 1fr 1fr; gap: 32px;
          }
          .bs-detail-col h4 {
            font-family: 'Raleway', sans-serif; font-size: 0.78rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.1em; color: var(--gold);
            margin-bottom: 16px;
          }
          .bs-detail-col p, .bs-detail-col li {
            font-family: 'Raleway', sans-serif; font-size: 0.9rem; color: var(--white-muted);
            line-height: 1.7;
          }
          .bs-steps { list-style: none; padding: 0; margin: 0; counter-reset: bs-step; }
          .bs-steps li {
            counter-increment: bs-step; padding-left: 28px; position: relative; margin-bottom: 10px;
          }
          .bs-steps li::before {
            content: counter(bs-step); position: absolute; left: 0; top: 1px;
            font-family: 'Raleway', sans-serif; font-size: 0.75rem; font-weight: 600;
            color: var(--gold); background: rgba(201, 168, 76, 0.1); width: 20px; height: 20px;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
          }
          .bs-doc-list { list-style: none; padding: 0; margin: 0; }
          .bs-doc-list li { padding: 6px 0 6px 18px; position: relative; margin-bottom: 2px; }
          .bs-doc-list li::before {
            content: '—'; position: absolute; left: 0; color: var(--gold-dim);
          }
          .bs-info-item { margin-bottom: 12px; }
          .bs-info-label {
            font-family: 'Raleway', sans-serif; font-size: 0.72rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.08em; color: var(--white-dim);
            margin-bottom: 2px;
          }
          .bs-info-value {
            font-family: 'Raleway', sans-serif; font-size: 0.92rem; color: var(--white);
          }
          .bs-cta {
            display: inline-block; margin-top: 20px; padding: 12px 28px;
            background: var(--gold); color: #000; font-family: 'Raleway', sans-serif;
            font-size: 0.88rem; font-weight: 600; border-radius: 6px; text-decoration: none;
            transition: opacity 0.2s var(--ease-smooth);
          }
          .bs-cta:hover { opacity: 0.88; }
          @media (max-width: 900px) {
            .bs-grid { grid-template-columns: repeat(2, 1fr); }
            .bs-detail-inner { grid-template-columns: 1fr; gap: 24px; }
          }
          @media (max-width: 560px) {
            .bs-grid { grid-template-columns: 1fr; }
            .bs-configurator { padding: 56px 16px; }
            .bs-detail-inner { padding: 24px 18px; }
          }
        `}</style>

        <section className="bs-configurator fade-in">
          <h2 className="serif">Choose your <span className="gold">entity structure.</span></h2>
          <p className="bs-subtitle">Select an entity type to see the full setup package — steps, documents, timeline, and jurisdiction.</p>

          <div className="bs-grid stagger">
            <div className={`bs-card${activeEntity === 'plc' ? ' bs-active' : ''}`} onClick={() => handleCardClick('plc')}>
              <div className="bs-card-icon">&#9670;</div>
              <div className="bs-card-name">Private Limited Company</div>
              <div className="bs-card-tagline">The standard for operating in Pakistan</div>
              <div className="bs-card-best">Best for: International investors, joint ventures, operational businesses</div>
            </div>
            <div className={`bs-card${activeEntity === 'smc' ? ' bs-active' : ''}`} onClick={() => handleCardClick('smc')}>
              <div className="bs-card-icon">&#9632;</div>
              <div className="bs-card-name">Single Member Company</div>
              <div className="bs-card-tagline">Solo ownership, full legal protection</div>
              <div className="bs-card-best">Best for: Individual investors, freelancers scaling up, sole proprietors</div>
            </div>
            <div className={`bs-card${activeEntity === 'branch' ? ' bs-active' : ''}`} onClick={() => handleCardClick('branch')}>
              <div className="bs-card-icon">&#8644;</div>
              <div className="bs-card-name">Branch / Liaison Office</div>
              <div className="bs-card-tagline">Establish presence without full incorporation</div>
              <div className="bs-card-best">Best for: MNCs testing the market, representative offices, pre-investment</div>
            </div>
            <div className={`bs-card${activeEntity === 'jv' ? ' bs-active' : ''}`} onClick={() => handleCardClick('jv')}>
              <div className="bs-card-icon">&#43;</div>
              <div className="bs-card-name">Joint Venture Structure</div>
              <div className="bs-card-tagline">Partner with local expertise</div>
              <div className="bs-card-best">Best for: Mining JVs, construction partnerships, technology partnerships</div>
            </div>
            <div className={`bs-card${activeEntity === 'spv' ? ' bs-active' : ''}`} onClick={() => handleCardClick('spv')}>
              <div className="bs-card-icon">&#9733;</div>
              <div className="bs-card-name">Special Purpose Vehicle (SPV)</div>
              <div className="bs-card-tagline">Ring-fenced, deal-specific structure</div>
              <div className="bs-card-best">Best for: Project finance, real estate investments, mining deals, infrastructure projects</div>
            </div>
            <div className={`bs-card${activeEntity === 'dmcc' ? ' bs-active' : ''}`} onClick={() => handleCardClick('dmcc')}>
              <div className="bs-card-icon">&#36;</div>
              <div className="bs-card-name">International Entity</div>
              <div className="bs-card-tagline">International invoicing &amp; USD banking</div>
              <div className="bs-card-best">Best for: Commodities trading, international clients, USD revenue, global presence</div>
            </div>
          </div>

          {!activeEntity && (
            <div className="bs-prompt">Select an entity type above to view the full setup package.</div>
          )}

          <div className={`bs-detail${activeEntity ? ' bs-open' : ''}`}>
            {data && (
              <div className="bs-detail-inner">
                <div className="bs-detail-col">
                  <h4>Setup Steps</h4>
                  <ol className="bs-steps">
                    {data.steps.map((s, i) => <li key={i}>{s}</li>)}
                  </ol>
                </div>
                <div className="bs-detail-col">
                  <h4>Required Documents</h4>
                  <ul className="bs-doc-list">
                    {data.docs.map((d, i) => <li key={i}>{d}</li>)}
                  </ul>
                </div>
                <div className="bs-detail-col">
                  <h4>Key Information</h4>
                  <div className="bs-info-item">
                    <div className="bs-info-label">Timeline</div>
                    <div className="bs-info-value">{data.timeline}</div>
                  </div>
                  <div className="bs-info-item">
                    <div className="bs-info-label">Jurisdiction</div>
                    <div className="bs-info-value">{data.jurisdiction}</div>
                  </div>
                  <div className="bs-info-item">
                    <div className="bs-info-label">Key Details</div>
                    <div className="bs-info-value">{data.keyInfo}</div>
                  </div>
                  <a href="/contact" className="bs-cta">Start Setup &rarr;</a>
                </div>
              </div>
            )}
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Complete business establishment in Pakistan &mdash; from entity formation through to operational readiness.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>SECP Registration</h3>
              <p>Full company incorporation service — name reservation, digital filing with the Securities and Exchange Commission of Pakistan, certificate of incorporation, and registered agent representation.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9881;</div>
              <h3>Corporate Structuring</h3>
              <p>Strategic entity design for your Pakistan operations — holding companies, subsidiaries, joint venture structures, and special purpose vehicles tailored to your investment objectives.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Legal Documentation</h3>
              <p>Comprehensive corporate documentation — Memorandum and Articles of Association, shareholder agreements, board resolutions, director appointments, and all statutory filings.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#36;</div>
              <h3>Bank Account Setup</h3>
              <p>Corporate banking facilitation — commercial bank account opening, foreign currency accounts, payment gateway integration, and banking infrastructure to support your operations.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8962;</div>
              <h3>Office Establishment</h3>
              <p>Physical and virtual presence setup — registered office address, virtual office services, commercial workspace procurement, and facility management across Islamabad, Lahore, and Karachi.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8644;</div>
              <h3>Ongoing Compliance</h3>
              <p>Post-incorporation regulatory management — annual SECP returns, statutory filings, corporate governance advisory, director and shareholder updates, and ongoing compliance monitoring.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">Setup capabilities <span className="gold">at a glance.</span></h2>
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">48hrs</div>
              <div className="label">Fast-track registration</div>
            </div>
            <div className="stat-item">
              <div className="number">SECP</div>
              <div className="label">Registered agent</div>
            </div>
            <div className="stat-item">
              <div className="number">6+</div>
              <div className="label">Entity types supported</div>
            </div>
            <div className="stat-item">
              <div className="number">100%</div>
              <div className="label">Compliance record</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* WHY CZAAH */}
        <section className="section fade-in">
          <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
          <p className="subtitle">Deep local expertise combined with international standards, applied to every stage of your entity formation.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>Local Expertise</h4>
                <p>Our team has extensive experience navigating Pakistan&apos;s corporate registration landscape. We understand SECP processes, timelines, and requirements — ensuring your setup is handled correctly the first time.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>Regulatory Relationships</h4>
                <p>Established working relationships with SECP, banking institutions, and government departments accelerate your registration and reduce administrative friction at every step.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>International Structuring</h4>
                <p>We help clients structure cross-border operations — enabling USD revenue flows, international invoicing, and clean corporate governance across jurisdictions.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#8644;</div>
              <div>
                <h4>End-to-End Support</h4>
                <p>From initial name search to a fully operational entity with bank accounts, office space, and compliance infrastructure — we manage the entire process so you can focus on your business.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Establish your Pakistan <span className="gold">presence.</span></h2>
          <p>Entity formation, regulatory registration, and corporate structuring &mdash; handled with institutional precision.</p>
          <a href="/contact?interest=Business%20Setup#contact-form" className="btn-gold">Begin Setup &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
