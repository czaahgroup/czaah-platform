'use client';
// @ts-nocheck

import { useEffect, useState, useRef, useCallback } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface Tender {
  dept: string;
  title: string;
  sector: string;
  value: string;
  status: string;
  deadline: string;
  bidType: string;
}

const tenders: Tender[] = [
  { dept: "NHA \u2014 National Highway Authority", title: "M-14 Motorway Extension \u2014 Phase III", sector: "Infrastructure", value: "PKR 12.5B", status: "Open", deadline: "31 Mar 2026", bidType: "Pre-qualification required" },
  { dept: "WAPDA \u2014 Water & Power Development Authority", title: "50MW Solar Farm Procurement (Cholistan)", sector: "Energy", value: "PKR 8.2B", status: "Open", deadline: "15 Apr 2026", bidType: "Pre-qualification required" },
  { dept: "NADRA \u2014 National Database & Registration Authority", title: "National Database Modernisation", sector: "IT & Digital", value: "PKR 3.1B", status: "Closing Soon", deadline: "18 Mar 2026", bidType: "Open bidding" },
  { dept: "NHA \u2014 National Highway Authority", title: "Sukkur-Hyderabad Motorway Resurfacing", sector: "Infrastructure", value: "PKR 5.7B", status: "Open", deadline: "22 May 2026", bidType: "Pre-qualification required" },
  { dept: "FBR \u2014 Federal Board of Revenue", title: "Tax Administration Digital Platform", sector: "IT & Digital", value: "PKR 1.8B", status: "Upcoming", deadline: "10 Jun 2026", bidType: "Open bidding" },
  { dept: "WAPDA \u2014 Water & Power Development Authority", title: "Transmission Line Upgrade (Northern Grid)", sector: "Energy", value: "PKR 6.4B", status: "Closing Soon", deadline: "25 Mar 2026", bidType: "Pre-qualification required" },
  { dept: "Defence \u2014 Ministry of Defence", title: "Logistics Hub Construction (Southern Command)", sector: "Defence", value: "PKR 4.2B", status: "Open", deadline: "30 Apr 2026", bidType: "Pre-qualification required" },
  { dept: "Provincial Govt \u2014 Government of Punjab", title: "E-Governance Platform (Punjab)", sector: "IT & Digital", value: "PKR 2.3B", status: "Upcoming", deadline: "15 Jul 2026", bidType: "Open bidding" }
];

function badgeClass(status: string): string {
  if (status === "Open") return "gv-badge-open";
  if (status === "Closing Soon") return "gv-badge-closing";
  return "gv-badge-upcoming";
}

export default function GovernmentPage() {
  const [activeSector, setActiveSector] = useState("All");
  const [activeStatus, setActiveStatus] = useState("All Status");

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const filteredTenders = tenders.filter(t => {
    const matchSector = activeSector === "All" || t.sector === activeSector;
    const matchStatus = activeStatus === "All Status" || t.status === activeStatus;
    return matchSector && matchStatus;
  });

  return (
    <>
      <Navbar />

      <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Government.jpg')" }}>
        <section className="v-hero">
          <div className="v-hero-text">
            <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
            <span className="gold-line hero-enter"></span>
            <div className="label hero-enter hero-enter-delay-1">Government Procurement</div>
            <h1 className="serif hero-enter hero-enter-delay-2">Government<br /><span className="gold">Contracts.</span></h1>
            <p className="hero-enter hero-enter-delay-3">Pakistan&apos;s annual public procurement exceeds PKR 2 trillion across infrastructure, energy, IT, and defence. Navigating this market requires deep institutional knowledge, regulatory expertise, and established relationships. That&apos;s what we provide.</p>
            <a href="/contact?interest=Government%20Contracts#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Explore Opportunities &rarr;</a>
          </div>
        </section>
      </div>

      <div className="divider"></div>

      {/* TENDER PIPELINE DASHBOARD */}
      <section className="gv-pipeline fade-in stagger">
        <h2 className="serif">Active tender <span className="gold">pipeline.</span></h2>
        <p className="gv-subtitle">Current and upcoming government procurement opportunities across Pakistan&apos;s priority sectors.</p>

        <div className="gv-controls">
          <div className="gv-filter-group">
            {["All", "Infrastructure", "Energy", "IT & Digital", "Defence"].map(s => (
              <button
                key={s}
                className={`gv-pill${activeSector === s ? ' gv-active' : ''}`}
                onClick={() => setActiveSector(s)}
              >
                {s === "IT & Digital" ? "IT & Digital" : s}
              </button>
            ))}
          </div>
          <div className="gv-separator"></div>
          <div className="gv-filter-group">
            {["All Status", "Open", "Closing Soon", "Upcoming"].map(s => (
              <button
                key={s}
                className={`gv-pill${activeStatus === s ? ' gv-active' : ''}`}
                onClick={() => setActiveStatus(s)}
              >
                {s}
              </button>
            ))}
          </div>
          <div className="gv-count">Showing <span>{filteredTenders.length}</span> of <span>{tenders.length}</span> opportunities</div>
        </div>

        <div className="gv-grid">
          {filteredTenders.map((t, i) => (
            <div key={i} className="gv-card" data-status={t.status}>
              <div className="gv-card-body">
                <span className={`gv-badge ${badgeClass(t.status)}`}>{t.status}</span>
                <div className="gv-dept">{t.dept}</div>
                <div className="gv-title">{t.title}</div>
                <div className="gv-meta">
                  <span className="gv-value">{t.value}</span>
                  <span className="gv-deadline">Deadline: {t.deadline}</span>
                </div>
                <div className="gv-bottom">
                  <span className="gv-sector-tag">{t.sector}</span>
                  <span className="gv-bid-type">{t.bidType}</span>
                </div>
              </div>
              <div className="gv-arrow">&rarr;</div>
            </div>
          ))}
        </div>

        <p className="gv-note">Pipeline updated regularly. <strong>Contact CZAAH</strong> for detailed tender documentation and bid support.</p>
      </section>

      <div className="divider"></div>

      {/* SERVICES */}
      <section className="section fade-in stagger">
        <h2 className="serif">Our <span className="gold">services.</span></h2>
        <p className="subtitle">Comprehensive support for international and domestic firms competing in Pakistan&apos;s public procurement market.</p>

        <div className="detail-grid">
          <div className="detail-card">
            <div className="card-icon">&#9670;</div>
            <h3>Tender Intelligence</h3>
            <p>Real-time monitoring of federal and provincial tender announcements across NHA, WAPDA, NADRA, FBR, and provincial works departments. Early identification of opportunities that match your capabilities.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9632;</div>
            <h3>Bid Preparation</h3>
            <p>End-to-end bid support &mdash; from pre-qualification documentation to technical and financial proposal preparation. We ensure your submissions meet every requirement first time.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9881;</div>
            <h3>Regulatory Compliance</h3>
            <p>Navigate PPRA (federal) and provincial procurement frameworks &mdash; SPPRA, KPPRA, PPRA Punjab. Full compliance management across registration, certification, and reporting requirements.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9733;</div>
            <h3>Government Relations</h3>
            <p>Institutional introductions and stakeholder engagement with the relevant government departments, ensuring your firm is positioned as a credible and trusted partner.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#8644;</div>
            <h3>Contract Management</h3>
            <p>Ongoing support through contract execution &mdash; milestone tracking, compliance reporting, payment facilitation, and government liaison throughout the project lifecycle.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#43;</div>
            <h3>Local Partnership</h3>
            <p>For international firms requiring an in-country partner to meet local participation requirements, CZAAH provides the institutional presence and local expertise you need.</p>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* PRIORITY SECTORS */}
      <section className="section fade-in stagger">
        <h2 className="serif">Priority <span className="gold">sectors.</span></h2>
        <p className="subtitle">Four high-value government sectors where deep institutional knowledge and established relationships make the difference.</p>

        <div className="detail-grid" style={{ gridTemplateColumns: 'repeat(2, 1fr)' }}>
          <div className="detail-card">
            <div className="card-icon">&#9776;</div>
            <h3>NHA &mdash; Infrastructure</h3>
            <p>Pakistan&apos;s largest infrastructure spending pipeline &mdash; roads, bridges, highways, and motorways across the country. CPEC has accelerated the infrastructure programme significantly.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9889;</div>
            <h3>WAPDA &mdash; Energy</h3>
            <p>Solar, wind, transmission, mini-hydro, and energy storage. Pakistan&apos;s energy transition is creating massive procurement demand for international technology and engineering firms.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9881;</div>
            <h3>Government IT</h3>
            <p>NADRA, FBR, and provincial e-governance digitisation programmes. Modernisation mandates are creating sustained demand for enterprise technology vendors and systems integrators.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9733;</div>
            <h3>Defence &amp; Logistics</h3>
            <p>Facility management, logistics infrastructure, IT systems, and operational support for defence establishments. A significant and recurring procurement category.</p>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* HOW WE WORK */}
      <section className="section fade-in stagger">
        <h2 className="serif">How we <span className="gold">work.</span></h2>
        <p className="subtitle">A structured process from opportunity identification through to contract award and execution support.</p>

        <div className="process-list">
          <div className="process-item">
            <div>
              <h4>Market Assessment</h4>
              <p>We analyse the government procurement pipeline, identify tenders aligned with your capabilities, and provide a clear picture of the competitive landscape and win probability.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Pre-Qualification &amp; Registration</h4>
              <p>Ensure your firm is registered with the relevant procuring agencies, meets all eligibility criteria, and has the required certifications and documentation in place.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Bid Strategy &amp; Submission</h4>
              <p>Develop your technical and financial proposals with deep knowledge of evaluation criteria, pricing benchmarks, and procuring agency expectations. We manage the full submission process.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Award &amp; Mobilisation</h4>
              <p>Post-award support including contract negotiation, performance bond arrangements, team mobilisation, and initial government stakeholder coordination.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Ongoing Contract Support</h4>
              <p>Continuous government liaison, compliance monitoring, progress reporting, and issue resolution throughout the contract lifecycle &mdash; ensuring smooth execution and timely payments.</p>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* STATS */}
      <section className="section section-center fade-in-scale stagger">
        <div className="stats-row">
          <div className="stat-item">
            <div className="number">PKR 2T+</div>
            <div className="label">Annual government procurement spend</div>
          </div>
          <div className="stat-item">
            <div className="number">PPRA</div>
            <div className="label">Federal procurement framework</div>
          </div>
          <div className="stat-item">
            <div className="number">4</div>
            <div className="label">Priority government sectors</div>
          </div>
          <div className="stat-item">
            <div className="number">CPEC</div>
            <div className="label">Expanding the infrastructure pipeline</div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* REGULATORY */}
      <section className="section fade-in-left">
        <div className="split">
          <div>
            <h3 className="serif">Regulatory <span className="gold">landscape.</span></h3>
            <p>Pakistan&apos;s public procurement is governed by PPRA at the federal level, with provincial equivalents &mdash; SPPRA (Sindh), KPPRA (KPK), and PPRA Punjab &mdash; governing regional tenders.</p>
            <p>Each framework has distinct registration requirements, evaluation methodologies, and compliance standards. CZAAH maintains expertise across all procurement regulatory bodies, ensuring your bids are compliant and competitive regardless of jurisdiction.</p>
          </div>
          <div>
            <h3 className="serif">Key <span className="gold">departments.</span></h3>
            <div style={{ marginTop: '8px' }}>
              <span className="tag">NHA</span>
              <span className="tag">WAPDA</span>
              <span className="tag">NADRA</span>
              <span className="tag">FBR</span>
              <span className="tag">PITB</span>
              <span className="tag">Planning Commission</span>
              <span className="tag">Provincial Works Depts</span>
              <span className="tag">Defence Logistics</span>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      <section className="cta-banner fade-in">
        <h2 className="serif">Compete in Pakistan&apos;s <span className="gold">public sector.</span></h2>
        <p>Tender identification, bid preparation, regulatory compliance, and government relationships &mdash; the infrastructure to win.</p>
        <a href="/contact?interest=Government%20Contracts#contact-form" className="btn-gold">Discuss a Tender &rarr;</a>
      </section>

      <Footer />
    </>
  );
}