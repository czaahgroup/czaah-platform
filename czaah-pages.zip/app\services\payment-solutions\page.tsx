'use client';
// @ts-nocheck

import { useEffect } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

export default function PaymentSolutionsPage() {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <Navbar />

      <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Business-Setup.jpg')" }}>
        <section className="v-hero">
          <div className="v-hero-text">
            <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
            <span className="gold-line hero-enter"></span>
            <div className="label hero-enter hero-enter-delay-1">Financial Infrastructure</div>
            <h1 className="serif hero-enter hero-enter-delay-2">Payment<br /><span className="gold">Solutions.</span></h1>
            <p className="hero-enter hero-enter-delay-3">CZAAH has partnered with Swiss Payments to deliver seamless cross-border payment infrastructure for businesses operating across Pakistan, the Gulf, and international markets. Multi-currency accounts, corporate cards, and real-time settlement &mdash; built on Swiss regulatory standards.</p>
            <a href="/contact?interest=Payment%20Solutions#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Get Started &rarr;</a>
          </div>
        </section>
      </div>

      {/* PARTNERSHIP HIGHLIGHT */}
      <section className="ps-partnership fade-in">
        <div className="ps-partnership-inner">
          <div className="ps-partner-badge">SP</div>
          <div className="ps-partner-content">
            <h3>Powered by <span className="gold">Swiss Payments</span></h3>
            <div className="ps-partner-sub">Swiss-regulated financial infrastructure for global commerce</div>
            <p>Our partnership with Swiss Payments brings institutional-grade payment infrastructure to CZAAH clients. Swiss regulatory oversight ensures full AML/KYC compliance, transparent pricing, and the security standards expected by international investors and corporate treasuries.</p>
            <p>Whether you are settling trade invoices across borders, managing multi-currency payroll, or issuing corporate cards for distributed teams &mdash; the platform is built for speed, transparency, and regulatory confidence.</p>
            <div className="ps-partner-tags">
              <span className="ps-tag">Swiss Regulated</span>
              <span className="ps-tag">AML/KYC Compliant</span>
              <span className="ps-tag">Transparent Pricing</span>
              <span className="ps-tag">Global Reach</span>
            </div>
            <div style={{ marginTop: '20px' }}>
              <a href="https://swisspayments.ch" target="_blank" rel="noopener" className="ps-partner-link">Visit swisspayments.ch &rarr;</a>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* SERVICES */}
      <section className="section fade-in">
        <h2 className="serif">Our <span className="gold">services.</span></h2>
        <p className="subtitle">End-to-end payment infrastructure for cross-border commerce &mdash; from account opening to global settlement.</p>

        <div className="detail-grid stagger">
          <div className="detail-card">
            <div className="card-icon">&#8644;</div>
            <h3>Cross-Border Payments</h3>
            <p>Send and receive payments globally through local payment rails and international wire networks. Competitive rates, fast processing, and full transparency on fees and delivery timelines for every transaction.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#36;</div>
            <h3>Multi-Currency Accounts</h3>
            <p>Hold, manage, and convert balances across 30+ currencies in a single platform. Reduce FX exposure, eliminate unnecessary conversions, and maintain operational accounts in the currencies your business needs.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9670;</div>
            <h3>Corporate Card Programme</h3>
            <p>Issue virtual and physical cards for your team with granular spend controls, real-time notifications, and seamless integration into your expense management workflow. Scale card issuance as your operations grow.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9881;</div>
            <h3>FX &amp; Treasury Management</h3>
            <p>Access competitive foreign exchange rates with real-time conversion capabilities. Manage treasury positions across currencies, set rate alerts, and execute conversions at optimal pricing for your business needs.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9733;</div>
            <h3>Transaction Monitoring</h3>
            <p>Real-time visibility into every payment &mdash; status tracking, compliance reporting, and audit-ready transaction histories. Full transparency for internal controls, regulatory requirements, and stakeholder reporting.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#8962;</div>
            <h3>Settlement Infrastructure</h3>
            <p>Fast, reliable settlement for trade payments, contract disbursements, and invoice processing. Purpose-built for the speed and documentation requirements of cross-border commerce and investment flows.</p>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* STATS */}
      <section className="section section-center fade-in-scale">
        <h2 className="serif">Payment capabilities <span className="gold">at a glance.</span></h2>
        <div className="stats-row stagger">
          <div className="stat-item">
            <div className="number">30+</div>
            <div className="label">Currencies supported</div>
          </div>
          <div className="stat-item">
            <div className="number">Real-time</div>
            <div className="label">Settlement tracking</div>
          </div>
          <div className="stat-item">
            <div className="number">Swiss</div>
            <div className="label">Regulated compliance</div>
          </div>
          <div className="stat-item">
            <div className="number">Minutes</div>
            <div className="label">To open an account</div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* WHY CZAAH */}
      <section className="section fade-in">
        <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
        <p className="subtitle">Swiss financial standards combined with regional expertise, applied to every layer of your payment infrastructure.</p>

        <div className="relationships stagger">
          <div className="rel-card">
            <div className="rel-icon">&#9670;</div>
            <div>
              <h4>Swiss Financial Standards</h4>
              <p>Every transaction is processed under Swiss regulatory supervision, ensuring full AML/KYC compliance, transparent fee structures, and the institutional-grade security that international investors and corporate clients require.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9632;</div>
            <div>
              <h4>International Integration</h4>
              <p>We structure payment flows across borders that align with your cross-border requirements &mdash; enabling efficient settlement across jurisdictions with full regulatory compliance.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9733;</div>
            <div>
              <h4>Investor-Grade Reporting</h4>
              <p>Complete audit trails, compliance documentation, and transaction reporting built for institutional standards. Every payment is tracked, documented, and available for review by your compliance and finance teams.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#8644;</div>
            <div>
              <h4>Dedicated Account Management</h4>
              <p>A named account manager for your payment operations &mdash; from initial setup and onboarding through to ongoing support, issue resolution, and strategic advisory on optimising your payment infrastructure.</p>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      <section className="cta-banner fade-in">
        <h2 className="serif">Streamline your cross-border <span className="gold">payments.</span></h2>
        <p>Multi-currency accounts, corporate cards, and global settlement &mdash; powered by Swiss financial infrastructure.</p>
        <a href="/contact?interest=Payment%20Solutions#contact-form" className="btn-gold">Schedule a Consultation &rarr;</a>
      </section>

      <Footer />
    </>
  );
}