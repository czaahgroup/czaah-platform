'use client';
// @ts-nocheck

import { useEffect, useState } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface Programme {
  country: string;
  type: string;
  desc: string;
  benefits: string[];
  routes: string[];
  investment: string;
  timeline: string;
  programme: string;
  family: string;
  presence: string;
  citizenship: string;
}

const programmes: Programme[] = [
  {
    country: 'Latvia',
    type: 'Temporary Residence Permit \u2014 Investment Route',
    desc: "Latvia's residence permit by investment is one of Europe's most efficient pathways to EU residency. Through a qualifying real estate purchase, subordinated capital deposit, or company investment, applicants receive a five-year temporary residence permit (TRP) with full Schengen travel rights. Latvia is an EU and NATO member, offers a high quality of life, competitive living costs, and a clear pathway from temporary residency through permanent residency to full Latvian \u2014 and therefore EU \u2014 citizenship. The process is straightforward: invest, submit biometrics and documentation to the Office of Citizenship and Migration Affairs (OCMA), and receive your residence permit within 30\u201390 days.",
    benefits: ['Full EU residency & Schengen access', 'Five-year TRP, renewable indefinitely', 'Path to permanent residency (after 5 years)', 'Path to EU citizenship (after 10 years)', 'Family inclusion \u2014 spouse, children, parents', 'No language requirement for TRP', 'EU healthcare & education access', 'NATO member state security', 'Low cost of living vs Western Europe'],
    routes: ['Real Estate in Riga (\u20AC250,000+)', 'Real Estate outside Riga (\u20AC50,000+ in designated areas)', 'Subordinated Capital in Latvian bank (\u20AC280,000+)', 'Company Investment (\u20AC50,000+ equity + tax obligations)', 'Government Bonds (\u20AC250,000+)'],
    investment: '\u20AC50K \u2013 \u20AC280K',
    timeline: '30 \u2013 90 days',
    programme: 'Temporary Residency (5-year TRP)',
    family: 'Spouse, children, dependent parents',
    presence: 'Visit once per calendar year',
    citizenship: 'Permanent residency after 5 years, citizenship after 10 years'
  },
  {
    country: 'Portugal',
    type: 'Golden Visa \u2014 Residency by Investment',
    desc: "Portugal's Golden Visa is one of Europe's most established residency by investment programmes. It offers a clear path to EU residency and Portuguese citizenship with minimal physical presence requirements. Ideal for investors seeking Schengen area access and a gateway to the European Union.",
    benefits: ['Schengen area access', 'Path to EU citizenship (5 years)', 'Minimal residency requirement (7 days/year)', 'Family inclusion', 'Access to Portuguese healthcare & education'],
    routes: ['Fund Investment (\u20AC500K+)', 'Scientific Research (\u20AC500K+)', 'Cultural Heritage (\u20AC250K+)', 'Business Creation (10+ jobs)'],
    investment: '\u20AC250K \u2013 \u20AC500K',
    timeline: '6 \u2013 12 months',
    programme: 'Residency',
    family: 'Spouse, children, dependants',
    presence: '7 days/year average',
    citizenship: 'After 5 years'
  },
  {
    country: 'Greece',
    type: 'Golden Visa \u2014 Residency by Investment',
    desc: "Greece offers one of Europe's most accessible golden visa programmes through real estate investment. With a relatively low entry threshold and no minimum stay requirement, it provides an efficient route to EU residency for investors and their families.",
    benefits: ['EU residency permit', 'No minimum stay requirement', 'Schengen travel access', 'Family inclusion', 'Real estate capital appreciation'],
    routes: ['Real Estate (\u20AC250K\u2013\u20AC800K by region)', 'Capital Investment (\u20AC400K+)', 'Government Bonds (\u20AC400K+)'],
    investment: '\u20AC250K \u2013 \u20AC800K',
    timeline: '3 \u2013 6 months',
    programme: 'Residency',
    family: 'Spouse, children, parents',
    presence: 'No minimum stay',
    citizenship: 'After 7 years (with residency)'
  },
  {
    country: 'Spain',
    type: 'Golden Visa \u2014 Residency by Investment',
    desc: "Spain's Golden Visa programme grants residency to non-EU investors who make a qualifying investment in Spanish real estate, financial assets, or business ventures. Spain offers a high quality of life, excellent infrastructure, and access to the EU's fourth-largest economy.",
    benefits: ['EU residency & Schengen access', 'Work authorisation included', 'Excellent healthcare & education', 'Family inclusion', 'Path to permanent residency'],
    routes: ['Real Estate (\u20AC500K+)', 'Financial Assets (\u20AC1M+)', 'Bank Deposit (\u20AC1M+)', 'Business Project (significant interest)'],
    investment: '\u20AC500K \u2013 \u20AC1M+',
    timeline: '2 \u2013 4 months',
    programme: 'Residency',
    family: 'Spouse, children, dependants',
    presence: 'Visit once per year to renew',
    citizenship: 'After 10 years'
  },
  {
    country: 'Malta',
    type: 'Citizenship & Residency by Investment',
    desc: "Malta offers both residency and a direct citizenship by naturalisation programme \u2014 one of the few in Europe. Maltese citizenship grants an EU passport with visa-free access to 180+ countries.",
    benefits: ['EU citizenship & passport', 'Visa-free access to 180+ countries', 'Favourable tax regime', 'English-speaking jurisdiction'],
    routes: ['Citizenship: Contribution (\u20AC600K\u2013\u20AC750K) + Property + Donation', 'Residency: Property (\u20AC300K+) + Contribution (\u20AC28K+)'],
    investment: '\u20AC150K \u2013 \u20AC1M+',
    timeline: '12 \u2013 36 months (citizenship)',
    programme: 'Citizenship & Residency',
    family: 'Spouse, children, dependants, parents',
    presence: 'Residency: some presence',
    citizenship: 'Direct (12\u201336 months)'
  },
  {
    country: 'Turkey',
    type: 'Citizenship by Investment',
    desc: "A direct route to citizenship through real estate or capital investment. Turkey straddles Europe and Asia, offering strategic positioning and visa-free access to 110+ countries.",
    benefits: ['Turkish passport & citizenship', 'Visa-free to 110+ countries', 'No language or residency test', 'Growing real estate market'],
    routes: ['Real Estate ($400K+)', 'Bank Deposit ($500K+)', 'Capital Investment ($500K+)'],
    investment: '$400K \u2013 $500K',
    timeline: '3 \u2013 6 months',
    programme: 'Citizenship',
    family: 'Spouse, children under 18',
    presence: 'No minimum requirement',
    citizenship: 'Direct \u2014 3 to 6 months'
  },
  {
    country: 'UAE',
    type: 'Golden Visa \u2014 Long-Term Residency',
    desc: "The UAE Golden Visa grants 10-year renewable residency to investors and entrepreneurs. Zero income tax, world-class infrastructure, and a strategic hub between continents.",
    benefits: ['10-year renewable residency', 'Zero income tax', '100% business ownership', 'Family sponsorship'],
    routes: ['Real Estate (AED 2M+ / $545K+)', 'Business Investment', 'Public Investment (AED 2M+)'],
    investment: 'AED 2M+ ($545K+)',
    timeline: '2 \u2013 4 weeks',
    programme: 'Long-term Residency',
    family: 'Spouse, children, domestic staff',
    presence: 'Visit every 6 months',
    citizenship: 'By nomination only'
  },
  {
    country: 'Caribbean',
    type: 'Citizenship by Investment \u2014 Multiple Nations',
    desc: "Fast-track second passport programmes across St Kitts & Nevis, Dominica, Grenada, Antigua & Barbuda, and St Lucia. No residency requirement, competitive pricing, and Schengen visa-free travel.",
    benefits: ['Second passport in 3\u20136 months', 'No residency required', 'Visa-free to 140+ countries', 'Tax-neutral jurisdictions'],
    routes: ['National Development Fund ($100K\u2013$200K)', 'Real Estate ($200K\u2013$400K)'],
    investment: '$100K \u2013 $400K',
    timeline: '3 \u2013 6 months',
    programme: 'Citizenship',
    family: 'Spouse, children, siblings, parents',
    presence: 'No requirement',
    citizenship: 'Direct \u2014 no residency phase'
  }
];

export default function InvestmentMigrationPage() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fading, setFading] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showMeetingModal, setShowMeetingModal] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState('');
  const [meetingForm, setMeetingForm] = useState({ name: '', email: '', phone: '', date: '', time: '', notes: '' });
  const [meetingSubmitting, setMeetingSubmitting] = useState(false);
  const [meetingSuccess, setMeetingSuccess] = useState(false);
  const [meetingError, setMeetingError] = useState('');

  // Check auth state
  useEffect(() => {
    async function checkAuth() {
      try {
        const { createClient } = await import('@/lib/supabase/client');
        const supabase = createClient();
        const { data: { session } } = await supabase.auth.getSession();
        setIsLoggedIn(!!session?.user);
        if (session?.user) {
          const { data: profile } = await supabase.from('profiles').select('full_name, email, phone').eq('id', session.user.id).single();
          if (profile) {
            setMeetingForm(f => ({ ...f, name: profile.full_name || '', email: profile.email || '', phone: profile.phone || '' }));
          }
        }
      } catch { /* not logged in */ }
    }
    checkAuth();
  }, []);

  async function handleMeetingSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!meetingForm.name || !meetingForm.email || !meetingForm.date || !meetingForm.time) {
      setMeetingError('Please fill in all required fields');
      return;
    }
    setMeetingSubmitting(true);
    setMeetingError('');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: meetingForm.name,
          email: meetingForm.email,
          phone: meetingForm.phone || '',
          interest: `Investment Migration - ${selectedCountry}`,
          message: `Meeting Request for Investment Migration (${selectedCountry})\n\nPreferred Date: ${meetingForm.date}\nPreferred Time: ${meetingForm.time}\n\n${meetingForm.notes ? 'Additional Notes: ' + meetingForm.notes : ''}`,
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to submit');
      }
      setMeetingSuccess(true);
    } catch (err) {
      setMeetingError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setMeetingSubmitting(false);
    }
  }

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const selectProgramme = (idx: number) => {
    if (idx === currentIndex) return;
    setFading(true);
    setTimeout(() => {
      setCurrentIndex(idx);
      setFading(false);
    }, 300);
  };

  const p = programmes[currentIndex];

  return (
    <>
      <Navbar />

      <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Investment-Migration.jpg')" }}>
        <section className="v-hero">
          <div className="v-hero-text">
            <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
            <span className="gold-line hero-enter"></span>
            <div className="label hero-enter hero-enter-delay-1">Residency &amp; Citizenship</div>
            <h1 className="serif hero-enter hero-enter-delay-2">Investment<br /><span className="gold">Migration.</span></h1>
            <p className="hero-enter hero-enter-delay-3">Secure European residency through qualifying investment &mdash; with Latvia as our primary pathway. Full advisory from programme selection and application through to approval, relocation, and settlement across the EU and beyond.</p>
            <a href="/contact?interest=Investment%20Migration#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Explore Programmes &rarr;</a>
          </div>
        </section>
      </div>

      <div className="divider"></div>

      {/* PROGRAMME SELECTOR */}
      <section className="im-section fade-in">
        <h2 className="serif">Programme <span className="gold">directory.</span></h2>
        <p className="im-subtitle">European residency and citizenship programmes assessed for credibility, processing time, and strategic value &mdash; with Latvia as our flagship route into the EU.</p>

        <div className="im-pills">
          {programmes.map((prog, i) => (
            <button
              key={prog.country}
              className={`im-pill${i === currentIndex ? ' im-active' : ''}`}
              onClick={() => selectProgramme(i)}
            >
              {prog.country}
            </button>
          ))}
        </div>

        <div className={`im-card${fading ? ' im-fading' : ''}`}>
          <div className="im-left">
            <div className="im-country">{p.country}</div>
            <div className="im-type">{p.type}</div>
            <p className="im-desc">{p.desc}</p>
            <div className="im-tag-group">
              <div className="im-tag-label">Key Benefits</div>
              <div className="im-tags">
                {p.benefits.map(b => (
                  <span key={b} className="im-tag">{b}</span>
                ))}
              </div>
            </div>
            <div className="im-tag-group">
              <div className="im-tag-label">Investment Routes</div>
              <div className="im-tags">
                {p.routes.map(r => (
                  <span key={r} className="im-tag">{r}</span>
                ))}
              </div>
            </div>
          </div>
          <div className="im-right">
            <div className="im-detail-row">
              <div className="im-detail-item">
                <div className="im-detail-label">Minimum Investment</div>
                <div className="im-detail-value">{p.investment}</div>
              </div>
              <div className="im-detail-item">
                <div className="im-detail-label">Processing Time</div>
                <div className="im-detail-value">{p.timeline}</div>
              </div>
            </div>
            <div className="im-detail-row">
              <div className="im-detail-item">
                <div className="im-detail-label">Programme Type</div>
                <div className="im-detail-value">{p.programme}</div>
              </div>
              <div className="im-detail-item">
                <div className="im-detail-label">Family Inclusion</div>
                <div className="im-detail-value">{p.family}</div>
              </div>
            </div>
            <div className="im-detail-row">
              <div className="im-detail-item">
                <div className="im-detail-label">Physical Presence</div>
                <div className="im-detail-value">{p.presence}</div>
              </div>
              <div className="im-detail-item">
                <div className="im-detail-label">Path to Citizenship</div>
                <div className="im-detail-value">{p.citizenship}</div>
              </div>
            </div>

            {/* Application CTA */}
            <div style={{ marginTop: '24px', paddingTop: '20px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
              {isLoggedIn ? (
                <button
                  onClick={() => { setSelectedCountry(p.country); setShowMeetingModal(true); setMeetingSuccess(false); setMeetingError(''); }}
                  style={{
                    width: '100%',
                    background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                    color: '#000',
                    fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600,
                    fontSize: '14px',
                    letterSpacing: '0.05em',
                    padding: '14px 24px',
                    borderRadius: '4px',
                    border: 'none',
                    cursor: 'pointer',
                    transition: 'opacity 0.3s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.opacity = '0.9'}
                  onMouseLeave={e => e.currentTarget.style.opacity = '1'}
                >
                  Begin Your Application &rarr;
                </button>
              ) : (
                <a
                  href="/register"
                  style={{
                    display: 'block',
                    width: '100%',
                    textAlign: 'center',
                    background: 'transparent',
                    color: '#C9A84C',
                    fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600,
                    fontSize: '14px',
                    letterSpacing: '0.05em',
                    padding: '14px 24px',
                    borderRadius: '4px',
                    border: '1px solid rgba(201,168,76,0.3)',
                    textDecoration: 'none',
                    transition: 'all 0.3s',
                    boxSizing: 'border-box',
                  }}
                >
                  Become a Member to Begin Your Application
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* SERVICES */}
      <section className="section fade-in">
        <h2 className="serif">Our <span className="gold">services.</span></h2>
        <p className="subtitle">Comprehensive investment migration advisory &mdash; from initial assessment through to approval, relocation, and settlement.</p>

        <div className="detail-grid stagger">
          <div className="detail-card">
            <div className="card-icon">&#9670;</div>
            <h3>Programme Selection</h3>
            <p>Personalised assessment of your objectives, risk appetite, budget, and family requirements to identify the optimal residency or citizenship programme across our global network.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9881;</div>
            <h3>Application Management</h3>
            <p>End-to-end management of the application process &mdash; document preparation, form completion, government liaison, and status tracking from submission through to approval.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9733;</div>
            <h3>Due Diligence Support</h3>
            <p>Pre-application due diligence review to identify and resolve potential issues before submission. We ensure your profile meets programme requirements and passes government screening.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#36;</div>
            <h3>Investment Structuring</h3>
            <p>Guidance on qualifying investments &mdash; real estate selection, fund allocation, donation routing, and capital deployment &mdash; structured to meet programme thresholds while maximising returns.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9632;</div>
            <h3>Legal &amp; Tax Advisory</h3>
            <p>Coordination with immigration lawyers, tax advisors, and compliance specialists in both origin and destination countries to ensure clean, compliant migration with optimal tax positioning.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#43;</div>
            <h3>Relocation &amp; Settlement</h3>
            <p>Post-approval relocation support including property sourcing, school placement, bank account opening, healthcare registration, and integration assistance for you and your family.</p>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* STATS */}
      <section className="section section-center fade-in-scale">
        <h2 className="serif">Migration capability <span className="gold">at a glance.</span></h2>
        <div className="stats-row stagger">
          <div className="stat-item">
            <div className="number">20+</div>
            <div className="label">Programmes covered</div>
          </div>
          <div className="stat-item">
            <div className="number">Europe</div>
            <div className="label">Primary focus</div>
          </div>
          <div className="stat-item">
            <div className="number">End-to-End</div>
            <div className="label">Advisory scope</div>
          </div>
          <div className="stat-item">
            <div className="number">Family</div>
            <div className="label">Inclusive applications</div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* WHY CZAAH */}
      <section className="section fade-in">
        <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
        <p className="subtitle">Investment migration advisory built on real cross-border operational experience &mdash; not a referral desk.</p>

        <div className="relationships stagger">
          <div className="rel-card">
            <div className="rel-icon">&#9670;</div>
            <div>
              <h4>Multi-Jurisdictional Expertise</h4>
              <p>We operate across Pakistan, the UAE, and Europe with established legal and financial networks in every major destination country. Our advice reflects real operational knowledge, not brochure summaries.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9632;</div>
            <div>
              <h4>Programme-Specific Relationships</h4>
              <p>Direct relationships with immigration authorities, approved agents, and government-endorsed developers in Portugal, Greece, Malta, the Caribbean, Turkey, and the UAE.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9733;</div>
            <div>
              <h4>Integrated Wealth Planning</h4>
              <p>Investment migration is rarely standalone. We coordinate with your existing investment strategy, tax planning, and business structure to ensure migration complements your broader financial picture.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#8644;</div>
            <div>
              <h4>Confidential &amp; Discreet</h4>
              <p>We understand the sensitivity of migration decisions for high-net-worth families. Every engagement is handled with institutional-grade confidentiality and discretion from initial enquiry through to completion.</p>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      <section className="cta-banner fade-in">
        <h2 className="serif">Your next chapter starts with <span className="gold">the right programme.</span></h2>
        <p>Residency, citizenship, and global mobility &mdash; structured around your investment goals, family needs, and long-term vision.</p>
        <a href="/contact?interest=Investment%20Migration#contact-form" className="btn-gold">Book a Confidential Consultation &rarr;</a>
      </section>

      <Footer />

      {/* Meeting Scheduling Modal */}
      {showMeetingModal && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 1000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'rgba(0,0,0,0.8)',
            backdropFilter: 'blur(8px)',
            padding: '20px',
          }}
          onClick={(e) => { if (e.target === e.currentTarget) setShowMeetingModal(false); }}
        >
          <div style={{
            background: '#080808',
            border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: '12px',
            width: '100%',
            maxWidth: '480px',
            maxHeight: '90vh',
            overflowY: 'auto',
            padding: '36px',
            position: 'relative',
          }}>
            {/* Close button */}
            <button
              onClick={() => setShowMeetingModal(false)}
              style={{
                position: 'absolute', top: '16px', right: '16px',
                background: 'none', border: 'none', cursor: 'pointer',
                color: 'rgba(255,255,255,0.3)', fontSize: '20px', lineHeight: 1,
              }}
            >&times;</button>

            {meetingSuccess ? (
              <div style={{ textAlign: 'center', padding: '20px 0' }}>
                <div style={{
                  width: '64px', height: '64px', borderRadius: '50%',
                  background: 'rgba(34,197,94,0.15)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  margin: '0 auto 20px', fontSize: '28px', color: '#22c55e',
                }}>&#10003;</div>
                <h3 style={{
                  fontFamily: "'Cinzel', serif", fontSize: '20px',
                  color: '#fff', marginBottom: '12px',
                }}>Meeting Request Submitted</h3>
                <p style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '14px',
                  color: 'rgba(255,255,255,0.45)', lineHeight: 1.7, marginBottom: '8px',
                }}>
                  Your meeting request for <strong style={{ color: '#C9A84C' }}>{selectedCountry}</strong> investment migration has been submitted.
                </p>
                <p style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '13px',
                  color: 'rgba(255,255,255,0.3)', lineHeight: 1.6,
                }}>
                  Our investment migration team will confirm your appointment shortly via email.
                </p>
                <button
                  onClick={() => setShowMeetingModal(false)}
                  style={{
                    marginTop: '24px',
                    background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                    color: '#000', fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600, fontSize: '13px', padding: '10px 28px',
                    borderRadius: '4px', border: 'none', cursor: 'pointer',
                  }}
                >Close</button>
              </div>
            ) : (
              <>
                <h3 style={{
                  fontFamily: "'Cinzel', serif", fontSize: '20px',
                  color: '#fff', marginBottom: '6px',
                }}>Schedule a Consultation</h3>
                <p style={{
                  fontFamily: "'Raleway', sans-serif", fontSize: '13px',
                  color: 'rgba(255,255,255,0.4)', marginBottom: '24px', lineHeight: 1.5,
                }}>
                  Book a meeting to discuss your <strong style={{ color: '#C9A84C' }}>{selectedCountry}</strong> investment migration application.
                </p>

                {meetingError && (
                  <div style={{
                    background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)',
                    borderRadius: '6px', padding: '10px 14px', marginBottom: '16px',
                  }}>
                    <p style={{ fontFamily: "'Raleway', sans-serif", fontSize: '13px', color: '#ef4444', margin: 0 }}>{meetingError}</p>
                  </div>
                )}

                <form onSubmit={handleMeetingSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div>
                    <label style={{ display: 'block', fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', marginBottom: '6px' }}>Full Name *</label>
                    <input
                      type="text" value={meetingForm.name} onChange={e => setMeetingForm(f => ({ ...f, name: e.target.value }))} required
                      style={{ width: '100%', background: '#000', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '6px', padding: '10px 14px', color: '#fff', fontFamily: "'Raleway', sans-serif", fontSize: '14px', outline: 'none', boxSizing: 'border-box' }}
                      onFocus={e => e.currentTarget.style.borderColor = '#C9A84C'} onBlur={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', marginBottom: '6px' }}>Email *</label>
                    <input
                      type="email" value={meetingForm.email} onChange={e => setMeetingForm(f => ({ ...f, email: e.target.value }))} required
                      style={{ width: '100%', background: '#000', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '6px', padding: '10px 14px', color: '#fff', fontFamily: "'Raleway', sans-serif", fontSize: '14px', outline: 'none', boxSizing: 'border-box' }}
                      onFocus={e => e.currentTarget.style.borderColor = '#C9A84C'} onBlur={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', marginBottom: '6px' }}>Phone</label>
                    <input
                      type="tel" value={meetingForm.phone} onChange={e => setMeetingForm(f => ({ ...f, phone: e.target.value }))}
                      style={{ width: '100%', background: '#000', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '6px', padding: '10px 14px', color: '#fff', fontFamily: "'Raleway', sans-serif", fontSize: '14px', outline: 'none', boxSizing: 'border-box' }}
                      onFocus={e => e.currentTarget.style.borderColor = '#C9A84C'} onBlur={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}
                      placeholder="+44 000 000 0000"
                    />
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                    <div>
                      <label style={{ display: 'block', fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', marginBottom: '6px' }}>Preferred Date *</label>
                      <input
                        type="date" value={meetingForm.date} onChange={e => setMeetingForm(f => ({ ...f, date: e.target.value }))} required
                        min={new Date().toISOString().split('T')[0]}
                        style={{ width: '100%', background: '#000', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '6px', padding: '10px 14px', color: '#fff', fontFamily: "'Raleway', sans-serif", fontSize: '14px', outline: 'none', boxSizing: 'border-box', colorScheme: 'dark' }}
                        onFocus={e => e.currentTarget.style.borderColor = '#C9A84C'} onBlur={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', marginBottom: '6px' }}>Preferred Time *</label>
                      <select
                        value={meetingForm.time} onChange={e => setMeetingForm(f => ({ ...f, time: e.target.value }))} required
                        style={{ width: '100%', background: '#000', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '6px', padding: '10px 14px', color: '#fff', fontFamily: "'Raleway', sans-serif", fontSize: '14px', outline: 'none', boxSizing: 'border-box' }}
                      >
                        <option value="">Select time</option>
                        <option value="09:00">09:00 AM</option>
                        <option value="10:00">10:00 AM</option>
                        <option value="11:00">11:00 AM</option>
                        <option value="12:00">12:00 PM</option>
                        <option value="13:00">01:00 PM</option>
                        <option value="14:00">02:00 PM</option>
                        <option value="15:00">03:00 PM</option>
                        <option value="16:00">04:00 PM</option>
                        <option value="17:00">05:00 PM</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontFamily: "'Raleway', sans-serif", fontSize: '11px', letterSpacing: '0.05em', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', marginBottom: '6px' }}>Additional Notes</label>
                    <textarea
                      value={meetingForm.notes} onChange={e => setMeetingForm(f => ({ ...f, notes: e.target.value }))}
                      rows={3} placeholder="Any specific questions or requirements..."
                      style={{ width: '100%', background: '#000', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '6px', padding: '10px 14px', color: '#fff', fontFamily: "'Raleway', sans-serif", fontSize: '14px', outline: 'none', boxSizing: 'border-box', resize: 'none' }}
                      onFocus={e => e.currentTarget.style.borderColor = '#C9A84C'} onBlur={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={meetingSubmitting}
                    style={{
                      background: meetingSubmitting ? 'rgba(201,168,76,0.5)' : 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                      color: '#000', fontFamily: "'Raleway', sans-serif",
                      fontWeight: 600, fontSize: '14px', letterSpacing: '0.05em',
                      padding: '14px', borderRadius: '6px', border: 'none',
                      cursor: meetingSubmitting ? 'not-allowed' : 'pointer',
                      width: '100%', transition: 'opacity 0.3s',
                    }}
                  >
                    {meetingSubmitting ? 'Submitting...' : 'Schedule Meeting'}
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}