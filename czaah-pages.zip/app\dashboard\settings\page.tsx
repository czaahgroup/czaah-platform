'use client'

import { useEffect, useState, useRef } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

interface Profile {
  id: string
  full_name: string
  email: string
  phone: string | null
  company_name: string | null
  country: string | null
  company_website: string | null
  company_description: string | null
  role: string
  avatar_url: string | null
}

interface NotificationPreferences {
  id: string
  email_new_message: boolean
  email_enquiry_status: boolean
  email_new_investment: boolean
  in_app_new_message: boolean
  in_app_enquiry_status: boolean
}

interface MfaFactor {
  id: string
  factor_type: string
  status: string
}

export default function SettingsPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [notifications, setNotifications] = useState<NotificationPreferences | null>(null)
  const [loading, setLoading] = useState(true)
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingNotifications, setSavingNotifications] = useState(false)
  const [profileMsg, setProfileMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [notifMsg, setNotifMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const router = useRouter()
  const supabase = createClient()

  // Avatar state
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)
  const [avatarSignedUrl, setAvatarSignedUrl] = useState<string | null>(null)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // 2FA state
  const [mfaFactors, setMfaFactors] = useState<MfaFactor[]>([])
  const [mfaEnrolling, setMfaEnrolling] = useState(false)
  const [mfaQrCode, setMfaQrCode] = useState<string | null>(null)
  const [mfaFactorId, setMfaFactorId] = useState<string | null>(null)
  const [mfaCode, setMfaCode] = useState('')
  const [mfaMsg, setMfaMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [mfaLoading, setMfaLoading] = useState(false)

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [savingPassword, setSavingPassword] = useState(false)
  const [passwordMsg, setPasswordMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  // Form state
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')
  const [companyName, setCompanyName] = useState('')
  const [country, setCountry] = useState('')
  const [companyWebsite, setCompanyWebsite] = useState('')
  const [companyDescription, setCompanyDescription] = useState('')

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/login'); return }

      const { data: prof } = await supabase
        .from('profiles')
        .select('id, full_name, email, phone, company_name, country, company_website, company_description, role, avatar_url')
        .eq('id', user.id)
        .single()

      if (!prof) { router.push('/login'); return }
      setProfile(prof)
      setFullName(prof.full_name || '')
      setPhone(prof.phone || '')
      setCompanyName(prof.company_name || '')
      setCountry(prof.country || '')
      setCompanyWebsite(prof.company_website || '')
      setCompanyDescription(prof.company_description || '')

      // Load avatar signed URL
      if (prof.avatar_url) {
        const { data: signedData } = await supabase.storage
          .from('platform-files')
          .createSignedUrl(prof.avatar_url, 3600)
        if (signedData?.signedUrl) {
          setAvatarSignedUrl(signedData.signedUrl)
        }
      }

      // Load MFA factors
      const { data: mfaData } = await supabase.auth.mfa.listFactors()
      if (mfaData?.totp) {
        setMfaFactors(mfaData.totp.filter(f => f.status === 'verified').map(f => ({
          id: f.id,
          factor_type: f.factor_type,
          status: f.status,
        })))
      }

      // Load notification preferences
      const { data: notifPrefs } = await supabase
        .from('notification_preferences')
        .select('id, email_new_message, email_enquiry_status, email_new_investment, in_app_new_message, in_app_enquiry_status')
        .eq('user_id', user.id)
        .single()

      if (notifPrefs) {
        setNotifications(notifPrefs)
      } else {
        const { data: newPrefs } = await supabase
          .from('notification_preferences')
          .insert({
            user_id: user.id,
            email_new_message: true,
            email_enquiry_status: true,
            email_new_investment: true,
            in_app_new_message: true,
            in_app_enquiry_status: true,
          })
          .select()
          .single()

        if (newPrefs) setNotifications(newPrefs)
      }

      setLoading(false)
    }
    load()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Avatar upload
  async function handleAvatarSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return

    // Preview
    const reader = new FileReader()
    reader.onload = () => setAvatarPreview(reader.result as string)
    reader.readAsDataURL(file)

    // Upload
    setUploadingAvatar(true)
    try {
      const arrayBuffer = await file.arrayBuffer()
      const base64 = btoa(
        new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
      )

      const res = await fetch('/api/profile/avatar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageData: base64 }),
      })

      const result = await res.json()
      if (res.ok) {
        setProfileMsg({ type: 'success', text: 'Avatar updated successfully.' })
      } else {
        setProfileMsg({ type: 'error', text: result.error || 'Avatar upload failed.' })
        setAvatarPreview(null)
      }
    } catch {
      setProfileMsg({ type: 'error', text: 'Avatar upload failed.' })
      setAvatarPreview(null)
    }
    setUploadingAvatar(false)
  }

  // 2FA enrollment
  async function handleEnrollMfa() {
    setMfaLoading(true)
    setMfaMsg(null)
    try {
      const res = await fetch('/api/auth/mfa/enroll', { method: 'POST' })
      const result = await res.json()
      if (res.ok) {
        setMfaQrCode(result.data.qrCode)
        setMfaFactorId(result.data.factorId)
        setMfaEnrolling(true)
      } else {
        setMfaMsg({ type: 'error', text: result.error || 'Failed to start 2FA enrollment.' })
      }
    } catch {
      setMfaMsg({ type: 'error', text: 'Failed to start 2FA enrollment.' })
    }
    setMfaLoading(false)
  }

  async function handleVerifyMfa() {
    if (!mfaFactorId || !mfaCode) return
    setMfaLoading(true)
    setMfaMsg(null)
    try {
      const res = await fetch('/api/auth/mfa/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ factorId: mfaFactorId, code: mfaCode }),
      })
      const result = await res.json()
      if (res.ok) {
        setMfaMsg({ type: 'success', text: 'Two-factor authentication enabled successfully.' })
        setMfaEnrolling(false)
        setMfaQrCode(null)
        setMfaFactorId(null)
        setMfaCode('')
        setMfaFactors(prev => [...prev, { id: mfaFactorId, factor_type: 'totp', status: 'verified' }])
      } else {
        setMfaMsg({ type: 'error', text: result.error || 'Invalid verification code.' })
      }
    } catch {
      setMfaMsg({ type: 'error', text: 'Verification failed.' })
    }
    setMfaLoading(false)
  }

  async function handleDisableMfa(factorId: string) {
    setMfaLoading(true)
    setMfaMsg(null)
    try {
      const res = await fetch('/api/auth/mfa/unenroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ factorId }),
      })
      const result = await res.json()
      if (res.ok) {
        setMfaMsg({ type: 'success', text: 'Two-factor authentication disabled.' })
        setMfaFactors(prev => prev.filter(f => f.id !== factorId))
      } else {
        setMfaMsg({ type: 'error', text: result.error || 'Failed to disable 2FA.' })
      }
    } catch {
      setMfaMsg({ type: 'error', text: 'Failed to disable 2FA.' })
    }
    setMfaLoading(false)
  }

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault()
    if (!profile) return
    setSavingProfile(true)
    setProfileMsg(null)

    const { error } = await supabase
      .from('profiles')
      .update({
        full_name: fullName.trim(),
        phone: phone.trim() || null,
        company_name: companyName.trim() || null,
        country: country.trim() || null,
        company_website: companyWebsite.trim() || null,
        company_description: companyDescription.trim() || null,
      })
      .eq('id', profile.id)

    if (error) {
      setProfileMsg({ type: 'error', text: error.message })
    } else {
      setProfileMsg({ type: 'success', text: 'Profile updated successfully.' })
      setProfile(prev => prev ? { ...prev, full_name: fullName.trim() } : null)
    }
    setSavingProfile(false)
  }

  async function saveNotifications() {
    if (!notifications) return
    setSavingNotifications(true)
    setNotifMsg(null)

    const { error } = await supabase
      .from('notification_preferences')
      .update({
        email_new_message: notifications.email_new_message,
        email_enquiry_status: notifications.email_enquiry_status,
        email_new_investment: notifications.email_new_investment,
        in_app_new_message: notifications.in_app_new_message,
        in_app_enquiry_status: notifications.in_app_enquiry_status,
      })
      .eq('id', notifications.id)

    if (error) {
      setNotifMsg({ type: 'error', text: error.message })
    } else {
      setNotifMsg({ type: 'success', text: 'Notification preferences saved.' })
    }
    setSavingNotifications(false)
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault()
    if (!profile) return
    setPasswordMsg(null)

    if (newPassword.length < 8) {
      setPasswordMsg({ type: 'error', text: 'New password must be at least 8 characters.' })
      return
    }

    if (newPassword !== confirmPassword) {
      setPasswordMsg({ type: 'error', text: 'New passwords do not match.' })
      return
    }

    setSavingPassword(true)

    try {
      // Verify current password by signing in
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: profile.email,
        password: currentPassword,
      })

      if (signInError) {
        setPasswordMsg({ type: 'error', text: 'Current password is incorrect.' })
        setSavingPassword(false)
        return
      }

      // Update to new password
      const { error: updateError } = await supabase.auth.updateUser({
        password: newPassword,
      })

      if (updateError) {
        setPasswordMsg({ type: 'error', text: updateError.message })
      } else {
        setPasswordMsg({ type: 'success', text: 'Password changed successfully.' })
        setCurrentPassword('')
        setNewPassword('')
        setConfirmPassword('')
      }
    } catch {
      setPasswordMsg({ type: 'error', text: 'Failed to change password.' })
    }

    setSavingPassword(false)
  }

  function toggleNotif(key: keyof Omit<NotificationPreferences, 'id'>) {
    if (!notifications) return
    setNotifications(prev => prev ? { ...prev, [key]: !prev[key] } : null)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-czaah-muted">Loading...</div>
      </div>
    )
  }

  const displayAvatar = avatarPreview || avatarSignedUrl
  const userInitial = profile?.full_name?.[0]?.toUpperCase() || '?'

  return (
    <>
      <div className="mb-6">
        <h1 className="font-[family-name:var(--font-heading)] text-2xl text-czaah-white">
          Settings
        </h1>
      </div>

      <div className="space-y-8">
        {/* Profile Section */}
        <form onSubmit={saveProfile} className="bg-czaah-card border border-czaah-border rounded-lg">
          <div className="px-6 py-4 border-b border-czaah-border">
            <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
              Profile
            </h2>
          </div>

          <div className="px-6 py-6 space-y-5">
            {/* Avatar Upload */}
            <div className="flex items-center gap-5">
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  borderRadius: '50%',
                  overflow: 'hidden',
                  border: '2px solid rgba(201,168,76,0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: '#080808',
                  flexShrink: 0,
                }}
              >
                {displayAvatar ? (
                  <img
                    src={displayAvatar}
                    alt="Avatar"
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                ) : (
                  <span style={{
                    fontFamily: "'Cinzel', serif",
                    fontSize: '28px',
                    color: '#C9A84C',
                  }}>
                    {userInitial}
                  </span>
                )}
              </div>
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarSelect}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingAvatar}
                  className="text-sm text-czaah-gold border border-czaah-gold/30 px-4 py-2 rounded hover:bg-czaah-gold/10 transition-colors disabled:opacity-50"
                >
                  {uploadingAvatar ? 'Uploading...' : 'Change Photo'}
                </button>
                <p className="text-xs text-czaah-muted-dim mt-1.5">JPG, PNG. Max 5MB.</p>
              </div>
            </div>

            {/* Email (read-only) */}
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Email</label>
              <input
                type="email"
                value={profile?.email || ''}
                disabled
                className="w-full bg-czaah-elevated border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-muted-dim cursor-not-allowed"
              />
            </div>

            {/* Full Name */}
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Full Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Phone</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
                placeholder="+1 234 567 8900"
              />
            </div>

            {/* Company Name */}
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Company Name</label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
              />
            </div>

            {/* Country */}
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Country</label>
              <input
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
              />
            </div>

            {/* Company Website */}
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Company Website</label>
              <input
                type="url"
                value={companyWebsite}
                onChange={(e) => setCompanyWebsite(e.target.value)}
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
                placeholder="https://example.com"
              />
            </div>

            {/* Company Description */}
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Company Description</label>
              <textarea
                value={companyDescription}
                onChange={(e) => setCompanyDescription(e.target.value)}
                rows={3}
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors resize-none"
              />
            </div>

            {profileMsg && (
              <div className={`text-sm px-4 py-2.5 rounded ${
                profileMsg.type === 'success'
                  ? 'bg-green-500/10 border border-green-500/20 text-green-400'
                  : 'bg-red-500/10 border border-red-500/20 text-red-400'
              }`}>
                {profileMsg.text}
              </div>
            )}
          </div>

          <div className="px-6 py-4 border-t border-czaah-border">
            <button
              type="submit"
              disabled={savingProfile}
              className="bg-czaah-gold text-czaah-black font-semibold px-6 py-2.5 rounded hover:bg-czaah-gold/90 transition-colors text-sm disabled:opacity-50"
            >
              {savingProfile ? 'Saving...' : 'Save Profile'}
            </button>
          </div>
        </form>

        {/* Two-Factor Authentication */}
        <div className="bg-czaah-card border border-czaah-border rounded-lg">
          <div className="px-6 py-4 border-b border-czaah-border">
            <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
              Two-Factor Authentication
            </h2>
          </div>

          <div className="px-6 py-6 space-y-4">
            {mfaFactors.length > 0 ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500" />
                    <span className="text-sm text-czaah-white">2FA Enabled</span>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded bg-green-500/10 border border-green-500/20 text-green-400">
                    Active
                  </span>
                </div>
                <p className="text-xs text-czaah-muted-dim">
                  Your account is protected with TOTP-based two-factor authentication.
                </p>
                {mfaFactors.map(factor => (
                  <button
                    key={factor.id}
                    onClick={() => handleDisableMfa(factor.id)}
                    disabled={mfaLoading}
                    className="text-sm text-red-400 border border-red-400/30 px-4 py-2 rounded hover:bg-red-400/10 transition-colors disabled:opacity-50"
                  >
                    {mfaLoading ? 'Processing...' : 'Disable 2FA'}
                  </button>
                ))}
              </div>
            ) : mfaEnrolling ? (
              <div className="space-y-4">
                <p className="text-sm text-czaah-muted">
                  Scan the QR code below with your authenticator app (Google Authenticator, Authy, etc.), then enter the 6-digit code.
                </p>
                {mfaQrCode && (
                  <div className="flex justify-center py-4">
                    <img
                      src={mfaQrCode}
                      alt="2FA QR Code"
                      style={{
                        width: '200px',
                        height: '200px',
                        borderRadius: '8px',
                        background: '#fff',
                        padding: '8px',
                      }}
                    />
                  </div>
                )}
                <div>
                  <label className="block text-sm text-czaah-muted mb-1.5">Verification Code</label>
                  <input
                    type="text"
                    value={mfaCode}
                    onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    maxLength={6}
                    className="w-full max-w-xs bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors tracking-widest text-center text-lg"
                  />
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={handleVerifyMfa}
                    disabled={mfaLoading || mfaCode.length !== 6}
                    className="bg-czaah-gold text-czaah-black font-semibold px-6 py-2.5 rounded hover:bg-czaah-gold/90 transition-colors text-sm disabled:opacity-50"
                  >
                    {mfaLoading ? 'Verifying...' : 'Verify & Enable'}
                  </button>
                  <button
                    onClick={() => { setMfaEnrolling(false); setMfaQrCode(null); setMfaFactorId(null); setMfaCode('') }}
                    className="text-sm text-czaah-muted border border-czaah-border px-4 py-2.5 rounded hover:text-czaah-white transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-czaah-muted">
                  Add an extra layer of security to your account by enabling two-factor authentication with an authenticator app.
                </p>
                <button
                  onClick={handleEnrollMfa}
                  disabled={mfaLoading}
                  className="bg-czaah-gold text-czaah-black font-semibold px-6 py-2.5 rounded hover:bg-czaah-gold/90 transition-colors text-sm disabled:opacity-50"
                >
                  {mfaLoading ? 'Loading...' : 'Enable 2FA'}
                </button>
              </div>
            )}

            {mfaMsg && (
              <div className={`text-sm px-4 py-2.5 rounded ${
                mfaMsg.type === 'success'
                  ? 'bg-green-500/10 border border-green-500/20 text-green-400'
                  : 'bg-red-500/10 border border-red-500/20 text-red-400'
              }`}>
                {mfaMsg.text}
              </div>
            )}
          </div>
        </div>

        {/* Notification Preferences */}
        <div className="bg-czaah-card border border-czaah-border rounded-lg">
          <div className="px-6 py-4 border-b border-czaah-border">
            <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
              Notification Preferences
            </h2>
          </div>

          {notifications && (
            <div className="px-6 py-6 space-y-6">
              {/* Email notifications */}
              <div>
                <h3 className="text-sm font-medium text-czaah-white mb-3">Email Notifications</h3>
                <div className="space-y-3">
                  <NotifToggle
                    label="New messages"
                    description="Receive an email when you get a new chat message"
                    checked={notifications.email_new_message}
                    onChange={() => toggleNotif('email_new_message')}
                  />
                  <NotifToggle
                    label="Enquiry status changes"
                    description="Receive an email when your enquiry status changes"
                    checked={notifications.email_enquiry_status}
                    onChange={() => toggleNotif('email_enquiry_status')}
                  />
                  <NotifToggle
                    label="New investment opportunities"
                    description="Receive an email about new investment listings"
                    checked={notifications.email_new_investment}
                    onChange={() => toggleNotif('email_new_investment')}
                  />
                </div>
              </div>

              {/* In-app notifications */}
              <div>
                <h3 className="text-sm font-medium text-czaah-white mb-3">In-App Notifications</h3>
                <div className="space-y-3">
                  <NotifToggle
                    label="New messages"
                    description="Show in-app notification for new chat messages"
                    checked={notifications.in_app_new_message}
                    onChange={() => toggleNotif('in_app_new_message')}
                  />
                  <NotifToggle
                    label="Enquiry status changes"
                    description="Show in-app notification for enquiry updates"
                    checked={notifications.in_app_enquiry_status}
                    onChange={() => toggleNotif('in_app_enquiry_status')}
                  />
                </div>
              </div>

              {notifMsg && (
                <div className={`text-sm px-4 py-2.5 rounded ${
                  notifMsg.type === 'success'
                    ? 'bg-green-500/10 border border-green-500/20 text-green-400'
                    : 'bg-red-500/10 border border-red-500/20 text-red-400'
                }`}>
                  {notifMsg.text}
                </div>
              )}
            </div>
          )}

          <div className="px-6 py-4 border-t border-czaah-border">
            <button
              onClick={saveNotifications}
              disabled={savingNotifications}
              className="bg-czaah-gold text-czaah-black font-semibold px-6 py-2.5 rounded hover:bg-czaah-gold/90 transition-colors text-sm disabled:opacity-50"
            >
              {savingNotifications ? 'Saving...' : 'Save Preferences'}
            </button>
          </div>
        </div>
        {/* Change Password */}
        <form onSubmit={changePassword} className="bg-czaah-card border border-czaah-border rounded-lg">
          <div className="px-6 py-4 border-b border-czaah-border">
            <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white">
              Change Password
            </h2>
          </div>

          <div className="px-6 py-6 space-y-5">
            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Current Password</label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
                placeholder="Enter your current password"
              />
            </div>

            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">New Password</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={8}
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
                placeholder="Minimum 8 characters"
              />
            </div>

            <div>
              <label className="block text-sm text-czaah-muted mb-1.5">Confirm New Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                minLength={8}
                className="w-full bg-czaah-black border border-czaah-border rounded px-4 py-2.5 text-sm text-czaah-white focus:border-czaah-gold focus:outline-none transition-colors"
                placeholder="Re-enter your new password"
              />
            </div>

            {passwordMsg && (
              <div className={`text-sm px-4 py-2.5 rounded ${
                passwordMsg.type === 'success'
                  ? 'bg-green-500/10 border border-green-500/20 text-green-400'
                  : 'bg-red-500/10 border border-red-500/20 text-red-400'
              }`}>
                {passwordMsg.text}
              </div>
            )}
          </div>

          <div className="px-6 py-4 border-t border-czaah-border">
            <button
              type="submit"
              disabled={savingPassword}
              className="bg-czaah-gold text-czaah-black font-semibold px-6 py-2.5 rounded hover:bg-czaah-gold/90 transition-colors text-sm disabled:opacity-50"
            >
              {savingPassword ? 'Changing...' : 'Change Password'}
            </button>
          </div>
        </form>
      </div>
    </>
  )
}

function NotifToggle({
  label, description, checked, onChange,
}: {
  label: string; description: string; checked: boolean; onChange: () => void
}) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group">
      <div className="pt-0.5">
        <button
          type="button"
          role="switch"
          aria-checked={checked}
          onClick={onChange}
          className={`relative w-9 h-5 rounded-full transition-colors ${
            checked ? 'bg-czaah-gold' : 'bg-czaah-elevated border border-czaah-border'
          }`}
        >
          <span
            className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full transition-transform ${
              checked ? 'translate-x-4 bg-czaah-black' : 'translate-x-0 bg-czaah-muted'
            }`}
          />
        </button>
      </div>
      <div>
        <p className="text-sm text-czaah-white group-hover:text-czaah-gold transition-colors">{label}</p>
        <p className="text-xs text-czaah-muted-dim">{description}</p>
      </div>
    </label>
  )
}
