'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

const edTabs = [
  {
    id: 'higher', icon: '\uD83C\uDF93', label: 'Higher Education',
    title: 'Higher Education',
    desc: 'Pakistan has 235+ HEC-recognised universities serving a rapidly expanding student population. Demand for quality tertiary education outstrips supply — particularly in engineering, business, and health sciences.',
    stats: [{ value: '235+', label: 'HEC Universities' }, { value: '2.5M+', label: 'Enrolled Students' }, { value: '9%', label: 'Gross Enrolment Rate' }],
    details: [
      { heading: 'Opportunities', items: ['Private university campuses', 'Franchise partnerships', 'Research park development', 'Faculty exchange programmes'] },
      { heading: 'Key Bodies', items: ['HEC (Higher Education Commission)', 'PEC (Pakistan Engineering Council)', 'PMDC (Medical & Dental Council)'] },
      { heading: 'Growth Drivers', items: ['Youth bulge (64% under 30)', 'Rising middle class', 'Professional certification demand'] }
    ]
  },
  {
    id: 'k12', icon: '\uD83D\uDCDA', label: 'K-12 & Schools',
    title: 'K-12 & School Networks',
    desc: 'With 51M+ school-age children and only 30% enrolled in private institutions, Pakistan\'s K-12 sector represents one of the largest untapped markets in global education.',
    stats: [{ value: '51M+', label: 'School-Age Children' }, { value: '260K+', label: 'Private Schools' }, { value: '30%', label: 'Private Sector Share' }],
    details: [
      { heading: 'Opportunities', items: ['School chain acquisition', 'Franchise model expansion', 'Curriculum licensing', 'Teacher training institutes'] },
      { heading: 'Key Bodies', items: ['Provincial Education Departments', 'Federal Directorate of Education', 'PEIRA (Islamabad)'] },
      { heading: 'Models', items: ['Affordable private (mass market)', 'Premium (O/A Levels, IB)', 'Hybrid digital-physical'] }
    ]
  },
  {
    id: 'vocational', icon: '\u2692', label: 'Vocational & TVET',
    title: 'Vocational & Technical Training',
    desc: 'Pakistan needs 30,000+ skilled workers per year for CPEC projects alone. Existing TVET infrastructure covers fewer than 500,000 students annually — creating a massive supply-demand gap.',
    stats: [{ value: '3,600+', label: 'TVET Institutes' }, { value: '500K', label: 'Annual Enrolment' }, { value: 'CPEC', label: 'Demand Driver' }],
    details: [
      { heading: 'Opportunities', items: ['Technical training centres', 'Industry-aligned curricula', 'Gulf workforce certification', 'German/Chinese TVET models'] },
      { heading: 'Key Bodies', items: ['NAVTTC (National Vocational)', 'TEVTAs (Provincial)', 'PBTE (Technical Boards)'] },
      { heading: 'Priority Trades', items: ['Construction & civil works', 'Welding & fabrication', 'IT & networking', 'Hospitality'] }
    ]
  },
  {
    id: 'edtech', icon: '\uD83D\uDCBB', label: 'EdTech',
    title: 'EdTech & Digital Learning',
    desc: 'Mobile penetration at 85%+ and broadband expansion are unlocking digital education at scale. Pakistan\'s EdTech market is projected to reach $3.5B by 2028.',
    stats: [{ value: '$3.5B', label: 'Projected by 2028' }, { value: '85%+', label: 'Mobile Penetration' }, { value: '40%+', label: 'Growth YoY' }],
    details: [
      { heading: 'Opportunities', items: ['LMS platform deployment', 'Assessment & certification', 'AI tutoring systems', 'Content localisation'] },
      { heading: 'Infrastructure', items: ['5G rollout (2025-2027)', 'USF rural connectivity', 'Punjab IT Board labs'] },
      { heading: 'Segments', items: ['Test preparation', 'Language learning', 'Professional upskilling', 'K-12 supplementary'] }
    ]
  },
  {
    id: 'medical', icon: '\u2624', label: 'Medical & Health',
    title: 'Medical & Health Sciences',
    desc: 'Pakistan produces 20,000+ medical graduates annually from 170+ medical and dental colleges. International accreditation partnerships and simulation-based training represent significant growth areas.',
    stats: [{ value: '170+', label: 'Medical Colleges' }, { value: '20K+', label: 'Annual Graduates' }, { value: 'High', label: 'Gulf Demand' }],
    details: [
      { heading: 'Opportunities', items: ['Private medical universities', 'Nursing & allied health', 'Simulation centres', 'Postgraduate specialisation'] },
      { heading: 'Key Bodies', items: ['PMDC', 'PNC (Pakistan Nursing Council)', 'HEC'] },
      { heading: 'Export Markets', items: ['Gulf healthcare systems', 'UK NHS recruitment', 'Southeast Asia'] }
    ]
  },
  {
    id: 'international', icon: '\uD83C\uDF10', label: 'International Schools',
    title: 'International Schools',
    desc: 'Rising HNWI families, expatriate demand, and diaspora return migration are driving demand for internationally accredited schools offering IB, Cambridge, and American curricula.',
    stats: [{ value: '50+', label: 'International Schools' }, { value: '$15K+', label: 'Avg Annual Fees' }, { value: 'Growing', label: 'Returnee Demand' }],
    details: [
      { heading: 'Opportunities', items: ['IB World School campuses', 'Cambridge-affiliated networks', 'American school models', 'Boarding school development'] },
      { heading: 'Key Cities', items: ['Islamabad', 'Lahore', 'Karachi'] },
      { heading: 'Client Profile', items: ['HNWI families', 'Expatriate executives', 'Diplomatic corps', 'Diaspora returnees'] }
    ]
  },
];

export default function EducationPage() {
  const [activeTab, setActiveTab] = useState('higher');
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => { entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add('visible'); }); },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach((el) => { observerRef.current?.observe(el); });
    return () => observerRef.current?.disconnect();
  }, []);

  const activePanel = edTabs.find(t => t.id === activeTab)!;

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Education.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">230M Population &middot; 64% Under 30 &middot; $8B+ Education Market</div>
              <h1 className="serif hero-enter hero-enter-delay-2"><span className="gold">Education.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Pakistan&apos;s youngest demographic in its history meets the largest education infrastructure gap in South Asia. CZAAH facilitates institutional partnerships, campus development, and EdTech deployment for international education investors.</p>
              <a href="/contact?interest=Education#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Explore Partnerships &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* EDUCATION CATALOG */}
        <style>{`
          .ed-catalog { display: flex; gap: 0; min-height: 520px; }
          .ed-tabs { display: flex; flex-direction: column; min-width: 220px; max-width: 220px; border-right: 1px solid var(--black-border); }
          .ed-tab-btn { display: flex; align-items: center; gap: 12px; padding: 18px 20px; background: transparent; border: none; border-left: 3px solid transparent; color: var(--white-dim); font-family: 'Raleway', sans-serif; font-size: 0.9rem; cursor: pointer; text-align: left; transition: all 0.3s var(--ease-smooth); }
          .ed-tab-btn:hover { color: var(--white-muted); background: var(--black-elevated); }
          .ed-tab-btn.ed-active { border-left-color: var(--gold); color: var(--gold); background: var(--black-elevated); }
          .ed-tab-icon { font-size: 1.2rem; width: 24px; text-align: center; flex-shrink: 0; }
          .ed-tab-label { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
          .ed-panels { flex: 1; position: relative; overflow: hidden; }
          .ed-panel { padding: 32px 40px; }
          .ed-panel-title { font-family: 'Cinzel', serif; font-size: 1.6rem; color: var(--white); margin-bottom: 6px; }
          .ed-panel-desc { color: var(--white-muted); font-size: 0.95rem; line-height: 1.7; margin-bottom: 24px; }
          .ed-stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 28px; }
          .ed-stat-card { background: var(--black-card); border: 1px solid var(--black-border); border-radius: 8px; padding: 16px 18px; text-align: center; }
          .ed-stat-value { font-family: 'Cinzel', serif; font-size: 1.3rem; color: var(--gold); margin-bottom: 4px; }
          .ed-stat-label { font-size: 0.78rem; color: var(--white-dim); text-transform: uppercase; letter-spacing: 0.05em; }
          .ed-detail-row { display: flex; gap: 32px; margin-bottom: 20px; flex-wrap: wrap; }
          .ed-detail-block { flex: 1; min-width: 180px; }
          .ed-detail-block h5 { font-family: 'Raleway', sans-serif; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.08em; color: var(--gold-dim); margin-bottom: 8px; }
          .ed-detail-block ul { list-style: none; padding: 0; margin: 0; }
          .ed-detail-block li { color: var(--white-muted); font-size: 0.88rem; padding: 3px 0; position: relative; padding-left: 14px; }
          .ed-detail-block li::before { content: '\u203A'; position: absolute; left: 0; color: var(--gold); }
          .ed-enquire { display: inline-block; margin-top: 8px; color: var(--gold); font-size: 0.9rem; font-weight: 500; text-decoration: none; transition: opacity 0.2s; }
          .ed-enquire:hover { opacity: 0.75; }
          @media (max-width: 768px) { .ed-catalog { flex-direction: column; min-height: auto; } .ed-tabs { flex-direction: row; max-width: none; min-width: 0; overflow-x: auto; border-right: none; border-bottom: 1px solid var(--black-border); -webkit-overflow-scrolling: touch; scrollbar-width: none; } .ed-tabs::-webkit-scrollbar { display: none; } .ed-tab-btn { border-left: none; border-bottom: 3px solid transparent; padding: 14px 18px; white-space: nowrap; flex-shrink: 0; } .ed-tab-btn.ed-active { border-left-color: transparent; border-bottom-color: var(--gold); } .ed-panels { position: relative; min-height: 480px; } .ed-panel { padding: 24px 16px; } .ed-stats-grid { grid-template-columns: repeat(2, 1fr); } }
        `}</style>

        <section className="section fade-in">
          <h2 className="serif">Education <span className="gold">landscape.</span></h2>
          <p className="subtitle">From elite private universities to vocational training at scale — Pakistan&apos;s education sector is being reshaped by demographic pressure and institutional demand.</p>

          <div className="ed-catalog" style={{ background: 'var(--black-card)', border: '1px solid var(--black-border)', borderRadius: '12px', overflow: 'hidden', marginTop: '32px' }}>
            <div className="ed-tabs">
              {edTabs.map(tab => (
                <button key={tab.id} className={`ed-tab-btn${activeTab === tab.id ? ' ed-active' : ''}`} onClick={() => setActiveTab(tab.id)}>
                  <span className="ed-tab-icon">{tab.icon}</span>
                  <span className="ed-tab-label">{tab.label}</span>
                </button>
              ))}
            </div>
            <div className="ed-panels">
              <div className="ed-panel">
                <div className="ed-panel-title">{activePanel.title}</div>
                <p className="ed-panel-desc">{activePanel.desc}</p>
                <div className="ed-stats-grid">
                  {activePanel.stats.map((s, i) => (
                    <div key={i} className="ed-stat-card">
                      <div className="ed-stat-value">{s.value}</div>
                      <div className="ed-stat-label">{s.label}</div>
                    </div>
                  ))}
                </div>
                <div className="ed-detail-row">
                  {activePanel.details.map((d, i) => (
                    <div key={i} className="ed-detail-block">
                      <h5>{d.heading}</h5>
                      <ul>{d.items.map((item, j) => (<li key={j}>{item}</li>))}</ul>
                    </div>
                  ))}
                </div>
                <a href="/contact" className="ed-enquire">Enquire &rarr;</a>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* REGULATORY FRAMEWORK */}
        <section className="section fade-in">
          <h2 className="serif">Regulatory <span className="gold">framework.</span></h2>
          <p className="subtitle">Pakistan&apos;s education sector operates under federal and provincial regulatory structures with distinct requirements by institution type.</p>
          <div className="relationships stagger">
            <div className="rel-card"><div className="rel-icon">&#9670;</div><div><h4>Higher Education Commission (HEC)</h4><p>Federal body governing university recognition, degree attestation, quality assurance, and faculty credentialing. All degree-granting institutions require HEC charter.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9632;</div><div><h4>Provincial Education Departments</h4><p>K-12 regulation is devolved to provinces post-18th Amendment. Each province maintains its own registration, curriculum, and examination frameworks.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9733;</div><div><h4>NAVTTC &amp; TEVTAs</h4><p>National and provincial vocational training authorities regulate TVET standards, trade certification, and skills qualification frameworks aligned with national priorities.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#8644;</div><div><h4>Professional Councils</h4><p>PMDC, PEC, PNC, and PBA regulate professional education in medicine, engineering, nursing, and law respectively. Each requires programme-level accreditation.</p></div></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Institutional facilitation for international education investors, operators, and technology providers entering Pakistan.</p>
          <div className="detail-grid stagger">
            <div className="detail-card"><div className="card-icon">&#9670;</div><h3>Market Intelligence</h3><p>Demographic analysis, competitive mapping, and feasibility studies for education investments — from urban K-12 to rural vocational.</p></div>
            <div className="detail-card"><div className="card-icon">&#9881;</div><h3>Institutional Partnerships</h3><p>Connecting international universities and school groups with Pakistani institutions for franchise, affiliation, and joint degree arrangements.</p></div>
            <div className="detail-card"><div className="card-icon">&#9733;</div><h3>Regulatory Navigation</h3><p>HEC charter applications, provincial NOCs, professional council accreditation, and campus approval facilitation.</p></div>
            <div className="detail-card"><div className="card-icon">&#8644;</div><h3>Campus Development</h3><p>Site acquisition, construction management, and campus infrastructure development through our real estate and construction verticals.</p></div>
            <div className="detail-card"><div className="card-icon">&#36;</div><h3>EdTech Deployment</h3><p>Government and private sector distribution for learning management systems, assessment platforms, and digital content providers.</p></div>
            <div className="detail-card"><div className="card-icon">&#43;</div><h3>Workforce Pipeline</h3><p>Design and operationalise training programmes aligned with Gulf and international labour market requirements through NAVTTC frameworks.</p></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">Pakistan&apos;s education sector <span className="gold">at a glance.</span></h2>
          <div className="stats-row stagger">
            <div className="stat-item"><div className="number">$8B+</div><div className="label">Education market size</div></div>
            <div className="stat-item"><div className="number">64%</div><div className="label">Population under 30</div></div>
            <div className="stat-item"><div className="number">51M+</div><div className="label">School-age children</div></div>
            <div className="stat-item"><div className="number">235+</div><div className="label">HEC-recognised universities</div></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* INVESTMENT OPPORTUNITIES */}
        <section className="section fade-in">
          <h2 className="serif">Investment <span className="gold">opportunities.</span></h2>
          <p className="subtitle">Structural demand across every education segment — driven by demographics, policy reform, and the digital transition.</p>
          <div className="relationships stagger">
            <div className="rel-card"><div className="rel-icon">&#9670;</div><div><h4>Affordable Private Schools</h4><p>Low-cost private school networks serving the mass market represent the fastest-growing segment. Unit economics are proven — the challenge is operational scale.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9632;</div><div><h4>TVET for Export</h4><p>Gulf and European labour markets need certified Pakistani workers. Investment in NAVTTC-aligned training centres creates a direct revenue pathway through deployment fees.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9733;</div><div><h4>University Campus Development</h4><p>Pakistan&apos;s gross tertiary enrolment rate of 9% compares to 28% in India and 51% globally. New campus development is the primary constraint to expansion.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#8644;</div><div><h4>Digital Assessment &amp; Certification</h4><p>Online examination systems, digital credentialing, and AI-driven assessment platforms are replacing paper-based testing across government and private institutions.</p></div></div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">The largest youth population <span className="gold">in Pakistan&apos;s history.</span></h2>
          <p>Education infrastructure, institutional partnerships, and EdTech deployment for investors who understand demographic inevitability.</p>
          <a href="/contact?interest=Education#contact-form" className="btn-gold">Discuss Opportunities &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
