'use client';
// @ts-nocheck

import { useEffect, useState } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface SecurityAssessment {
  level: number;
  threats: string[];
  pkg: string;
  includes: string[];
  personnel: string;
  response: string;
  monitoring: string;
}

type OpType = 'mining' | 'construction' | 'corporate' | 'vip' | 'logistics' | 'energy';
type LocType = 'balochistan' | 'kpk' | 'sindh' | 'punjab' | 'islamabad' | 'gb';

const data: Record<OpType, Record<LocType, SecurityAssessment>> = {
  mining: {
    balochistan: { level: 5, threats: ["Kidnapping", "Armed Militancy", "Tribal Disputes", "IED/Explosives"], pkg: "Maximum Protection Protocol", includes: ["Armed escort teams", "Counter-surveillance operations", "Tribal liaison & negotiation", "Secure compound establishment", "Emergency extraction plan"], personnel: "12\u201320", response: "< 10 min", monitoring: "24/7 Active" },
    kpk: { level: 4, threats: ["Militant Activity", "Kidnapping", "Road Hazards", "Tribal Disputes"], pkg: "Enhanced Protection Protocol", includes: ["Armed escort convoy", "Threat intelligence briefings", "Site perimeter security", "Emergency evacuation planning", "Local liaison coordination"], personnel: "10\u201316", response: "< 12 min", monitoring: "24/7 Active" },
    sindh: { level: 3, threats: ["Dacoity", "Kidnapping for Ransom", "Civil Unrest", "Road Hazards"], pkg: "Elevated Security Package", includes: ["Armed site security", "Convoy protection", "Threat monitoring & alerts", "Community engagement support"], personnel: "8\u201314", response: "< 20 min", monitoring: "24/7 Active" },
    punjab: { level: 2, threats: ["Petty Crime", "Labour Disputes", "Road Safety", "Theft"], pkg: "Standard Protection Package", includes: ["Site access control", "Perimeter monitoring", "Security personnel deployment", "Incident reporting system"], personnel: "6\u201310", response: "< 25 min", monitoring: "24/7 Active" },
    islamabad: { level: 2, threats: ["Petty Crime", "Regulatory Disruption", "Protest Activity", "Theft"], pkg: "Standard Protection Package", includes: ["Facility security", "CCTV & access control", "Personnel screening", "Incident response protocol"], personnel: "4\u20138", response: "< 25 min", monitoring: "24/7 Active" },
    gb: { level: 4, threats: ["Terrain Hazards", "Sectarian Tensions", "Road Blockades", "Avalanche/Landslide Risk"], pkg: "Remote Operations Protocol", includes: ["Mountain security teams", "Helicopter evacuation standby", "Satellite communication systems", "Weather & terrain monitoring", "Medical emergency response"], personnel: "10\u201318", response: "< 15 min", monitoring: "24/7 Active" }
  },
  construction: {
    balochistan: { level: 5, threats: ["Armed Attacks", "Sabotage", "Kidnapping", "Tribal Opposition"], pkg: "Maximum Protection Protocol", includes: ["Armed perimeter teams", "Counter-surveillance", "Anti-sabotage patrols", "Tribal engagement & liaison", "Secure worker housing"], personnel: "14\u201322", response: "< 10 min", monitoring: "24/7 Active" },
    kpk: { level: 4, threats: ["Militant Threats", "Sabotage", "Labour Extortion", "Civil Unrest"], pkg: "Enhanced Protection Protocol", includes: ["Site perimeter security", "Convoy escort", "Threat intelligence", "Emergency extraction plan", "Worker safety briefings"], personnel: "8\u201315", response: "< 15 min", monitoring: "24/7 Active" },
    sindh: { level: 3, threats: ["Dacoity", "Equipment Theft", "Labour Disputes", "Extortion"], pkg: "Elevated Security Package", includes: ["24/7 site guards", "Equipment monitoring", "Access control systems", "Community liaison"], personnel: "6\u201312", response: "< 20 min", monitoring: "24/7 Active" },
    punjab: { level: 2, threats: ["Theft", "Labour Disputes", "Trespassing", "Vandalism"], pkg: "Standard Site Security", includes: ["Site access control", "Guard patrols", "CCTV monitoring", "Incident reporting"], personnel: "4\u20138", response: "< 30 min", monitoring: "Business hours + on-call" },
    islamabad: { level: 1, threats: ["Theft", "Trespassing", "Regulatory Compliance", "Vandalism"], pkg: "Basic Site Security", includes: ["Access control", "Guard deployment", "CCTV system", "Visitor management"], personnel: "3\u20136", response: "< 30 min", monitoring: "Business hours + on-call" },
    gb: { level: 4, threats: ["Terrain Hazards", "Road Blockades", "Landslide Risk", "Sectarian Tensions"], pkg: "Remote Construction Protocol", includes: ["Mountain-trained security", "Satellite comms", "Helicopter medevac standby", "Road monitoring teams", "Weather risk management"], personnel: "10\u201316", response: "< 15 min", monitoring: "24/7 Active" }
  },
  corporate: {
    balochistan: { level: 3, threats: ["Targeted Attacks", "Kidnapping", "Civil Unrest", "Extortion"], pkg: "Elevated Office Security", includes: ["Armed reception security", "Executive safe room", "Counter-surveillance", "Emergency protocols", "Secure transport"], personnel: "6\u201310", response: "< 15 min", monitoring: "24/7 Active" },
    kpk: { level: 3, threats: ["Militant Threats", "Targeted Crime", "Protest Activity", "Extortion"], pkg: "Elevated Office Security", includes: ["Armed guards", "CCTV & alarm systems", "Vehicle screening", "Emergency evacuation plan"], personnel: "5\u20138", response: "< 20 min", monitoring: "24/7 Active" },
    sindh: { level: 2, threats: ["Street Crime", "Protest Disruption", "Theft", "Extortion Attempts"], pkg: "Standard Office Security", includes: ["Reception security", "Access control", "CCTV monitoring", "Incident response protocol"], personnel: "4\u20136", response: "< 25 min", monitoring: "Business hours + on-call" },
    punjab: { level: 2, threats: ["Petty Crime", "Protest Activity", "Theft", "Cyber Threats"], pkg: "Standard Office Security", includes: ["Access control", "CCTV monitoring", "Reception security", "Visitor management"], personnel: "3\u20135", response: "< 30 min", monitoring: "Business hours + on-call" },
    islamabad: { level: 1, threats: ["Petty Crime", "Protest Disruption", "Regulatory Risk", "Cyber Threats"], pkg: "Basic Corporate Security", includes: ["Access control", "CCTV monitoring", "Reception security", "Incident reporting"], personnel: "2\u20134", response: "< 30 min", monitoring: "Business hours + on-call" },
    gb: { level: 3, threats: ["Sectarian Tensions", "Road Blockades", "Communication Outages", "Natural Disasters"], pkg: "Remote Office Protocol", includes: ["Armed security", "Satellite communications", "Emergency supplies", "Evacuation planning"], personnel: "4\u20137", response: "< 20 min", monitoring: "24/7 Active" }
  },
  vip: {
    balochistan: { level: 5, threats: ["Kidnapping", "Assassination Risk", "Armed Ambush", "IED/Explosives"], pkg: "Maximum Executive Protection", includes: ["Close protection team", "Armoured vehicles", "Advance route reconnaissance", "Counter-surveillance", "Emergency extraction & medevac"], personnel: "8\u201314", response: "< 5 min", monitoring: "24/7 Active" },
    kpk: { level: 4, threats: ["Kidnapping", "Targeted Attack", "Road Ambush", "Militant Activity"], pkg: "Enhanced Executive Protection", includes: ["Close protection officers", "Armoured transport", "Route planning & reconnaissance", "Safe house arrangement", "Medical support standby"], personnel: "6\u201310", response: "< 10 min", monitoring: "24/7 Active" },
    sindh: { level: 3, threats: ["Kidnapping for Ransom", "Carjacking", "Street Crime", "Civil Unrest"], pkg: "Executive Travel Security", includes: ["Close protection detail", "Secure vehicle", "Route monitoring", "Hotel security coordination"], personnel: "4\u20138", response: "< 15 min", monitoring: "24/7 Active" },
    punjab: { level: 2, threats: ["Street Crime", "Protest Disruption", "Traffic Hazards", "Opportunistic Crime"], pkg: "Standard Executive Security", includes: ["Protection officer", "Secure vehicle", "Route planning", "Hotel security liaison"], personnel: "3\u20135", response: "< 20 min", monitoring: "24/7 Active" },
    islamabad: { level: 2, threats: ["Protest Activity", "Street Crime", "Traffic Disruption", "Opportunistic Targeting"], pkg: "Standard Executive Security", includes: ["Protection officer", "Secure vehicle", "Airport transfers", "Hotel coordination"], personnel: "2\u20134", response: "< 20 min", monitoring: "24/7 Active" },
    gb: { level: 4, threats: ["Road Hazards", "Terrain Risks", "Sectarian Tensions", "Communication Gaps"], pkg: "Remote Executive Protocol", includes: ["Mountain-trained CPO team", "4x4 convoy", "Helicopter standby", "Satellite phone", "Medical kit & medevac plan"], personnel: "6\u201310", response: "< 10 min", monitoring: "24/7 Active" }
  },
  logistics: {
    balochistan: { level: 5, threats: ["Highway Robbery", "Cargo Hijacking", "IED/Explosives", "Armed Ambush"], pkg: "Maximum Convoy Protection", includes: ["Armed escort vehicles", "Route reconnaissance", "GPS cargo tracking", "Anti-ambush protocols", "Emergency response teams"], personnel: "10\u201318", response: "< 10 min", monitoring: "24/7 Active" },
    kpk: { level: 4, threats: ["Cargo Theft", "Road Ambush", "Extortion", "Militant Checkpoints"], pkg: "Enhanced Convoy Security", includes: ["Armed escort", "Route intelligence", "Real-time tracking", "Alternative route planning", "Driver security briefings"], personnel: "8\u201314", response: "< 12 min", monitoring: "24/7 Active" },
    sindh: { level: 3, threats: ["Highway Robbery", "Cargo Theft", "Dacoity", "Road Hazards"], pkg: "Convoy Escort Package", includes: ["Armed escorts", "GPS tracking", "Rest stop security", "Incident response team"], personnel: "6\u201310", response: "< 20 min", monitoring: "24/7 Active" },
    punjab: { level: 2, threats: ["Cargo Theft", "Road Accidents", "Petty Crime", "Traffic Disruption"], pkg: "Standard Transport Security", includes: ["GPS tracking", "Driver protocols", "Route monitoring", "Incident response"], personnel: "4\u20136", response: "< 25 min", monitoring: "Business hours + on-call" },
    islamabad: { level: 1, threats: ["Traffic Disruption", "Petty Theft", "Road Accidents", "Protest Blockades"], pkg: "Basic Transport Security", includes: ["GPS tracking", "Route planning", "Driver check-ins", "Incident reporting"], personnel: "2\u20134", response: "< 30 min", monitoring: "Business hours + on-call" },
    gb: { level: 4, threats: ["Road Collapse", "Landslides", "Cargo Theft", "Terrain Hazards"], pkg: "Mountain Transport Protocol", includes: ["4x4 escort vehicles", "Satellite tracking", "Weather monitoring", "Road condition intelligence", "Emergency recovery teams"], personnel: "8\u201312", response: "< 15 min", monitoring: "24/7 Active" }
  },
  energy: {
    balochistan: { level: 5, threats: ["Sabotage", "Armed Attacks", "Pipeline Bombing", "Kidnapping"], pkg: "Maximum Infrastructure Protection", includes: ["Armed perimeter teams", "Pipeline patrol units", "Counter-sabotage operations", "Tribal liaison", "Emergency shutdown protocols"], personnel: "14\u201324", response: "< 10 min", monitoring: "24/7 Active" },
    kpk: { level: 4, threats: ["Sabotage", "Militant Threats", "Power Line Attacks", "Extortion"], pkg: "Enhanced Infrastructure Security", includes: ["Armed site security", "Patrol teams", "Threat intelligence", "Sabotage detection systems", "Emergency response"], personnel: "10\u201316", response: "< 12 min", monitoring: "24/7 Active" },
    sindh: { level: 3, threats: ["Theft", "Vandalism", "Civil Unrest", "Equipment Sabotage"], pkg: "Elevated Site Security", includes: ["24/7 guard teams", "Perimeter monitoring", "Equipment protection", "Community engagement"], personnel: "6\u201312", response: "< 20 min", monitoring: "24/7 Active" },
    punjab: { level: 2, threats: ["Theft", "Vandalism", "Labour Disputes", "Trespassing"], pkg: "Standard Site Security", includes: ["Guard deployment", "CCTV systems", "Access control", "Incident reporting"], personnel: "4\u20138", response: "< 25 min", monitoring: "Business hours + on-call" },
    islamabad: { level: 1, threats: ["Vandalism", "Trespassing", "Regulatory Compliance", "Theft"], pkg: "Basic Facility Security", includes: ["Access control", "CCTV monitoring", "Guard patrols", "Visitor management"], personnel: "3\u20135", response: "< 30 min", monitoring: "Business hours + on-call" },
    gb: { level: 4, threats: ["Terrain Hazards", "Sabotage", "Road Blockades", "Natural Disasters"], pkg: "Remote Energy Protocol", includes: ["Mountain security teams", "Pipeline/facility patrols", "Satellite communications", "Weather monitoring", "Helicopter medevac standby"], personnel: "10\u201316", response: "< 15 min", monitoring: "24/7 Active" }
  }
};

const opOptions: { key: OpType; icon: string; label: string }[] = [
  { key: 'mining', icon: '\u25C6', label: 'Mining & Extraction' },
  { key: 'construction', icon: '\u2699', label: 'Construction & Infrastructure' },
  { key: 'corporate', icon: '\u25A0', label: 'Corporate Office' },
  { key: 'vip', icon: '\u2605', label: 'VIP / Executive Visit' },
  { key: 'logistics', icon: '\u21C4', label: 'Logistics & Transport' },
  { key: 'energy', icon: '\u26A1', label: 'Energy & Utilities' }
];

const locOptions: { key: LocType; label: string }[] = [
  { key: 'balochistan', label: 'Balochistan' },
  { key: 'kpk', label: 'KPK & Tribal Areas' },
  { key: 'sindh', label: 'Sindh (Rural)' },
  { key: 'punjab', label: 'Punjab' },
  { key: 'islamabad', label: 'Islamabad / Rawalpindi' },
  { key: 'gb', label: 'Gilgit-Baltistan & AJK' }
];

export default function SecurityPage() {
  const [selOp, setSelOp] = useState<OpType | null>(null);
  const [selLoc, setSelLoc] = useState<LocType | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const assessment = selOp && selLoc ? data[selOp]?.[selLoc] : null;

  return (
    <>
      <Navbar />

      <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Security.jpg')" }}>
        <section className="v-hero">
          <div className="v-hero-text">
            <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
            <span className="gold-line hero-enter"></span>
            <div className="label hero-enter hero-enter-delay-1">Corporate &amp; Project Protection</div>
            <h1 className="serif hero-enter hero-enter-delay-2">Security <span className="gold">Services.</span></h1>
            <p className="hero-enter hero-enter-delay-3">Corporate and project protection for international operations across Pakistan &mdash; site security, executive protection, risk assessment, and monitoring through vetted, experienced security partners.</p>
            <a href="/contact?interest=Security%20Services#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Discuss Requirements &rarr;</a>
          </div>
        </section>
      </div>

      <div className="divider"></div>

      {/* SECURITY RISK ASSESSMENT TOOL */}
      <section className="sr-section fade-in">
        <h2 className="serif">Assess your <span className="gold">security needs.</span></h2>
        <p className="sr-subtitle">Select your operation type and location to receive a tailored security assessment and recommended protection package.</p>

        <div className="sr-row">
          <div className="sr-row-label">Operation Type</div>
          <div className="sr-cards" id="srOps">
            {opOptions.map(op => (
              <div
                key={op.key}
                className={`sr-card${selOp === op.key ? ' sr-selected' : ''}`}
                onClick={() => setSelOp(op.key)}
              >
                <span className="sr-card-icon">{op.icon}</span>
                <span className="sr-card-label">{op.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="sr-row">
          <div className="sr-row-label">Location</div>
          <div className="sr-cards" id="srLocs">
            {locOptions.map(loc => (
              <div
                key={loc.key}
                className={`sr-card${selLoc === loc.key ? ' sr-selected' : ''}`}
                onClick={() => setSelLoc(loc.key)}
              >
                <span className="sr-card-icon">&#9673;</span>
                <span className="sr-card-label">{loc.label}</span>
              </div>
            ))}
          </div>
        </div>

        {!assessment && (
          <div className="sr-placeholder">Select an operation type and location above to generate your assessment.</div>
        )}

        {assessment && (
          <div className="sr-result sr-visible">
            <div className="sr-result-left">
              <div className="sr-section-label">Threat Level</div>
              <div className="sr-threat-bar">
                {[1, 2, 3, 4, 5].map(lvl => (
                  <div
                    key={lvl}
                    className={`sr-threat-seg${lvl <= assessment.level ? ' sr-active' : ''}`}
                    data-level={lvl}
                  ></div>
                ))}
              </div>
              <div className="sr-threat-labels">
                {[
                  { lvl: 1, label: 'Very Low' },
                  { lvl: 2, label: 'Low' },
                  { lvl: 3, label: 'Medium' },
                  { lvl: 4, label: 'High' },
                  { lvl: 5, label: 'Very High' }
                ].map(item => (
                  <span
                    key={item.lvl}
                    className={`sr-threat-label-item${item.lvl === assessment.level ? ' sr-label-active' : ''}`}
                  >
                    {item.label}
                  </span>
                ))}
              </div>
              <div className="sr-section-label">Key Threats</div>
              <div className="sr-tags">
                {assessment.threats.map(t => (
                  <span key={t} className="sr-tag">{t}</span>
                ))}
              </div>
              <div className="sr-section-label">Recommended Package</div>
              <div className="sr-pkg-name">{assessment.pkg}</div>
              <ul className="sr-pkg-list">
                {assessment.includes.map(item => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className="sr-result-right">
              <div className="sr-metric">
                <div className="sr-metric-value">{assessment.personnel}</div>
                <div className="sr-metric-label">Personnel Required</div>
              </div>
              <div className="sr-metric">
                <div className="sr-metric-value">{assessment.response}</div>
                <div className="sr-metric-label">Response Time</div>
              </div>
              <div className="sr-metric">
                <div className="sr-metric-value">{assessment.monitoring}</div>
                <div className="sr-metric-label">Monitoring</div>
              </div>
              <a href="/contact" className="sr-cta">Request Detailed Assessment &rarr;</a>
            </div>
          </div>
        )}
      </section>

      <div className="divider"></div>

      {/* SERVICES */}
      <section className="section fade-in">
        <h2 className="serif">Our <span className="gold">services.</span></h2>
        <p className="subtitle">Comprehensive security solutions for corporate, industrial, and international clients operating in Pakistan.</p>

        <div className="detail-grid stagger">
          <div className="detail-card">
            <div className="card-icon">&#9632;</div>
            <h3>Site Security</h3>
            <p>24/7 security personnel for mining operations, construction sites, industrial facilities, and energy projects across Pakistan.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9733;</div>
            <h3>Executive Protection</h3>
            <p>Close protection services for visiting executives, delegation security, and VIP travel coordination throughout Pakistan.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9670;</div>
            <h3>Risk Assessment</h3>
            <p>Comprehensive security risk assessments for new market entrants, project locations, and operational environments.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#8644;</div>
            <h3>Transport Security</h3>
            <p>Secure logistics and convoy management for valuable cargo, equipment transport, and personnel movement in high-risk areas.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9881;</div>
            <h3>Security Consulting</h3>
            <p>Security strategy development, standard operating procedures, emergency response planning, and compliance with international security standards.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9992;</div>
            <h3>Monitoring &amp; Intelligence</h3>
            <p>24/7 operations centre monitoring, threat intelligence reporting, and real-time security updates for client operations.</p>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* STATS */}
      <section className="section section-center fade-in-scale">
        <div className="stats-row stagger">
          <div className="stat-item">
            <div className="number">24/7</div>
            <div className="label">Operations monitoring</div>
          </div>
          <div className="stat-item">
            <div className="number">Mining</div>
            <div className="label">Energy, infrastructure coverage</div>
          </div>
          <div className="stat-item">
            <div className="number">Vetted</div>
            <div className="label">Experienced security personnel</div>
          </div>
          <div className="stat-item">
            <div className="number">ISI/Int&apos;l</div>
            <div className="label">Standard compliance</div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* WHO WE SERVE */}
      <section className="section fade-in">
        <h2 className="serif">Who we <span className="gold">serve.</span></h2>
        <p className="subtitle">Tailored security solutions for the sectors and organisations that need them most.</p>

        <div className="relationships stagger">
          <div className="rel-card">
            <div className="rel-icon">&#9670;</div>
            <div>
              <h4>Mining &amp; Extraction</h4>
              <p>Security for exploration teams, mine sites, and mineral transport across Balochistan, KPK, and Gilgit-Baltistan.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9632;</div>
            <div>
              <h4>Infrastructure &amp; CPEC</h4>
              <p>Protection for construction projects, road building, and CPEC corridor development sites.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9881;</div>
            <div>
              <h4>Corporate Operations</h4>
              <p>Office security, employee safety programmes, and business continuity planning for international firms operating in Pakistan.</p>
            </div>
          </div>
          <div className="rel-card">
            <div className="rel-icon">&#9733;</div>
            <div>
              <h4>Diplomatic &amp; NGO</h4>
              <p>Security coordination for diplomatic missions, international organisations, and NGO operations requiring local security expertise.</p>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      <section className="cta-banner fade-in">
        <h2 className="serif">Protect your <span className="gold">operations.</span></h2>
        <p>Site security, executive protection, and risk assessment &mdash; deployed through vetted, experienced security partners.</p>
        <a href="/contact?interest=Security%20Services#contact-form" className="btn-gold">Discuss Requirements &rarr;</a>
      </section>

      <Footer />
    </>
  );
}