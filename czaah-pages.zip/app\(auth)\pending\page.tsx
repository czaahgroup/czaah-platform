'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function PendingPage() {
  const [status, setStatus] = useState<string>('pending_kyc_review')
  const [rejectionReason, setRejectionReason] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function checkStatus() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        router.push('/login')
        return
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('role, status, rejection_reason')
        .eq('id', user.id)
        .single()

      if (profile?.status === 'approved') {
        if (profile.role === 'super_admin') {
          router.push('/admin')
        } else {
          router.push('/dashboard')
        }
        return
      }

      setStatus(profile?.status || 'pending_kyc_review')
      setRejectionReason(profile?.rejection_reason || null)
      setLoading(false)
    }

    checkStatus()
  }, [router])

  async function handleSignOut() {
    const supabase = createClient()
    await supabase.auth.signOut()
    const form = document.createElement('form')
    form.method = 'POST'
    form.action = '/api/auth/signout'
    document.body.appendChild(form)
    form.submit()
  }

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000' }}>
        <div style={{ fontFamily: "'Raleway', sans-serif", fontSize: '14px', color: 'rgba(255,255,255,0.4)' }}>Loading...</div>
      </div>
    )
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px', background: '#000' }}>
      <div style={{ width: '100%', maxWidth: '460px', textAlign: 'center' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <Link href="/" style={{ textDecoration: 'none', display: 'inline-block' }}>
            <svg viewBox="-5 -12 100 80" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ height: '96px', width: 'auto', display: 'block', margin: '0 auto' }}>
              <defs>
                <linearGradient id="authHornGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8a6f2e"/>
                  <stop offset="40%" stopColor="#c9a84c"/>
                  <stop offset="60%" stopColor="#e8c97a"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
                <linearGradient id="authBodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#c9a84c"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
              </defs>
              <path d="M 38 38 C 34 30, 24 22, 20 12 C 17 4, 22 -2, 28 2 C 34 6, 36 16, 32 24 C 28 32, 22 34, 18 28 C 15 22, 18 14, 24 12" stroke="url(#authHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 35 36 C 30 28, 22 20, 22 12 C 22 7, 26 4, 29 6" stroke="url(#authHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 52 36 C 56 28, 66 20, 70 10 C 73 2, 68 -4, 62 0 C 56 4, 54 14, 58 22 C 62 30, 68 32, 72 26 C 75 20, 72 12, 66 10" stroke="url(#authHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 55 34 C 60 26, 68 18, 68 10 C 68 5, 64 2, 61 4" stroke="url(#authHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 34 38 C 32 42, 32 48, 36 52 L 38 58 C 40 64, 50 64, 52 58 L 54 52 C 58 48, 58 42, 56 38 C 54 34, 50 32, 45 32 C 40 32, 36 34, 34 38 Z" fill="url(#authBodyGrad)" opacity="0.9"/>
              <circle cx="41" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
              <circle cx="49" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
            </svg>
          </Link>
        </div>

        {/* Card */}
        <div style={{
          background: '#080808',
          border: '1px solid rgba(255,255,255,0.06)',
          borderRadius: '12px',
          padding: '48px 40px',
        }}>
          {status === 'pending_kyc_review' && (
            <>
              <div style={{
                width: '72px',
                height: '72px',
                borderRadius: '50%',
                border: '2px solid rgba(201,168,76,0.25)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 28px',
              }}>
                <svg style={{ width: '32px', height: '32px', color: '#C9A84C' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 style={{
                fontFamily: "'Cinzel', serif",
                fontSize: '20px',
                color: '#fff',
                marginBottom: '16px',
                letterSpacing: '1px',
              }}>Application Under Review</h2>
              <p style={{
                fontFamily: "'Raleway', sans-serif",
                fontSize: '14px',
                color: 'rgba(255,255,255,0.45)',
                lineHeight: 1.7,
              }}>
                Thank you for applying to become a CZAAH member. Our team is reviewing your application and supporting documents. You will be notified within 48 hours.
              </p>
            </>
          )}

          {status === 'rejected' && (
            <>
              <div style={{
                width: '72px',
                height: '72px',
                borderRadius: '50%',
                border: '2px solid rgba(220,38,38,0.25)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 28px',
              }}>
                <svg style={{ width: '32px', height: '32px', color: '#dc2626' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <h2 style={{
                fontFamily: "'Cinzel', serif",
                fontSize: '20px',
                color: '#fff',
                marginBottom: '16px',
                letterSpacing: '1px',
              }}>Application Not Approved</h2>
              {rejectionReason && (
                <div style={{
                  background: '#000',
                  border: '1px solid rgba(220,38,38,0.15)',
                  borderRadius: '8px',
                  padding: '16px',
                  marginBottom: '20px',
                }}>
                  <p style={{
                    fontFamily: "'Raleway', sans-serif",
                    fontSize: '13px',
                    color: 'rgba(255,255,255,0.5)',
                  }}>
                    <span style={{ color: '#dc2626', fontWeight: 600 }}>Reason: </span>
                    {rejectionReason}
                  </p>
                </div>
              )}
              <p style={{
                fontFamily: "'Raleway', sans-serif",
                fontSize: '14px',
                color: 'rgba(255,255,255,0.45)',
                lineHeight: 1.7,
                marginBottom: '28px',
              }}>
                Unfortunately, your application was not approved at this time. You may resubmit with updated information.
              </p>
              <button
                onClick={() => router.push('/register')}
                style={{
                  width: '100%',
                  background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                  color: '#000',
                  fontFamily: "'Raleway', sans-serif",
                  fontWeight: 600,
                  fontSize: '14px',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  padding: '14px',
                  borderRadius: '6px',
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'opacity 0.3s',
                }}
                onMouseEnter={e => e.currentTarget.style.opacity = '0.85'}
                onMouseLeave={e => e.currentTarget.style.opacity = '1'}
              >
                Resubmit Application
              </button>
            </>
          )}

          {status !== 'pending_kyc_review' && status !== 'rejected' && (
            <>
              <div style={{
                width: '72px',
                height: '72px',
                borderRadius: '50%',
                border: '2px solid rgba(201,168,76,0.25)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 28px',
              }}>
                <svg style={{ width: '32px', height: '32px', color: '#C9A84C' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 style={{
                fontFamily: "'Cinzel', serif",
                fontSize: '20px',
                color: '#fff',
                marginBottom: '16px',
                letterSpacing: '1px',
              }}>Account Pending</h2>
              <p style={{
                fontFamily: "'Raleway', sans-serif",
                fontSize: '14px',
                color: 'rgba(255,255,255,0.45)',
                lineHeight: 1.7,
              }}>
                Your account is not yet active. Please contact us at{' '}
                <a href="mailto:info@czaah.com" style={{ color: '#C9A84C', textDecoration: 'none' }}>info@czaah.com</a>{' '}
                for assistance.
              </p>
            </>
          )}
        </div>

        {/* Sign Out */}
        <button
          onClick={handleSignOut}
          style={{
            marginTop: '28px',
            background: 'none',
            border: 'none',
            fontFamily: "'Raleway', sans-serif",
            fontSize: '13px',
            color: 'rgba(201,168,76,0.5)',
            cursor: 'pointer',
            transition: 'color 0.3s',
          }}
          onMouseEnter={e => e.currentTarget.style.color = 'rgba(201,168,76,1)'}
          onMouseLeave={e => e.currentTarget.style.color = 'rgba(201,168,76,0.5)'}
        >
          Sign Out
        </button>
      </div>
    </div>
  )
}
