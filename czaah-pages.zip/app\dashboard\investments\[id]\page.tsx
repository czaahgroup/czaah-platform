'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter, useParams } from 'next/navigation'
import Link from 'next/link'

interface Profile {
  id: string
  full_name: string
  role: string
}

interface InvestmentImage {
  id: string
  image_url: string
  caption: string | null
  display_order: number
}

interface InvestmentDetail {
  id: string
  title: string
  sector_tag: string | null
  status: string
  min_investment_amount: number | null
  currency: string
  target_return: string | null
  investment_timeline: string | null
  description: string | null
  key_highlights: string[]
  location: string | null
  published_at: string | null
  created_at: string
  documents_count: number
  images: InvestmentImage[]
}

const STATUS_BADGES: Record<string, string> = {
  published: 'bg-green-500/20 text-green-400',
  closing_soon: 'bg-orange-500/20 text-orange-400',
}

function formatStatus(status: string) {
  return status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

function formatCurrency(amount: number | null, currency: string) {
  if (amount === null || amount === undefined) return '--'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export default function InvestmentDetailPage() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [investment, setInvestment] = useState<InvestmentDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [expressing, setExpressing] = useState(false)
  const [expressed, setExpressed] = useState(false)
  const router = useRouter()
  const params = useParams()
  const supabase = createClient()
  const id = params.id as string

  useEffect(() => {
    async function load() {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) { router.push('/login'); return }

        const { data: prof } = await supabase
          .from('profiles')
          .select('id, full_name, role')
          .eq('id', user.id)
          .single()

        if (!prof) { router.push('/login'); return }
        setProfile(prof)

        const res = await fetch(`/api/investments/${id}`)
        const json = await res.json()
        if (!res.ok) throw new Error(json.error || 'Failed to load investment')
        setInvestment(json.data)
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Something went wrong')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [id]) // eslint-disable-line react-hooks/exhaustive-deps

  async function handleExpressInterest() {
    if (!investment || !profile) return
    setExpressing(true)

    try {
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sectorId: null,
          productName: `Investment Interest: ${investment.title}`,
          description: `I am interested in the investment opportunity "${investment.title}". Please provide more details and next steps.`,
          estimatedQuantity: 'N/A',
          timeline: investment.investment_timeline || 'To be discussed',
        }),
      })

      if (!res.ok) {
        const json = await res.json()
        throw new Error(json.error || 'Failed to express interest')
      }

      setExpressed(true)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to express interest')
    } finally {
      setExpressing(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-czaah-muted">Loading...</div>
      </div>
    )
  }

  if (error && !investment) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <p className="text-red-400 mb-4">{error}</p>
          <Link href="/dashboard/investments" className="text-czaah-gold hover:text-czaah-gold/80 text-sm">
            Back to Investments
          </Link>
        </div>
      </div>
    )
  }

  if (!investment) return null

  return (
    <>
      {/* Back link */}
      <Link
        href="/dashboard/investments"
        className="text-sm text-czaah-muted hover:text-czaah-gold transition-colors mb-6 inline-block"
      >
        &larr; Back to Investments
      </Link>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 mb-6">
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-start justify-between gap-4 mb-3">
          <h1 className="font-[family-name:var(--font-heading)] text-3xl text-czaah-white leading-tight">
            {investment.title}
          </h1>
          <span className={`text-xs px-3 py-1 rounded shrink-0 ${STATUS_BADGES[investment.status] || ''}`}>
            {formatStatus(investment.status)}
          </span>
        </div>
        <div className="flex items-center gap-4 text-sm text-czaah-muted">
          {investment.sector_tag && (
            <span className="bg-czaah-gold/10 text-czaah-gold px-2.5 py-0.5 rounded text-xs">
              {investment.sector_tag}
            </span>
          )}
          {investment.location && (
            <span>{investment.location}</span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Description */}
          {investment.description && (
            <div className="bg-czaah-card border border-czaah-border rounded-lg p-6">
              <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white mb-3">Overview</h2>
              <p className="text-sm text-czaah-muted leading-relaxed whitespace-pre-wrap">
                {investment.description}
              </p>
            </div>
          )}

          {/* Key highlights */}
          {investment.key_highlights && investment.key_highlights.length > 0 && (
            <div className="bg-czaah-card border border-czaah-border rounded-lg p-6">
              <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white mb-3">Key Highlights</h2>
              <ul className="space-y-2">
                {investment.key_highlights.map((highlight, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-czaah-muted">
                    <span className="text-czaah-gold mt-0.5 shrink-0">&#9670;</span>
                    <span>{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Images */}
          {investment.images && investment.images.length > 0 && (
            <div className="bg-czaah-card border border-czaah-border rounded-lg p-6">
              <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white mb-3">Gallery</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {investment.images.map((img) => (
                  <div key={img.id} className="rounded-lg overflow-hidden border border-czaah-border/50">
                    <img
                      src={img.image_url}
                      alt={img.caption || investment.title}
                      className="w-full h-48 object-cover"
                    />
                    {img.caption && (
                      <p className="text-xs text-czaah-muted px-3 py-2">{img.caption}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar - Financials and CTA */}
        <div className="space-y-6">
          {/* Financial details */}
          <div className="bg-czaah-card border border-czaah-border rounded-lg p-6">
            <h2 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white mb-4">Investment Details</h2>
            <div className="space-y-4">
              <div>
                <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-1">Minimum Investment</p>
                <p className="text-xl font-[family-name:var(--font-heading)] text-czaah-white">
                  {formatCurrency(investment.min_investment_amount, investment.currency)}
                </p>
              </div>
              <div className="border-t border-czaah-border/50 pt-4">
                <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-1">Target Return</p>
                <p className="text-lg font-semibold text-czaah-gold">
                  {investment.target_return || '--'}
                </p>
              </div>
              {investment.investment_timeline && (
                <div className="border-t border-czaah-border/50 pt-4">
                  <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-1">Investment Timeline</p>
                  <p className="text-sm text-czaah-white">{investment.investment_timeline}</p>
                </div>
              )}
              {investment.currency && (
                <div className="border-t border-czaah-border/50 pt-4">
                  <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-1">Currency</p>
                  <p className="text-sm text-czaah-white">{investment.currency}</p>
                </div>
              )}
              {investment.documents_count > 0 && (
                <div className="border-t border-czaah-border/50 pt-4">
                  <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-1">Documents Available</p>
                  <p className="text-sm text-czaah-white">{investment.documents_count} document{investment.documents_count !== 1 ? 's' : ''}</p>
                </div>
              )}
            </div>
          </div>

          {/* Express Interest CTA */}
          <div className="bg-czaah-card border border-czaah-gold/20 rounded-lg p-6">
            {expressed ? (
              <div className="text-center">
                <div className="w-10 h-10 rounded-full bg-czaah-success/20 flex items-center justify-center mx-auto mb-3">
                  <span className="text-czaah-success text-lg">&#10003;</span>
                </div>
                <h3 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white mb-2">Interest Submitted</h3>
                <p className="text-sm text-czaah-muted mb-4">
                  Your enquiry has been created. Our team will be in touch shortly.
                </p>
                <Link
                  href="/dashboard/enquiries"
                  className="text-sm text-czaah-gold hover:text-czaah-gold/80 transition-colors"
                >
                  View My Enquiries &rarr;
                </Link>
              </div>
            ) : (
              <>
                <h3 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white mb-2">Interested?</h3>
                <p className="text-sm text-czaah-muted mb-4">
                  Express your interest and our team will reach out with further details and documentation.
                </p>
                <button
                  onClick={handleExpressInterest}
                  disabled={expressing}
                  className="w-full bg-czaah-gold text-czaah-black font-semibold px-5 py-3 rounded text-sm hover:bg-czaah-gold/90 transition-colors disabled:opacity-50"
                >
                  {expressing ? 'Submitting...' : 'Express Interest'}
                </button>
              </>
            )}
          </div>

          {/* Status warning */}
          {investment.status === 'closing_soon' && (
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-4">
              <p className="text-sm text-orange-400 font-medium mb-1">Closing Soon</p>
              <p className="text-xs text-orange-400/70">
                This investment opportunity is closing soon. Express your interest now to secure your place.
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
