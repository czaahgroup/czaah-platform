'use client';
// @ts-nocheck

import { useState, useEffect, useRef, useCallback } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface SectorData {
  name: string;
  thesis: string;
  drivers: string[];
  structures: string[];
  metrics: { marketSize: number; growth: number; competition: number; regulatory: number };
  investment: string;
  timeline: string;
  risk: string;
}

const sectorsList: SectorData[] = [
  {
    name: 'Minerals',
    thesis: 'Pakistan holds over $1 trillion in untapped mineral reserves across copper, gold, coal, rare earths, and gemstones. Balochistan, KPK, and Gilgit-Baltistan offer generational exploration opportunities. CPEC infrastructure is unlocking previously inaccessible deposits, creating a narrow window for early-mover advantage before institutional capital crowds the space.',
    drivers: ['CPEC infrastructure unlocking deposits', 'Rising global commodity prices', 'Provincial licensing reform', 'Chinese JV demand'],
    structures: ['Joint Venture', 'Exploration License', 'Streaming / Royalty'],
    metrics: { marketSize: 95, growth: 85, competition: 40, regulatory: 70 },
    investment: '$5M \u2013 $50M',
    timeline: '3 \u2013 7 years',
    risk: 'Medium-High'
  },
  {
    name: 'Real Estate',
    thesis: 'Urbanisation, diaspora remittances, and CPEC Special Economic Zones are driving sustained demand across commercial, residential, and industrial real estate. Gwadar, Islamabad, and Lahore present distinct risk-return profiles. The sector offers tangible collateral and proven capital appreciation in a market with limited institutional competition.',
    drivers: ['CPEC SEZ development', 'Diaspora investment demand', 'Rapid urbanisation', 'Limited institutional supply'],
    structures: ['Joint Venture', 'Greenfield Development', 'Acquisition'],
    metrics: { marketSize: 90, growth: 75, competition: 80, regulatory: 50 },
    investment: '$2M \u2013 $25M',
    timeline: '2 \u2013 5 years',
    risk: 'Medium'
  },
  {
    name: 'Textiles',
    thesis: "Pakistan is the world\u2019s fourth-largest textile exporter with a deeply fragmented supply chain. International buyers increasingly seek compliant, vertically integrated sourcing partners. Opportunities exist in value-added manufacturing, sustainable textiles, and export consolidation serving EU and Gulf markets.",
    drivers: ['EU GSP+ trade access', 'Sustainability compliance demand', 'Supply chain diversification from China', 'Low labour costs'],
    structures: ['Joint Venture', 'Contract Manufacturing', 'Acquisition'],
    metrics: { marketSize: 85, growth: 65, competition: 75, regulatory: 45 },
    investment: '$1M \u2013 $15M',
    timeline: '2 \u2013 4 years',
    risk: 'Medium'
  },
  {
    name: 'Technology',
    thesis: "Pakistan\u2019s IT exports exceed $2.6 billion annually, with a young, English-speaking developer workforce. Government digitisation programmes and the fintech revolution are creating domestic demand, while global staff augmentation and SaaS opportunities offer dollar-denominated revenue streams with minimal capital intensity.",
    drivers: ['Government digitisation push', 'Fintech regulatory reform', 'Young developer talent pool', 'Dollar-denominated exports'],
    structures: ['Equity Investment', 'Greenfield', 'Strategic Partnership'],
    metrics: { marketSize: 70, growth: 90, competition: 65, regulatory: 35 },
    investment: '$500K \u2013 $10M',
    timeline: '1 \u2013 3 years',
    risk: 'Low-Medium'
  },
  {
    name: 'Agriculture',
    thesis: "Agriculture contributes 23% of Pakistan\u2019s GDP and employs 37% of the labour force, yet remains underinvested in cold chain, processing, and modern farming techniques. Opportunities in agri-tech, food processing, organic exports, and water management offer high social impact alongside strong commercial returns.",
    drivers: ['Food security national priority', 'Agri-tech adoption gap', 'Export demand for organic produce', 'Cold chain infrastructure deficit'],
    structures: ['Joint Venture', 'Greenfield', 'Public-Private Partnership'],
    metrics: { marketSize: 88, growth: 70, competition: 55, regulatory: 45 },
    investment: '$1M \u2013 $20M',
    timeline: '2 \u2013 5 years',
    risk: 'Medium'
  },
  {
    name: 'Pharmaceuticals',
    thesis: "Pakistan\u2019s pharmaceutical market is valued at over $4 billion, growing at 12% annually. A 220-million-person domestic market, rising healthcare awareness, and export potential to Central Asia and Africa present compelling opportunities in generics manufacturing, API production, and biotech.",
    drivers: ['220M domestic population', 'Rising healthcare spend', 'Generics export potential', 'API localisation incentives'],
    structures: ['Acquisition', 'Joint Venture', 'Licensing'],
    metrics: { marketSize: 72, growth: 78, competition: 60, regulatory: 75 },
    investment: '$3M \u2013 $30M',
    timeline: '3 \u2013 6 years',
    risk: 'Medium-High'
  },
  {
    name: 'Aviation',
    thesis: "Pakistan\u2019s aviation sector is underserved relative to population and geography. Private charter, executive transport, and CPEC-related logistics represent immediate opportunities. Regulatory modernisation and tourism growth are expected to further expand demand for both commercial and private aviation services.",
    drivers: ['CPEC executive logistics demand', 'Underserved private charter market', 'Tourism sector growth', 'Medical evacuation gaps'],
    structures: ['Greenfield', 'Joint Venture', 'Operational Lease'],
    metrics: { marketSize: 45, growth: 60, competition: 30, regulatory: 80 },
    investment: '$5M \u2013 $40M',
    timeline: '2 \u2013 5 years',
    risk: 'High'
  },
  {
    name: 'Construction',
    thesis: 'Pakistan faces a housing deficit of over 10 million units and requires massive infrastructure investment across roads, bridges, dams, and industrial zones. CPEC Phase II, government housing schemes, and provincial development budgets are creating a sustained pipeline of large-scale construction opportunities.',
    drivers: ['10M+ housing deficit', 'CPEC Phase II infrastructure', 'Government housing schemes', 'Provincial development budgets'],
    structures: ['Joint Venture', 'EPC Contract', 'Public-Private Partnership'],
    metrics: { marketSize: 82, growth: 72, competition: 70, regulatory: 60 },
    investment: '$3M \u2013 $30M',
    timeline: '2 \u2013 5 years',
    risk: 'Medium'
  },
  {
    name: 'Tourism',
    thesis: "Pakistan\u2019s northern areas, cultural heritage sites, and religious tourism circuits represent a largely untapped hospitality market. International media coverage has shifted perception, and government visa liberalisation is accelerating inbound tourism. Hotel, resort, and adventure tourism infrastructure remain critically undersupplied.",
    drivers: ['Visa liberalisation policy', 'International media exposure', 'Religious tourism circuits', 'Adventure tourism demand'],
    structures: ['Greenfield', 'Joint Venture', 'Management Contract'],
    metrics: { marketSize: 50, growth: 82, competition: 25, regulatory: 40 },
    investment: '$2M \u2013 $20M',
    timeline: '3 \u2013 6 years',
    risk: 'Medium'
  }
];

export default function InvestmentAdvisoryPage() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFading, setIsFading] = useState(false);
  const [barHeights, setBarHeights] = useState({ marketSize: 0, growth: 0, competition: 0, regulatory: 0 });
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('visible');
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => {
      observerRef.current?.observe(el);
    });

    return () => observerRef.current?.disconnect();
  }, []);

  const selectSector = useCallback((idx: number) => {
    if (idx === currentIndex && barHeights.marketSize > 0) return;

    setBarHeights({ marketSize: 0, growth: 0, competition: 0, regulatory: 0 });
    setIsFading(true);

    setTimeout(() => {
      setCurrentIndex(idx);
      setIsFading(false);

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          const s = sectorsList[idx];
          setBarHeights({
            marketSize: s.metrics.marketSize,
            growth: s.metrics.growth,
            competition: s.metrics.competition,
            regulatory: s.metrics.regulatory
          });
        });
      });
    }, 300);
  }, [currentIndex, barHeights.marketSize]);

  // Initialize first sector
  useEffect(() => {
    const s = sectorsList[0];
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        setBarHeights({
          marketSize: s.metrics.marketSize,
          growth: s.metrics.growth,
          competition: s.metrics.competition,
          regulatory: s.metrics.regulatory
        });
      });
    });
  }, []);

  const sector = sectorsList[currentIndex];

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Investment-Advisory.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Strategy &amp; Analysis</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Investment<br /><span className="gold">Advisory.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Data-driven investment advisory for international capital entering Pakistan — feasibility studies, market analysis, financial modelling, opportunity identification, and strategic guidance across all sectors.</p>
              <a href="/contact?interest=Investment%20Advisory#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Get Advisory &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* SECTOR OPPORTUNITY MATRIX */}
        <style>{`
          .ia-section { padding: 80px 6vw; background: #111; }
          .ia-section h2 { font-family: 'Cinzel', serif; font-size: 2.4rem; color: #fff; margin-bottom: 12px; }
          .ia-subtitle { font-family: 'Raleway', sans-serif; color: rgba(255,255,255,0.55); font-size: 1.05rem; max-width: 640px; margin-bottom: 40px; line-height: 1.6; }
          .ia-pills { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 36px; }
          .ia-pill { font-family: 'Raleway', sans-serif; font-size: 0.85rem; font-weight: 500; padding: 10px 20px; border: 1px solid rgba(201,168,76,0.25); border-radius: 40px; background: transparent; color: rgba(255,255,255,0.6); cursor: pointer; transition: all 0.3s ease; letter-spacing: 0.02em; }
          .ia-pill:hover { border-color: #C9A84C; color: #fff; }
          .ia-pill.ia-active { background: #C9A84C; color: #000; border-color: #C9A84C; font-weight: 600; }
          .ia-card { display: flex; flex-wrap: wrap; gap: 40px; border: 1px solid rgba(201,168,76,0.15); border-radius: 16px; background: rgba(0,0,0,0.5); padding: 40px; opacity: 1; transition: opacity 0.4s ease; }
          .ia-card.ia-fading { opacity: 0; }
          .ia-left { flex: 0 0 60%; }
          .ia-right { flex: 0 0 calc(40% - 40px); display: flex; gap: 24px; justify-content: center; align-items: flex-end; padding-bottom: 20px; }
          .ia-sector-name { font-family: 'Cinzel', serif; font-size: 1.8rem; color: #C9A84C; margin-bottom: 16px; }
          .ia-thesis { font-family: 'Raleway', sans-serif; color: rgba(255,255,255,0.65); font-size: 0.95rem; line-height: 1.7; margin-bottom: 24px; }
          .ia-tag-group { margin-bottom: 20px; }
          .ia-tag-label { font-family: 'Raleway', sans-serif; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; color: rgba(255,255,255,0.35); margin-bottom: 8px; }
          .ia-tags { display: flex; flex-wrap: wrap; gap: 8px; }
          .ia-tag { font-family: 'Raleway', sans-serif; font-size: 0.78rem; padding: 5px 14px; border-radius: 20px; background: rgba(201,168,76,0.1); color: #C9A84C; border: 1px solid rgba(201,168,76,0.2); }
          .ia-metric { display: flex; flex-direction: column; align-items: center; gap: 10px; }
          .ia-bar-track { width: 8px; height: 180px; background: rgba(255,255,255,0.08); border-radius: 4px; position: relative; overflow: hidden; }
          .ia-bar-fill { position: absolute; bottom: 0; left: 0; width: 100%; background: linear-gradient(to top, #C9A84C, #e0c36a); border-radius: 4px; transition: height 0.6s cubic-bezier(0.4, 0, 0.2, 1); }
          .ia-bar-value { font-family: 'Raleway', sans-serif; font-size: 0.85rem; font-weight: 600; color: #C9A84C; }
          .ia-bar-label { font-family: 'Raleway', sans-serif; font-size: 0.68rem; color: rgba(255,255,255,0.4); text-align: center; max-width: 60px; line-height: 1.3; }
          .ia-bottom { display: flex; gap: 32px; margin-top: 28px; padding-top: 20px; border-top: 1px solid rgba(201,168,76,0.1); flex-wrap: wrap; }
          .ia-bottom-item { font-family: 'Raleway', sans-serif; }
          .ia-bottom-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em; color: rgba(255,255,255,0.35); margin-bottom: 4px; }
          .ia-bottom-value { font-size: 0.95rem; color: #fff; font-weight: 500; }
          @media (max-width: 768px) {
            .ia-card { flex-direction: column; padding: 28px 20px; }
            .ia-left, .ia-right { flex: 1 1 100%; }
            .ia-right { padding-bottom: 0; padding-top: 20px; border-top: 1px solid rgba(201,168,76,0.1); }
            .ia-bar-track { height: 120px; }
            .ia-section h2 { font-size: 1.8rem; }
          }
        `}</style>

        <section className="ia-section fade-in">
          <h2 className="serif">Sector opportunity <span className="gold">matrix.</span></h2>
          <p className="ia-subtitle">CZAAH&apos;s proprietary assessment of Pakistan&apos;s investment landscape — evaluating market depth, growth trajectory, competitive dynamics, and regulatory environment across nine priority sectors.</p>

          <div className="ia-pills">
            {sectorsList.map((s, i) => (
              <button
                key={s.name}
                className={`ia-pill${currentIndex === i ? ' ia-active' : ''}`}
                onClick={() => selectSector(i)}
              >
                {s.name}
              </button>
            ))}
          </div>

          <div className={`ia-card${isFading ? ' ia-fading' : ''}`}>
            <div className="ia-left">
              <div className="ia-sector-name">{sector.name}</div>
              <p className="ia-thesis">{sector.thesis}</p>
              <div className="ia-tag-group">
                <div className="ia-tag-label">Key Drivers</div>
                <div className="ia-tags">
                  {sector.drivers.map((d, i) => (
                    <span key={i} className="ia-tag">{d}</span>
                  ))}
                </div>
              </div>
              <div className="ia-tag-group">
                <div className="ia-tag-label">Recommended Entry Structures</div>
                <div className="ia-tags">
                  {sector.structures.map((st, i) => (
                    <span key={i} className="ia-tag">{st}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="ia-right">
              <div className="ia-metric">
                <div className="ia-bar-track"><div className="ia-bar-fill" style={{ height: `${barHeights.marketSize}%` }}></div></div>
                <div className="ia-bar-value">{sector.metrics.marketSize}</div>
                <div className="ia-bar-label">Market Size</div>
              </div>
              <div className="ia-metric">
                <div className="ia-bar-track"><div className="ia-bar-fill" style={{ height: `${barHeights.growth}%` }}></div></div>
                <div className="ia-bar-value">{sector.metrics.growth}</div>
                <div className="ia-bar-label">Growth Rate</div>
              </div>
              <div className="ia-metric">
                <div className="ia-bar-track"><div className="ia-bar-fill" style={{ height: `${barHeights.competition}%` }}></div></div>
                <div className="ia-bar-value">{sector.metrics.competition}</div>
                <div className="ia-bar-label">Competitive Intensity</div>
              </div>
              <div className="ia-metric">
                <div className="ia-bar-track"><div className="ia-bar-fill" style={{ height: `${barHeights.regulatory}%` }}></div></div>
                <div className="ia-bar-value">{sector.metrics.regulatory}</div>
                <div className="ia-bar-label">Regulatory Complexity</div>
              </div>
            </div>
            <div className="ia-bottom" style={{ flexBasis: '100%' }}>
              <div className="ia-bottom-item">
                <div className="ia-bottom-label">Minimum Investment</div>
                <div className="ia-bottom-value">{sector.investment}</div>
              </div>
              <div className="ia-bottom-item">
                <div className="ia-bottom-label">Typical Timeline</div>
                <div className="ia-bottom-value">{sector.timeline}</div>
              </div>
              <div className="ia-bottom-item">
                <div className="ia-bottom-label">Risk Profile</div>
                <div className="ia-bottom-value">{sector.risk}</div>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Institutional-grade advisory services — from initial opportunity identification through to ongoing strategic guidance.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>Feasibility Studies</h3>
              <p>Comprehensive market and financial feasibility for proposed investments. We assess viability, project costs, revenue potential, and regulatory requirements before you commit capital.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9881;</div>
              <h3>Market Analysis</h3>
              <p>Sector research, competitor mapping, demand forecasting, regulatory landscape. Our analysts provide the granular, on-the-ground intelligence that international databases cannot capture.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#36;</div>
              <h3>Financial Modelling</h3>
              <p>Revenue projections, IRR analysis, sensitivity testing, capital structuring. Rigorous financial models built with local cost data and realistic assumptions for the Pakistani market.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Opportunity Identification</h3>
              <p>Proactive deal sourcing across minerals, real estate, technology, textiles, pharmaceuticals, and agriculture. We surface opportunities that match your investment thesis and risk appetite.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9632;</div>
              <h3>Risk Assessment</h3>
              <p>Political, regulatory, currency, and operational risk evaluation with mitigation strategies. We quantify risks that other advisors treat as unknowns — because we operate inside the system.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#43;</div>
              <h3>Strategic Advisory</h3>
              <p>Board-level guidance on Pakistan market entry, expansion, and portfolio strategy. Whether you&apos;re making your first investment or scaling an existing position, we provide the strategic clarity you need.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">Advisory capability <span className="gold">at a glance.</span></h2>
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">9</div>
              <div className="label">Sectors covered</div>
            </div>
            <div className="stat-item">
              <div className="number">$300B+</div>
              <div className="label">Addressable market</div>
            </div>
            <div className="stat-item">
              <div className="number">13+</div>
              <div className="label">Sectors covered</div>
            </div>
            <div className="stat-item">
              <div className="number">Institutional</div>
              <div className="label">Advisory grade</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* WHY CZAAH */}
        <section className="section fade-in">
          <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
          <p className="subtitle">Our advisory is built on real operational experience across Pakistan&apos;s key sectors — not theoretical analysis from a distance.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>Cross-Sector Expertise</h4>
                <p>Advisory coverage spanning minerals, real estate, technology, textiles, pharmaceuticals, agriculture, aviation, government, and security. We understand how sectors interconnect and where the real opportunities lie.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>On-the-Ground Intelligence</h4>
                <p>Our teams operate from Islamabad with international reach, providing real-time market intelligence that international advisory firms simply cannot access. We know the players, the regulations, and the unwritten rules.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>Institutional Methodology</h4>
                <p>Our advisory process follows institutional standards — structured frameworks, auditable models, and documented assumptions. The quality of work you expect from a global advisory firm, with the depth of a local operator.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#8644;</div>
              <div>
                <h4>Network Advantage</h4>
                <p>Advisory backed by relationships across government, industry, and finance. When we assess an opportunity, we can validate assumptions directly with the stakeholders who matter — not rely on secondary sources.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Informed decisions in <span className="gold">complex markets.</span></h2>
          <p>Feasibility, financial modelling, and strategic guidance &mdash; grounded in real operational experience across Pakistan.</p>
          <a href="/contact?interest=Investment%20Advisory#contact-form" className="btn-gold">Request an Assessment &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
