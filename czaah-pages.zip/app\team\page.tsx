'use client'
// @ts-nocheck

import { useEffect } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

export default function TeamPage() {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: `
    .team-tier { margin-top: 48px; margin-bottom: 56px; }
    .team-tier:last-child { margin-bottom: 0; }
    .tier-label {
      font-family: 'Raleway', sans-serif;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: #C9A84C;
      margin-bottom: 28px;
      padding-bottom: 12px;
      border-bottom: 1px solid rgba(201,168,76,0.15);
    }
    .team-grid {
      display: grid;
      gap: 20px;
    }
    .team-grid.tier-founders { grid-template-columns: repeat(2, 1fr); max-width: 720px; margin: 0 auto; }
    .team-grid.tier-founders .team-avatar {
      width: 88px;
      height: 88px;
      font-size: 26px;
      border-color: rgba(201,168,76,0.4);
      background: rgba(201,168,76,0.14);
    }
    .team-grid.tier-1 { grid-template-columns: repeat(2, 1fr); max-width: 720px; margin: 0 auto; }
    .team-grid.tier-2 { grid-template-columns: repeat(3, 1fr); }
    .team-grid.tier-3 { grid-template-columns: repeat(4, 1fr); }
    .team-grid.tier-4 { grid-template-columns: repeat(4, 1fr); }

    .team-card {
      background: rgba(255,255,255,0.02);
      border: 1px solid rgba(201,168,76,0.1);
      padding: 28px 24px;
      text-align: center;
      transition: all 0.4s ease;
      position: relative;
    }
    .team-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 2px;
      background: linear-gradient(90deg, transparent, #C9A84C, transparent);
      opacity: 0;
      transition: opacity 0.4s ease;
    }
    .team-card:hover {
      background: rgba(201,168,76,0.04);
      border-color: rgba(201,168,76,0.25);
      transform: translateY(-3px);
    }
    .team-card:hover::before { opacity: 1; }

    .team-avatar {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      background: rgba(201,168,76,0.08);
      border: 1px solid rgba(201,168,76,0.2);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px;
      font-family: 'Cinzel', serif;
      font-size: 20px;
      color: #C9A84C;
      font-weight: 600;
      letter-spacing: 0.05em;
    }
    .tier-1 .team-avatar {
      width: 80px;
      height: 80px;
      font-size: 24px;
      border-color: rgba(201,168,76,0.35);
      background: rgba(201,168,76,0.12);
    }

    .team-name {
      font-family: 'Cinzel', serif;
      font-size: 17px;
      font-weight: 600;
      color: #fff;
      margin-bottom: 4px;
    }
    .team-title {
      font-family: 'Raleway', sans-serif;
      font-size: 12px;
      font-weight: 500;
      color: #C9A84C;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 10px;
    }
    .team-scope {
      font-family: 'Raleway', sans-serif;
      font-size: 12px;
      color: rgba(255,255,255,0.45);
      line-height: 1.5;
    }

    @media (max-width: 1024px) {
      .team-grid.tier-3, .team-grid.tier-4 { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 768px) {
      .team-grid.tier-founders { grid-template-columns: 1fr; }
      .team-grid.tier-1 { grid-template-columns: 1fr; }
      .team-grid.tier-2 { grid-template-columns: 1fr; }
      .team-grid.tier-3, .team-grid.tier-4 { grid-template-columns: 1fr; }
    }
      ` }} />
      <Navbar />
      <div className="page-wrap">

        {/* HERO */}
        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/About.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <Link href="/about" className="back-link hero-enter">&larr; Back to About</Link>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">CZAAH Group</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Our <span className="gold">Team.</span></h1>
              <p className="hero-enter hero-enter-delay-3">A senior team drawn from Pakistan, the Gulf, and the United Kingdom &mdash; combining institutional access with international discipline across thirteen sectors.</p>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* LEADERSHIP */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">leadership.</span></h2>
          <p className="subtitle">Sector specialists, regulatory navigators, and institutional operators &mdash; each role mapped directly to CZAAH&apos;s verticals.</p>

          {/* TIER 0 -- FOUNDERS */}
          <div className="team-tier stagger">
            <div className="tier-label">Founders</div>
            <div className="team-grid tier-founders">
              <div className="team-card">
                <div className="team-avatar">CZ</div>
                <div className="team-name">Chaudhry Zeeshan Ahmed</div>
                <div className="team-title">Co-Founder &amp; Chairman</div>
                <div className="team-scope">Entrepreneur and seasoned business leader with over 18 years of experience in real estate, international business development, and the mines and minerals sector. Strategic advisor to numerous successful companies with a key role in building international partnerships and business networks. Chairman of the Gwadar Chamber of Commerce Standing Committee for Overseas Pakistanis, actively strengthening Gwadar-related international business relations including CPEC and overseas investment initiatives.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">AH</div>
                <div className="team-name">Aqib Hussain</div>
                <div className="team-title">Co-Founder &amp; Vice Chairman</div>
                <div className="team-scope">Experienced entrepreneur with over 12 years of expertise across sales, business development, construction and development, renewable energy, gas and electricity, IT, and artificial intelligence. Extensive experience in UK government contracting with strong capabilities in financial markets and strategic investment opportunities. Known for building high-value partnerships and maintaining a strong professional network across Europe, driving innovation and delivering impactful business solutions across diverse sectors.</div>
              </div>
            </div>
          </div>

          {/* TIER 1 -- SENIOR EXECUTIVES */}
          <div className="team-tier stagger">
            <div className="tier-label">Senior Executives</div>
            <div className="team-grid tier-1">
              <div className="team-card">
                <div className="team-avatar">SA</div>
                <div className="team-name">Ch Shahzad Akhtar</div>
                <div className="team-title">Chief Executive Officer</div>
                <div className="team-scope">Over 25 years of experience in marketing, business development, sports consultancy, and media management. Founder of Kashmir Premier League, Sindh Premier League, Global Celebrity League, Global Affairs Magazine, and Ring of Pakistan. CEO of Pakistan&apos;s Overseas Real Estate Forum and Cutting Edge Group. Member of the 100 CEOs Club of Pakistan, with established relations with the United Nations.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">SK</div>
                <div className="team-name">Saqib Karamat</div>
                <div className="team-title">Executive Director</div>
                <div className="team-scope">Visionary entrepreneur and strategic leader with extensive experience in technology, investment, real estate, and global education sectors. Strong footprint across Europe, China, Hong Kong, and Korea. Built, scaled, and managed multi-sector ventures focused on innovation and cross-border collaboration. Portfolio includes AI-driven innovations, healthcare transformation, and educational mobility programmes empowering youth worldwide. CEO, Europe of Oryx Capital. CEO, Marks Group. COO, Shenzhen Xingyi Intelligent Technology Co., Ltd. COO, Olive Healthcare Europe. CEO, Inturnationally Limited.</div>
              </div>
            </div>
          </div>

          {/* TIER 2 -- C-SUITE */}
          <div className="team-tier stagger">
            <div className="tier-label">Executive Leadership</div>
            <div className="team-grid tier-2">
              <div className="team-card">
                <div className="team-avatar">KA</div>
                <div className="team-name">Khalid Al-Rashid</div>
                <div className="team-title">Chief Operating Officer</div>
                <div className="team-scope">Group operations, service delivery across all thirteen sectors. International operations and service delivery oversight.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">SF</div>
                <div className="team-name">Sarah Fairclough</div>
                <div className="team-title">Chief Financial Officer</div>
                <div className="team-scope">Corporate finance, investment structuring, SPV architecture. FCA-qualified, international reporting standards.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">UR</div>
                <div className="team-name">Usman Raza</div>
                <div className="team-title">Chief Legal Officer</div>
                <div className="team-scope">Legal strategy, regulatory compliance, contract governance. SECP and international regulatory liaison.</div>
              </div>
            </div>
          </div>

          {/* TIER 3 -- DIRECTORS */}
          <div className="team-tier stagger">
            <div className="tier-label">Sector Directors</div>
            <div className="team-grid tier-3">
              <div className="team-card">
                <div className="team-avatar">ZM</div>
                <div className="team-name">Zainab Malik</div>
                <div className="team-title">Director, Minerals &amp; Mining</div>
                <div className="team-scope">Provincial mining leases, exploration licensing, offtake agreements. Balochistan &amp; KPK coverage.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">JW</div>
                <div className="team-name">James Whitfield</div>
                <div className="team-title">Director, Technology &amp; IT</div>
                <div className="team-scope">Government IT integration, software development partnerships, EdTech initiatives. UK tech sector liaison.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">NA</div>
                <div className="team-name">Nadia Al-Sayed</div>
                <div className="team-title">Director, Real Estate &amp; Construction</div>
                <div className="team-scope">CPEC corridor development, commercial property, infrastructure projects. Gulf investor relations.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">IK</div>
                <div className="team-name">Imran Khawaja</div>
                <div className="team-title">Director, Textiles &amp; Agriculture</div>
                <div className="team-scope">Export trading, mill aggregation, organic certification, cold chain logistics. TDAP coordination.</div>
              </div>
            </div>
          </div>

          {/* TIER 4 -- HEADS */}
          <div className="team-tier stagger">
            <div className="tier-label">Division Heads</div>
            <div className="team-grid tier-4">
              <div className="team-card">
                <div className="team-avatar">OB</div>
                <div className="team-name">Omar Bukhari</div>
                <div className="team-title">Head of Aviation &amp; Logistics</div>
                <div className="team-scope">Charter operations, medical evacuation, VIP transport coordination. CAA regulatory compliance.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">RA</div>
                <div className="team-name">Rebecca Ashworth</div>
                <div className="team-title">Head of Investor Relations</div>
                <div className="team-scope">Investor protection, advisory services, portfolio reporting. Diaspora &amp; international investor interface.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">TA</div>
                <div className="team-name">Tariq Abbas</div>
                <div className="team-title">Head of Government Contracts</div>
                <div className="team-scope">PPRA procurement, tender preparation, NHA &amp; WAPDA contract management. Federal &amp; provincial liaison.</div>
              </div>
              <div className="team-card">
                <div className="team-avatar">FS</div>
                <div className="team-name">Fatima Al-Suwaidi</div>
                <div className="team-title">Head of Licensing &amp; Compliance</div>
                <div className="team-scope">FBR, BOI, SECP filings. Business setup, import/export documentation, regulatory approvals across all sectors.</div>
              </div>
            </div>
            <div className="team-grid tier-1" style={{ marginTop: 20 }}>
              <div className="team-card">
                <div className="team-avatar">HQ</div>
                <div className="team-name">Hassan Qureshi</div>
                <div className="team-title">Head of Pharmaceuticals &amp; Energy</div>
                <div className="team-scope">DRAP registration, GMP compliance, manufacturing partnerships. NEPRA &amp; energy sector coordination.</div>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* CTA */}
        <section className="cta-banner fade-in">
          <h2 className="serif">Work with <span className="gold">us.</span></h2>
          <p>Seventeen professionals across thirteen sectors &mdash; every vertical covered, every relationship maintained.</p>
          <Link href="/contact#contact-form" className="btn-gold">Get in Touch &rarr;</Link>
        </section>

        <Footer />
      </div>
    </>
  )
}
