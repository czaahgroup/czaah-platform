'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function ResetPasswordPage() {
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [ready, setReady] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Supabase will have set the session from the reset link
    const supabase = createClient()
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setReady(true)
      } else {
        // No session — might need to wait for the hash to be processed
        const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
          if (event === 'PASSWORD_RECOVERY') {
            setReady(true)
          }
        })
        // Give it a moment
        setTimeout(() => setReady(true), 1000)
        return () => subscription.unsubscribe()
      }
    })
  }, [])

  async function handleReset(e: React.FormEvent) {
    e.preventDefault()
    setError('')

    if (password.length < 8) {
      setError('Password must be at least 8 characters')
      return
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match')
      return
    }

    setLoading(true)
    const supabase = createClient()
    const { error } = await supabase.auth.updateUser({ password })

    if (error) {
      setError(error.message)
      setLoading(false)
      return
    }

    setSuccess(true)
    setTimeout(() => router.push('/dashboard'), 2000)
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 16px', background: '#000' }}>
      <div style={{ width: '100%', maxWidth: '28rem' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <Link href="/" style={{ textDecoration: 'none', display: 'inline-block' }}>
            <svg viewBox="-5 -12 100 80" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ height: '96px', width: 'auto', display: 'block', margin: '0 auto' }}>
              <defs>
                <linearGradient id="authHornGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8a6f2e"/>
                  <stop offset="40%" stopColor="#c9a84c"/>
                  <stop offset="60%" stopColor="#e8c97a"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
                <linearGradient id="authBodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#c9a84c"/>
                  <stop offset="100%" stopColor="#8a6f2e"/>
                </linearGradient>
              </defs>
              <path d="M 38 38 C 34 30, 24 22, 20 12 C 17 4, 22 -2, 28 2 C 34 6, 36 16, 32 24 C 28 32, 22 34, 18 28 C 15 22, 18 14, 24 12" stroke="url(#authHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 35 36 C 30 28, 22 20, 22 12 C 22 7, 26 4, 29 6" stroke="url(#authHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 52 36 C 56 28, 66 20, 70 10 C 73 2, 68 -4, 62 0 C 56 4, 54 14, 58 22 C 62 30, 68 32, 72 26 C 75 20, 72 12, 66 10" stroke="url(#authHornGrad)" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <path d="M 55 34 C 60 26, 68 18, 68 10 C 68 5, 64 2, 61 4" stroke="url(#authHornGrad)" strokeWidth="1.2" fill="none" strokeLinecap="round" opacity="0.6"/>
              <path d="M 34 38 C 32 42, 32 48, 36 52 L 38 58 C 40 64, 50 64, 52 58 L 54 52 C 58 48, 58 42, 56 38 C 54 34, 50 32, 45 32 C 40 32, 36 34, 34 38 Z" fill="url(#authBodyGrad)" opacity="0.9"/>
              <circle cx="41" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
              <circle cx="49" cy="44" r="1.5" fill="#e8c97a" opacity="0.9"/>
            </svg>
          </Link>
        </div>

        <div style={{
          background: '#080808',
          border: '1px solid rgba(255,255,255,0.06)',
          borderRadius: '12px',
          padding: '40px',
        }}>
          {success ? (
            <div style={{ textAlign: 'center' }}>
              <div style={{
                width: '64px', height: '64px', borderRadius: '50%',
                border: '2px solid rgba(201,168,76,0.25)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                margin: '0 auto 24px',
              }}>
                <svg style={{ width: '28px', height: '28px', color: '#C9A84C' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 style={{
                fontFamily: "'Cinzel', serif", fontSize: '20px',
                color: '#fff', marginBottom: '12px',
              }}>Password Updated</h2>
              <p style={{
                fontFamily: "'Raleway', sans-serif", fontSize: '14px',
                color: 'rgba(255,255,255,0.45)', lineHeight: 1.7,
              }}>
                Your password has been reset. Redirecting to your dashboard...
              </p>
            </div>
          ) : !ready ? (
            <div style={{ textAlign: 'center' }}>
              <p style={{
                fontFamily: "'Raleway', sans-serif", fontSize: '14px',
                color: 'rgba(255,255,255,0.4)',
              }}>Verifying reset link...</p>
            </div>
          ) : (
            <>
              <h2 style={{
                fontFamily: "'Cinzel', serif", fontSize: '20px',
                marginBottom: '8px', textAlign: 'center', color: '#fff',
              }}>Set New Password</h2>
              <p style={{
                fontFamily: "'Raleway', sans-serif", fontSize: '13px',
                color: 'rgba(255,255,255,0.4)', textAlign: 'center',
                marginBottom: '24px', lineHeight: 1.6,
              }}>Enter your new password below.</p>

              <form onSubmit={handleReset} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <label style={{
                    display: 'block', fontFamily: "'Raleway', sans-serif",
                    fontSize: '12px', letterSpacing: '0.05em',
                    color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase',
                    marginBottom: '6px',
                  }}>New Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    style={{
                      width: '100%', background: '#000',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '6px', padding: '12px 16px',
                      color: '#fff', fontFamily: "'Raleway', sans-serif",
                      fontSize: '14px', transition: 'border-color 0.3s',
                      outline: 'none', boxSizing: 'border-box',
                    }}
                    onFocus={e => e.target.style.borderColor = '#C9A84C'}
                    onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.08)'}
                    placeholder="Min. 8 characters"
                  />
                </div>

                <div>
                  <label style={{
                    display: 'block', fontFamily: "'Raleway', sans-serif",
                    fontSize: '12px', letterSpacing: '0.05em',
                    color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase',
                    marginBottom: '6px',
                  }}>Confirm Password</label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    style={{
                      width: '100%', background: '#000',
                      border: '1px solid rgba(255,255,255,0.08)',
                      borderRadius: '6px', padding: '12px 16px',
                      color: '#fff', fontFamily: "'Raleway', sans-serif",
                      fontSize: '14px', transition: 'border-color 0.3s',
                      outline: 'none', boxSizing: 'border-box',
                    }}
                    onFocus={e => e.target.style.borderColor = '#C9A84C'}
                    onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.08)'}
                    placeholder="Re-enter your password"
                  />
                </div>

                {error && (
                  <p style={{ color: '#ef4444', fontFamily: "'Raleway', sans-serif", fontSize: '12px', margin: 0 }}>{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                    color: '#000', fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600, fontSize: '14px', letterSpacing: '0.1em',
                    textTransform: 'uppercase', padding: '14px',
                    borderRadius: '6px', border: 'none',
                    cursor: loading ? 'not-allowed' : 'pointer',
                    width: '100%', transition: 'opacity 0.3s',
                    opacity: loading ? 0.5 : 1,
                  }}
                >
                  {loading ? 'Updating...' : 'Update Password'}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
