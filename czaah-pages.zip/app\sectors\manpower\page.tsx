'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';
import { WorkforceRegistrationModal } from '@/components/WorkforceRegistrationModal';

const talentPools = [
  { title: 'Civil Engineers', badge: 'high', badgeText: 'High Availability', teamSize: '5–50', timeline: '30–45 days', cert: 'Certified by PEC', industry: 'Construction,Mining', role: 'Engineers & Technical', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman,Pakistan' },
  { title: 'Welders & Fabricators', badge: 'high', badgeText: 'High Availability', teamSize: '10–200', timeline: '21–30 days', cert: 'AWS/ASME certified', industry: 'Construction,Oil & Gas,Manufacturing', role: 'Skilled Trades', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman' },
  { title: 'Heavy Equipment Operators', badge: 'high', badgeText: 'High Availability', teamSize: '5–100', timeline: '21–30 days', cert: 'CAT/Komatsu trained', industry: 'Construction,Mining', role: 'Drivers & Operators', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman,Pakistan' },
  { title: 'Registered Nurses', badge: 'medium', badgeText: 'Medium Availability', teamSize: '10–100', timeline: '45–60 days', cert: 'PNC registered, Prometric/Dataflow ready', industry: 'Healthcare', role: 'Medical & Nursing', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman' },
  { title: 'Software Developers', badge: 'high', badgeText: 'High Availability', teamSize: '3–50', timeline: '14–21 days', cert: 'Full-stack, mobile, cloud', industry: 'IT & Telecom', role: 'IT Professionals', dest: 'UAE,Saudi Arabia,Pakistan' },
  { title: 'Hotel & Restaurant Staff', badge: 'high', badgeText: 'High Availability', teamSize: '20–500', timeline: '30–45 days', cert: 'F&B, housekeeping, front desk', industry: 'Hospitality', role: 'Semi-Skilled Labour', dest: 'UAE,Saudi Arabia,Qatar,Oman' },
  { title: 'Electricians', badge: 'high', badgeText: 'High Availability', teamSize: '10–150', timeline: '21–30 days', cert: 'Licensed, HV/LV certified', industry: 'Construction,Manufacturing,Oil & Gas', role: 'Skilled Trades', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman,Pakistan' },
  { title: 'Project Managers', badge: 'medium', badgeText: 'Medium Availability', teamSize: '1–10', timeline: '30–45 days', cert: 'PMP, PRINCE2 holders', industry: 'Construction,Oil & Gas,IT & Telecom', role: 'Management & Supervisory', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman,Pakistan' },
  { title: 'Security Guards', badge: 'high', badgeText: 'High Availability', teamSize: '20–500', timeline: '21–30 days', cert: 'Ex-military, PSIRA eligible', industry: 'Security', role: 'Semi-Skilled Labour', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman,Pakistan' },
  { title: 'General Labour', badge: 'high', badgeText: 'High Availability', teamSize: '50–2000', timeline: '14–21 days', cert: 'Physically screened, medically cleared', industry: 'Construction,Manufacturing', role: 'Semi-Skilled Labour', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman' },
  { title: 'Doctors & Physicians', badge: 'limited', badgeText: 'Limited Availability', teamSize: '1–20', timeline: '60–90 days', cert: 'PMDC registered, SCFHS/DHA eligible', industry: 'Healthcare', role: 'Medical & Nursing', dest: 'Saudi Arabia,UAE,Qatar' },
  { title: 'HVAC Technicians', badge: 'medium', badgeText: 'Medium Availability', teamSize: '5–50', timeline: '21–30 days', cert: 'Refrigeration & AC certified', industry: 'Construction,Manufacturing', role: 'Skilled Trades', dest: 'Saudi Arabia,UAE,Qatar,Kuwait,Bahrain,Oman,Pakistan' },
];

const deploymentSteps = [
  { num: '1', title: 'Demand Letter', brief: 'Your official workforce requirement is registered and approved.', details: ['Employer issues demand letter with job descriptions, quantities, and terms.', 'CZAAH reviews for completeness and market alignment.', 'Document attested by Pakistani Embassy/Consulate in destination country.', 'OEP license verification and MOFA clearance obtained.'] },
  { num: '2', title: 'Candidate Sourcing', brief: 'We activate our nationwide recruitment network.', details: ['Job postings across 4 provinces via partner agencies and digital platforms.', 'Database matching for pre-vetted candidates.', 'Initial screening for education, experience, and language.', 'Shortlisting based on employer criteria — typically 3:1 ratio.'] },
  { num: '3', title: 'Trade Testing', brief: 'Skills verified to international standards.', details: ['Trade-specific testing at accredited centres (STEVTA, NAVTTC partners).', 'Welding, electrical, mechanical, and construction skills tested per destination country standards.', 'Computer-based testing for IT and professional roles.', 'Results documented with certificates and video evidence.'] },
  { num: '4', title: 'Medical Clearance', brief: 'Full health screening at GAMCA-approved centres.', details: ['Medical examination at GCC Approved Medical Centres Association (GAMCA) facilities.', 'Blood tests, chest X-ray, physical examination.', 'Drug screening and fitness-for-work assessment.', 'Medical reports valid for 3 months — CZAAH manages timing to align with visa processing.'] },
  { num: '5', title: 'Visa & Documentation', brief: 'All paperwork handled, end to end.', details: ['Work visa application and processing.', 'Employment contract review and attestation.', 'Passport verification and travel document preparation.', 'Pre-departure orientation on destination country laws, culture, and worker rights.', 'Travel booking and departure logistics.'] },
  { num: '6', title: 'Deployment & Support', brief: 'Your workforce arrives ready to perform.', details: ['Airport reception and transfer coordination at destination.', 'Post-arrival welfare check within 72 hours.', 'Employer onboarding support.', 'Ongoing grievance mechanism and worker welfare monitoring.', 'Contract renewal and rotation management.'] },
];

export default function ManpowerPage() {
  const [filters, setFilters] = useState<{ industry: Set<string>; role: Set<string>; dest: Set<string> }>({ industry: new Set(), role: new Set(), dest: new Set() });
  const [expandedSteps, setExpandedSteps] = useState<Set<number>>(new Set());
  const [showRegistration, setShowRegistration] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => { entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add('visible'); }); },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach((el) => { observerRef.current?.observe(el); });
    return () => observerRef.current?.disconnect();
  }, []);

  function toggleFilter(type: 'industry' | 'role' | 'dest', value: string) {
    setFilters(prev => {
      const newSet = new Set(prev[type]);
      if (newSet.has(value)) newSet.delete(value); else newSet.add(value);
      return { ...prev, [type]: newSet };
    });
  }

  function isCardVisible(pool: typeof talentPools[0]) {
    const hasAny = filters.industry.size || filters.role.size || filters.dest.size;
    if (!hasAny) return true;
    const cIndustry = pool.industry.split(',');
    const cRole = pool.role.split(',');
    const cDest = pool.dest.split(',');
    if (filters.industry.size && !cIndustry.some(v => filters.industry.has(v))) return false;
    if (filters.role.size && !cRole.some(v => filters.role.has(v))) return false;
    if (filters.dest.size && !cDest.some(v => filters.dest.has(v))) return false;
    return true;
  }

  const visibleCount = talentPools.filter(isCardVisible).length;

  function toggleStep(idx: number) {
    setExpandedSteps(prev => {
      const newSet = new Set(prev);
      if (newSet.has(idx)) newSet.delete(idx); else newSet.add(idx);
      return newSet;
    });
  }

  const industries = ['Construction', 'Oil & Gas', 'Healthcare', 'Hospitality', 'IT & Telecom', 'Manufacturing', 'Security', 'Mining'];
  const roles = ['Engineers & Technical', 'Skilled Trades', 'Semi-Skilled Labour', 'Management & Supervisory', 'Medical & Nursing', 'IT Professionals', 'Drivers & Operators', 'Administrative'];
  const destinations = ['Saudi Arabia', 'UAE', 'Qatar', 'Kuwait', 'Bahrain', 'Oman', 'Malaysia', 'Pakistan'];

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Manpower.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Workforce Solutions</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Human Resources &amp;<br /><span className="gold">Manpower.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Access to Pakistan&apos;s 70 million-strong workforce &mdash; overseas deployment, domestic staffing, executive search, and trade testing, managed to international labour standards.</p>
              <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', alignItems: 'center' }} className="hero-enter hero-enter-delay-4">
                <a href="/contact?interest=Human%20Resources#contact-form" className="btn-gold">Discuss Workforce Needs &rarr;</a>
                <button
                  onClick={() => setShowRegistration(true)}
                  style={{
                    background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                    color: '#000',
                    fontFamily: "'Raleway', sans-serif",
                    fontWeight: 600,
                    fontSize: '14px',
                    letterSpacing: '0.05em',
                    padding: '14px 32px',
                    borderRadius: '4px',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                >
                  Register as a Worker &rarr;
                </button>
              </div>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* WORKFORCE CONFIGURATOR */}
        <style>{`
          .hr-configurator { max-width: 1100px; margin: 0 auto; }
          .hr-filter-group { margin-bottom: 28px; }
          .hr-filter-label { font-size: 11px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--gold); font-weight: 600; margin-bottom: 12px; font-family: 'Raleway', sans-serif; }
          .hr-pills { display: flex; flex-wrap: wrap; gap: 8px; }
          .hr-pill { padding: 8px 18px; border-radius: 999px; border: 1px solid var(--black-border); background: var(--black-card); color: var(--white-muted); font-size: 13px; font-family: 'Raleway', sans-serif; font-weight: 400; cursor: pointer; transition: all 0.25s var(--ease-smooth); user-select: none; }
          .hr-pill:hover { border-color: var(--gold-dim); color: var(--white); }
          .hr-pill.active { border-color: var(--gold); color: var(--gold); background: rgba(201,168,76,0.08); font-weight: 500; }
          .hr-count { font-size: 14px; color: var(--white-dim); margin-bottom: 20px; font-family: 'Raleway', sans-serif; }
          .hr-count span { color: var(--gold); font-weight: 600; }
          .hr-results { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
          @media (max-width: 900px) { .hr-results { grid-template-columns: repeat(2, 1fr); } }
          @media (max-width: 600px) { .hr-results { grid-template-columns: 1fr; } }
          .hr-card { background: var(--black-card); border: 1px solid var(--black-border); border-radius: 10px; padding: 24px; transition: opacity 0.35s var(--ease-smooth), transform 0.35s var(--ease-smooth); }
          .hr-card.hr-hidden { display: none; }
          .hr-card-title { font-family: 'Cinzel', serif; font-size: 18px; color: var(--white); margin-bottom: 10px; font-weight: 600; }
          .hr-badge { display: inline-block; font-size: 11px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; padding: 3px 10px; border-radius: 999px; margin-bottom: 14px; font-family: 'Raleway', sans-serif; }
          .hr-badge-high { background: rgba(34,197,94,0.12); color: #22c55e; }
          .hr-badge-medium { background: rgba(201,168,76,0.12); color: var(--gold); }
          .hr-badge-limited { background: rgba(239,68,68,0.10); color: #f87171; }
          .hr-card-meta { font-size: 13px; color: var(--white-dim); line-height: 1.7; font-family: 'Raleway', sans-serif; }
          .hr-card-meta strong { color: var(--white-muted); font-weight: 500; }
          .hr-card-cert { font-size: 12px; color: var(--gold-dim); margin-top: 10px; font-style: italic; }
          .hr-card-link { display: inline-block; margin-top: 16px; font-size: 13px; color: var(--gold); font-weight: 500; text-decoration: none; font-family: 'Raleway', sans-serif; transition: color 0.2s; }
          .hr-card-link:hover { color: var(--gold-light); }
          .hr-process { max-width: 760px; margin: 0 auto; position: relative; padding-left: 56px; }
          .hr-process::before { content: ''; position: absolute; left: 21px; top: 22px; bottom: 22px; width: 2px; background: linear-gradient(180deg, var(--gold) 0%, rgba(201,168,76,0.25) 100%); }
          .hr-step { position: relative; margin-bottom: 32px; cursor: pointer; }
          .hr-step:last-child { margin-bottom: 0; }
          .hr-step-node { position: absolute; left: -56px; top: 0; width: 44px; height: 44px; border-radius: 50%; border: 2px solid var(--gold); background: var(--black-card); display: flex; align-items: center; justify-content: center; font-family: 'Raleway', sans-serif; font-weight: 600; font-size: 16px; color: var(--gold); transition: background 0.3s var(--ease-smooth), color 0.3s var(--ease-smooth); z-index: 1; }
          .hr-step.expanded .hr-step-node { background: var(--gold); color: #000; }
          .hr-step-header { display: flex; align-items: center; gap: 12px; }
          .hr-step-title { font-family: 'Cinzel', serif; font-size: 20px; color: var(--white); font-weight: 600; transition: color 0.2s; }
          .hr-step:hover .hr-step-title { color: var(--gold); }
          .hr-step-toggle { font-size: 18px; color: var(--gold-dim); transition: transform 0.3s var(--ease-smooth); margin-left: auto; flex-shrink: 0; }
          .hr-step.expanded .hr-step-toggle { transform: rotate(180deg); }
          .hr-step-brief { font-size: 14px; color: var(--white-dim); margin-top: 6px; font-family: 'Raleway', sans-serif; line-height: 1.6; }
          .hr-step-detail { max-height: 0; overflow: hidden; transition: max-height 0.45s var(--ease-smooth), opacity 0.35s var(--ease-smooth); opacity: 0; margin-top: 0; border-left: 2px solid var(--gold-dim); padding-left: 16px; margin-left: 4px; }
          .hr-step.expanded .hr-step-detail { max-height: 400px; opacity: 1; margin-top: 14px; }
          .hr-step-detail ul { list-style: none; padding: 0; margin: 0; }
          .hr-step-detail li { font-size: 13px; color: var(--white-muted); line-height: 1.7; padding: 4px 0; font-family: 'Raleway', sans-serif; position: relative; padding-left: 16px; }
          .hr-step-detail li::before { content: '\u2014'; position: absolute; left: 0; color: var(--gold-dim); }
          @media (max-width: 600px) { .hr-process { padding-left: 48px; } .hr-step-node { left: -48px; width: 36px; height: 36px; font-size: 14px; } .hr-process::before { left: 17px; } .hr-step-title { font-size: 17px; } }
        `}</style>

        <section className="section fade-in">
          <h2 className="serif">Workforce <span className="gold">Configurator.</span></h2>
          <p className="subtitle">Select your requirements to explore matching talent pools from our recruitment network.</p>

          <div className="hr-configurator">
            <div className="hr-filter-group">
              <div className="hr-filter-label">Industry</div>
              <div className="hr-pills">
                {industries.map(v => (<div key={v} className={`hr-pill${filters.industry.has(v) ? ' active' : ''}`} onClick={() => toggleFilter('industry', v)}>{v}</div>))}
              </div>
            </div>
            <div className="hr-filter-group">
              <div className="hr-filter-label">Role Category</div>
              <div className="hr-pills">
                {roles.map(v => (<div key={v} className={`hr-pill${filters.role.has(v) ? ' active' : ''}`} onClick={() => toggleFilter('role', v)}>{v}</div>))}
              </div>
            </div>
            <div className="hr-filter-group">
              <div className="hr-filter-label">Deployment Destination</div>
              <div className="hr-pills">
                {destinations.map(v => (<div key={v} className={`hr-pill${filters.dest.has(v) ? ' active' : ''}`} onClick={() => toggleFilter('dest', v)}>{v === 'Pakistan' ? 'Pakistan (Domestic)' : v}</div>))}
              </div>
            </div>

            <div className="hr-count">Showing <span>{visibleCount}</span> of {talentPools.length} talent pools</div>

            <div className="hr-results">
              {talentPools.map((pool, i) => (
                <div key={i} className={`hr-card${!isCardVisible(pool) ? ' hr-hidden' : ''}`}>
                  <div className="hr-card-title">{pool.title}</div>
                  <div className={`hr-badge hr-badge-${pool.badge}`}>{pool.badgeText}</div>
                  <div className="hr-card-meta">
                    <strong>Team Size:</strong> {pool.teamSize}<br />
                    <strong>Timeline:</strong> {pool.timeline}
                  </div>
                  <div className="hr-card-cert">{pool.cert}</div>
                  <a href="/contact" className="hr-card-link">Request Workforce &rarr;</a>
                </div>
              ))}
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* DEPLOYMENT PROCESS */}
        <section className="section fade-in">
          <h2 className="serif">Deployment <span className="gold">Process.</span></h2>
          <p className="subtitle">From demand letter to deployed workforce — every step managed, every detail handled.</p>

          <div className="hr-process">
            {deploymentSteps.map((step, i) => (
              <div key={i} className={`hr-step${expandedSteps.has(i) ? ' expanded' : ''}`} onClick={() => toggleStep(i)}>
                <div className="hr-step-node">{step.num}</div>
                <div className="hr-step-header">
                  <div className="hr-step-title">{step.title}</div>
                  <div className="hr-step-toggle">&#9660;</div>
                </div>
                <div className="hr-step-brief">{step.brief}</div>
                <div className="hr-step-detail">
                  <ul>
                    {step.details.map((d, j) => (<li key={j}>{d}</li>))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="divider"></div>

        {/* TWO PILLARS */}
        <section className="section fade-in-left">
          <div className="split">
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Overseas Deployment</div>
              <h3 className="serif">Talent for the <span className="gold">Gulf &amp; beyond.</span></h3>
              <p>Pakistan is one of the world&apos;s largest exporters of manpower, with millions deployed across the Gulf, Middle East, and beyond. CZAAH operates as a licensed overseas employment promoter, providing end-to-end recruitment for construction, oil &amp; gas, hospitality, healthcare, and industrial sectors.</p>
              <p>We handle demand letter processing, trade testing, medical clearance, visa coordination, and pre-departure orientation — ensuring compliant, deployment-ready candidates on your timeline.</p>
              <p>Our network spans across Punjab, KPK, Sindh, and Balochistan, giving us access to diverse talent pools that match the specific requirements of Gulf, European, and Asian employers.</p>
            </div>
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Domestic Staffing</div>
              <h3 className="serif">Build teams <span className="gold">in Pakistan.</span></h3>
              <p>For companies establishing operations in Pakistan — whether in mining, construction, IT, or manufacturing — CZAAH provides executive search, mid-level recruitment, and bulk hiring services.</p>
              <p>We recruit engineers, project managers, skilled tradespeople, security personnel, administrative staff, and operational teams tailored to project requirements and timelines.</p>
              <p>Our HR advisory extends to workforce planning, compensation benchmarking, labour law compliance, and employee retention strategies for the Pakistani market.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Comprehensive manpower and human resources solutions for domestic and international clients.</p>
          <div className="detail-grid stagger">
            <div className="detail-card"><div className="card-icon">&#9823;</div><h3>Overseas Recruitment</h3><p>Licensed recruitment for Gulf, Middle East, and international markets. End-to-end processing from candidate sourcing through visa coordination to deployment, compliant with OEP regulations.</p></div>
            <div className="detail-card"><div className="card-icon">&#9670;</div><h3>Executive Search</h3><p>C-suite and senior management recruitment for companies entering or operating in Pakistan. Confidential headhunting with deep networks across finance, engineering, technology, and operations.</p></div>
            <div className="detail-card"><div className="card-icon">&#9632;</div><h3>Bulk Hiring &amp; Mobilisation</h3><p>Large-scale workforce mobilisation for construction, mining, and infrastructure projects. Hundreds or thousands of skilled and semi-skilled workers recruited, tested, and deployed on schedule.</p></div>
            <div className="detail-card"><div className="card-icon">&#9733;</div><h3>Trade Testing &amp; Certification</h3><p>Comprehensive skills assessment and trade testing through accredited centres. Welders, electricians, heavy equipment operators, and technicians verified to international standards.</p></div>
            <div className="detail-card"><div className="card-icon">&#43;</div><h3>HR Advisory &amp; Compliance</h3><p>Labour law compliance, compensation structuring, employee contracts, and workforce planning tailored to Pakistan&apos;s regulatory environment. EOBI, social security, and tax compliance managed end-to-end.</p></div>
            <div className="detail-card"><div className="card-icon">&#8644;</div><h3>Temporary &amp; Contract Staffing</h3><p>Flexible staffing solutions for project-based requirements. Payroll management, insurance, and administrative overhead handled by CZAAH — you focus on operations.</p></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SECTORS WE SERVE */}
        <section className="section fade-in">
          <h2 className="serif">Industries we <span className="gold">serve.</span></h2>
          <p className="subtitle">Our recruitment expertise spans every major employment sector.</p>
          <div className="relationships stagger">
            <div className="rel-card"><div className="rel-icon">&#9632;</div><div><h4>Construction &amp; Infrastructure</h4><p>Civil engineers, quantity surveyors, site supervisors, heavy machinery operators, steel fixers, carpenters, and general labour for megaprojects across the Gulf and Pakistan.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9670;</div><div><h4>Oil, Gas &amp; Energy</h4><p>Drilling crews, pipeline technicians, refinery operators, HSE officers, and field engineers for upstream, midstream, and downstream energy operations.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9733;</div><div><h4>Healthcare &amp; Nursing</h4><p>Doctors, registered nurses, pharmacists, lab technicians, and paramedical staff deployed to Gulf hospitals, clinics, and healthcare facilities with credential verification.</p></div></div>
            <div className="rel-card"><div className="rel-icon">&#9881;</div><div><h4>Technology &amp; IT</h4><p>Software developers, network engineers, data analysts, cybersecurity professionals, and IT support staff for both local and international tech companies and government IT projects.</p></div></div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <div className="stats-row stagger">
            <div className="stat-item"><div className="number">70M+</div><div className="label">Labour force</div></div>
            <div className="stat-item"><div className="number">Gulf+</div><div className="label">Deployment reach</div></div>
            <div className="stat-item"><div className="number">OEP</div><div className="label">Licensed operations</div></div>
            <div className="stat-item"><div className="number">Multi</div><div className="label">Sector coverage</div></div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">The talent your project <span className="gold">demands.</span></h2>
          <p>From skilled trades to senior executives &mdash; vetted, deployed, and managed to international standards.</p>
          <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center' }}>
            <a href="/contact?interest=Human%20Resources#contact-form" className="btn-gold">Discuss Workforce Needs &rarr;</a>
            <button
              onClick={() => setShowRegistration(true)}
              style={{
                background: 'linear-gradient(135deg, #8a6f2e 0%, #c9a84c 50%, #8a6f2e 100%)',
                color: '#000',
                fontFamily: "'Raleway', sans-serif",
                fontWeight: 600,
                fontSize: '14px',
                letterSpacing: '0.05em',
                padding: '14px 32px',
                borderRadius: '4px',
                border: 'none',
                cursor: 'pointer',
              }}
            >
              Register as a Worker &rarr;
            </button>
          </div>
        </section>

      </div>

      <WorkforceRegistrationModal open={showRegistration} onClose={() => setShowRegistration(false)} />

      <Footer />
    </>
  );
}
