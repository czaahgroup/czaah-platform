'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

export default function AviationPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [showSuccess, setShowSuccess] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('visible');
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );
    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach((el) => {
      observerRef.current?.observe(el);
    });
    return () => observerRef.current?.disconnect();
  }, []);

  useEffect(() => {
    const dateInput = document.getElementById('chartDate') as HTMLInputElement;
    const returnInput = document.getElementById('chartReturn') as HTMLInputElement;
    if (dateInput && returnInput) {
      const today = new Date().toISOString().split('T')[0];
      dateInput.setAttribute('min', today);
      returnInput.setAttribute('min', today);
    }
  }, []);

  function highlightEmpty(step: number) {
    if (step === 1) {
      ['chartDeparture','chartDestination','chartDate','chartPax','chartTrip'].forEach(id => {
        const el = document.getElementById(id) as HTMLInputElement | HTMLSelectElement;
        if (el && !el.value) {
          el.style.borderColor = '#c9544c';
          setTimeout(() => { el.style.borderColor = ''; }, 2000);
        }
      });
    }
    if (step === 2) {
      const opts = document.querySelector('.charter-options') as HTMLElement;
      if (opts) {
        opts.style.outline = '1px solid #c9544c';
        opts.style.borderRadius = '8px';
        setTimeout(() => { opts.style.outline = ''; }, 2000);
      }
    }
  }

  function charterNext(step: number) {
    if (step === 1) {
      const dep = (document.getElementById('chartDeparture') as HTMLSelectElement)?.value;
      const dest = (document.getElementById('chartDestination') as HTMLSelectElement)?.value;
      const date = (document.getElementById('chartDate') as HTMLInputElement)?.value;
      const pax = (document.getElementById('chartPax') as HTMLSelectElement)?.value;
      const trip = (document.getElementById('chartTrip') as HTMLSelectElement)?.value;
      if (!dep || !dest || !date || !pax || !trip) { highlightEmpty(step); return; }
    }
    if (step === 2) {
      const service = document.querySelector('input[name="serviceType"]:checked') as HTMLInputElement;
      if (!service) { highlightEmpty(step); return; }
      buildSummary();
    }
    setCurrentStep(step + 1);
  }

  function charterBack(step: number) {
    setCurrentStep(step - 1);
  }

  function buildSummary() {
    const dep = document.getElementById('chartDeparture') as HTMLSelectElement;
    const dest = document.getElementById('chartDestination') as HTMLSelectElement;
    const date = (document.getElementById('chartDate') as HTMLInputElement)?.value;
    const ret = (document.getElementById('chartReturn') as HTMLInputElement)?.value;
    const pax = (document.getElementById('chartPax') as HTMLSelectElement)?.value;
    const trip = document.getElementById('chartTrip') as HTMLSelectElement;
    const service = document.querySelector('input[name="serviceType"]:checked') as HTMLInputElement;
    const extras = Array.from(document.querySelectorAll('.charter-check input:checked')).map((c) => (c as HTMLInputElement).value);
    const notes = (document.getElementById('chartNotes') as HTMLTextAreaElement)?.value;

    let html = '<strong>Route:</strong> ' + dep?.options[dep.selectedIndex]?.text + ' &rarr; ' + dest?.options[dest.selectedIndex]?.text;
    html += ' &nbsp;|&nbsp; <strong>Date:</strong> ' + date;
    if (ret) html += ' &rarr; ' + ret;
    html += '<br><strong>Passengers:</strong> ' + pax;
    html += ' &nbsp;|&nbsp; <strong>Trip:</strong> ' + trip?.options[trip.selectedIndex]?.text;
    html += ' &nbsp;|&nbsp; <strong>Service:</strong> ' + (service?.value || '').replace(/-/g, ' ');
    if (extras.length) html += '<br><strong>Extras:</strong> ' + extras.map(e => e.replace(/-/g, ' ')).join(', ');
    if (notes) html += '<br><strong>Notes:</strong> ' + notes;

    const summaryEl = document.getElementById('charterSummary');
    if (summaryEl) summaryEl.innerHTML = html;
  }

  function submitCharter() {
    const name = (document.getElementById('chartName') as HTMLInputElement)?.value;
    const email = (document.getElementById('chartEmail') as HTMLInputElement)?.value;
    const phone = (document.getElementById('chartPhone') as HTMLInputElement)?.value;
    if (!name || !email || !phone) {
      ['chartName','chartEmail','chartPhone'].forEach(id => {
        const el = document.getElementById(id) as HTMLInputElement;
        if (el && !el.value) {
          el.style.borderColor = '#c9544c';
          setTimeout(() => { el.style.borderColor = ''; }, 2000);
        }
      });
      return;
    }
    setShowSuccess(true);
  }

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Aviation.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Private Aviation Services</div>
              <h1 className="serif hero-enter hero-enter-delay-2"><span className="gold">Aviation.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Premium private charter, executive transport, and aviation logistics across Pakistan and the Gulf. Flexible scheduling, discreet service, and access to locations beyond commercial airline reach.</p>
              <a href="/contact?interest=Aviation#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Request a Charter &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* CHARTER SEARCH ENGINE */}
        <section className="section fade-in" id="charter-search">
          <h2 className="serif">Find your <span className="gold">flight.</span></h2>
          <p className="subtitle">Search available routes and request a personalised charter quote. Our team responds within 24 hours.</p>

          <style>{`
            .charter-engine { background: var(--black-card); border: 1px solid var(--black-border); border-radius: 12px; padding: 40px; margin-top: 40px; max-width: 900px; margin-left: auto; margin-right: auto; }
            .charter-steps { display: flex; gap: 4px; margin-bottom: 36px; border-bottom: 1px solid var(--black-border); padding-bottom: 20px; }
            .charter-step { flex: 1; text-align: center; font-size: 13px; font-weight: 500; letter-spacing: 0.03em; color: var(--white-muted); padding: 10px 0; position: relative; transition: color 0.3s; }
            .charter-step.active { color: var(--gold); }
            .charter-step.completed { color: var(--white-dim); }
            .charter-step::after { content: ''; position: absolute; bottom: -21px; left: 20%; right: 20%; height: 2px; background: transparent; transition: background 0.3s; }
            .charter-step.active::after { background: var(--gold); }
            .charter-step.completed::after { background: var(--white-muted); }
            .step-num { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; border: 1px solid var(--white-muted); font-size: 11px; margin-right: 6px; transition: all 0.3s; }
            .charter-step.active .step-num { border-color: var(--gold); background: var(--gold); color: var(--black); }
            .charter-step.completed .step-num { border-color: var(--white-muted); background: var(--white-muted); color: var(--black); }
            .charter-panel { display: none; }
            .charter-panel.active { display: block; animation: charterFadeIn 0.4s ease; }
            @keyframes charterFadeIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
            .charter-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 28px; }
            .charter-field.full-width { grid-column: 1 / -1; }
            .charter-field label { display: block; font-size: 12px; font-weight: 500; letter-spacing: 0.08em; text-transform: uppercase; color: var(--white-dim); margin-bottom: 8px; }
            .charter-field select, .charter-field input, .charter-field textarea { width: 100%; padding: 12px 16px; background: var(--black-elevated); border: 1px solid var(--black-border); border-radius: 8px; color: var(--white); font-family: 'Raleway', sans-serif; font-size: 14px; transition: border-color 0.3s; outline: none; }
            .charter-field select:focus, .charter-field input:focus, .charter-field textarea:focus { border-color: var(--gold); }
            .charter-field select option { background: var(--black-card); color: var(--white); }
            .charter-field textarea { resize: vertical; min-height: 80px; }
            .charter-options { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
            .charter-option { display: flex; align-items: center; gap: 10px; padding: 14px 16px; background: var(--black-elevated); border: 1px solid var(--black-border); border-radius: 8px; cursor: pointer; font-size: 13px; color: var(--white-dim); transition: all 0.3s; }
            .charter-option:hover { border-color: var(--gold-dim); color: var(--white); }
            .charter-option input:checked + span { color: var(--gold); }
            .charter-option:has(input:checked) { border-color: var(--gold); background: rgba(201, 168, 76, 0.06); }
            .charter-option input { display: none; }
            .charter-checks { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
            .charter-check { display: flex; align-items: center; gap: 10px; padding: 10px 14px; background: var(--black-elevated); border: 1px solid var(--black-border); border-radius: 8px; cursor: pointer; font-size: 13px; color: var(--white-dim); transition: all 0.3s; }
            .charter-check:hover { border-color: var(--gold-dim); color: var(--white); }
            .charter-check:has(input:checked) { border-color: var(--gold); color: var(--gold); }
            .charter-check input { accent-color: var(--gold); }
            .charter-btns { display: flex; gap: 12px; justify-content: space-between; }
            .btn-outline { padding: 14px 28px; background: transparent; border: 1px solid var(--black-border); color: var(--white-dim); font-family: 'Raleway', sans-serif; font-size: 13px; font-weight: 500; letter-spacing: 0.06em; border-radius: 6px; cursor: pointer; transition: all 0.3s; }
            .btn-outline:hover { border-color: var(--white-muted); color: var(--white); }
            .charter-next, .charter-submit { margin-left: auto; }
            .charter-summary { background: var(--black-elevated); border: 1px solid var(--black-border); border-radius: 8px; padding: 20px 24px; margin-bottom: 28px; font-size: 13px; line-height: 1.8; color: var(--white-dim); }
            .charter-summary strong { color: var(--gold); font-weight: 500; }
            .charter-success { display: none; text-align: center; padding: 40px 20px; }
            .charter-success.show { display: block; animation: charterFadeIn 0.5s ease; }
            .charter-success-icon { width: 56px; height: 56px; border-radius: 50%; background: var(--gold); color: var(--black); display: inline-flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 700; margin-bottom: 20px; }
            .charter-success h3 { margin-bottom: 12px; }
            .charter-success p { max-width: 480px; margin: 0 auto; color: var(--white-dim); }
            @media (max-width: 768px) { .charter-engine { padding: 24px 20px; } .charter-form-grid { grid-template-columns: 1fr; } .charter-options { grid-template-columns: 1fr 1fr; } .charter-checks { grid-template-columns: 1fr; } .charter-steps { gap: 0; } .charter-step { font-size: 11px; } .step-num { width: 18px; height: 18px; font-size: 10px; margin-right: 4px; } .charter-btns { flex-direction: column-reverse; } .charter-next, .charter-submit { margin-left: 0; width: 100%; text-align: center; } .btn-outline { width: 100%; text-align: center; } }
          `}</style>

          <div className="charter-engine">
            <div className="charter-steps">
              <div className={`charter-step${currentStep === 1 ? ' active' : currentStep > 1 ? ' completed' : ''}`}><span className="step-num">1</span> Flight Details</div>
              <div className={`charter-step${currentStep === 2 ? ' active' : currentStep > 2 ? ' completed' : ''}`}><span className="step-num">2</span> Service Options</div>
              <div className={`charter-step${currentStep === 3 ? ' active' : ''}`}><span className="step-num">3</span> Request Quote</div>
            </div>

            {/* Step 1 */}
            <div className={`charter-panel${currentStep === 1 ? ' active' : ''}`}>
              <div className="charter-form-grid">
                <div className="charter-field">
                  <label>Departure</label>
                  <select id="chartDeparture">
                    <option value="">Select departure city</option>
                    <option value="ISB">Islamabad (ISB)</option>
                    <option value="LHE">Lahore (LHE)</option>
                    <option value="KHI">Karachi (KHI)</option>
                    <option value="PEW">Peshawar (PEW)</option>
                    <option value="UET">Quetta (UET)</option>
                    <option value="GIL">Gilgit (GIL)</option>
                    <option value="SKT">Sialkot (SKT)</option>
                    <option value="DXB">Dubai (DXB)</option>
                    <option value="AUH">Abu Dhabi (AUH)</option>
                    <option value="JED">Jeddah (JED)</option>
                    <option value="DOH">Doha (DOH)</option>
                    <option value="OTHER">Other (specify in notes)</option>
                  </select>
                </div>
                <div className="charter-field">
                  <label>Destination</label>
                  <select id="chartDestination">
                    <option value="">Select destination</option>
                    <option value="ISB">Islamabad (ISB)</option>
                    <option value="LHE">Lahore (LHE)</option>
                    <option value="KHI">Karachi (KHI)</option>
                    <option value="PEW">Peshawar (PEW)</option>
                    <option value="UET">Quetta (UET)</option>
                    <option value="GIL">Gilgit (GIL)</option>
                    <option value="SKT">Sialkot (SKT)</option>
                    <option value="GWD">Gwadar (GWD)</option>
                    <option value="TUK">Turbat (TUK)</option>
                    <option value="DXB">Dubai (DXB)</option>
                    <option value="AUH">Abu Dhabi (AUH)</option>
                    <option value="JED">Jeddah (JED)</option>
                    <option value="DOH">Doha (DOH)</option>
                    <option value="REMOTE">Remote Site (specify in notes)</option>
                    <option value="OTHER">Other (specify in notes)</option>
                  </select>
                </div>
                <div className="charter-field">
                  <label>Departure Date</label>
                  <input type="date" id="chartDate" />
                </div>
                <div className="charter-field">
                  <label>Return Date <span style={{ color: 'var(--white-muted)', fontWeight: 300 }}>(optional)</span></label>
                  <input type="date" id="chartReturn" />
                </div>
                <div className="charter-field">
                  <label>Passengers</label>
                  <select id="chartPax">
                    <option value="">Select</option>
                    <option value="1-2">1–2</option>
                    <option value="3-5">3–5</option>
                    <option value="6-8">6–8</option>
                    <option value="9-12">9–12</option>
                    <option value="13+">13+</option>
                  </select>
                </div>
                <div className="charter-field">
                  <label>Trip Type</label>
                  <select id="chartTrip">
                    <option value="">Select</option>
                    <option value="one-way">One Way</option>
                    <option value="return">Return</option>
                    <option value="multi-leg">Multi-Leg</option>
                  </select>
                </div>
              </div>
              <button className="btn-gold charter-next" onClick={() => charterNext(1)}>Continue to Service Options &rarr;</button>
            </div>

            {/* Step 2 */}
            <div className={`charter-panel${currentStep === 2 ? ' active' : ''}`}>
              <div className="charter-form-grid">
                <div className="charter-field full-width">
                  <label>Service Type</label>
                  <div className="charter-options">
                    <label className="charter-option"><input type="radio" name="serviceType" value="private-charter" /> <span>&#9992; Private Charter</span></label>
                    <label className="charter-option"><input type="radio" name="serviceType" value="executive-transport" /> <span>&#9670; Executive Transport</span></label>
                    <label className="charter-option"><input type="radio" name="serviceType" value="site-access" /> <span>&#9632; Site Access Flight</span></label>
                    <label className="charter-option"><input type="radio" name="serviceType" value="vip-delegation" /> <span>&#9733; VIP Delegation</span></label>
                    <label className="charter-option"><input type="radio" name="serviceType" value="medevac" /> <span>&#43; Medical Evacuation</span></label>
                    <label className="charter-option"><input type="radio" name="serviceType" value="event" /> <span>&#8644; Event Transport</span></label>
                  </div>
                </div>
                <div className="charter-field full-width">
                  <label>Additional Requirements</label>
                  <div className="charter-checks">
                    <label className="charter-check"><input type="checkbox" value="ground-transport" /> Ground transport at destination</label>
                    <label className="charter-check"><input type="checkbox" value="armoured" /> Armoured vehicle transfer</label>
                    <label className="charter-check"><input type="checkbox" value="security" /> Security escort</label>
                    <label className="charter-check"><input type="checkbox" value="catering" /> In-flight catering</label>
                    <label className="charter-check"><input type="checkbox" value="wifi" /> In-flight Wi-Fi</label>
                    <label className="charter-check"><input type="checkbox" value="overnight" /> Overnight accommodation</label>
                  </div>
                </div>
                <div className="charter-field full-width">
                  <label>Notes <span style={{ color: 'var(--white-muted)', fontWeight: 300 }}>(optional)</span></label>
                  <textarea id="chartNotes" rows={3} placeholder="Special requirements, remote site coordinates, multi-leg itinerary details..."></textarea>
                </div>
              </div>
              <div className="charter-btns">
                <button className="btn-outline charter-back" onClick={() => charterBack(2)}>&larr; Back</button>
                <button className="btn-gold charter-next" onClick={() => charterNext(2)}>Continue to Quote Request &rarr;</button>
              </div>
            </div>

            {/* Step 3 */}
            <div className={`charter-panel${currentStep === 3 ? ' active' : ''}`}>
              {!showSuccess && (
                <>
                  <div className="charter-summary" id="charterSummary"></div>
                  <div className="charter-form-grid">
                    <div className="charter-field">
                      <label>Full Name *</label>
                      <input type="text" id="chartName" placeholder="Your full name" />
                    </div>
                    <div className="charter-field">
                      <label>Email *</label>
                      <input type="email" id="chartEmail" placeholder="you@company.com" />
                    </div>
                    <div className="charter-field">
                      <label>Phone *</label>
                      <input type="tel" id="chartPhone" placeholder="+92 300 0000000" />
                    </div>
                    <div className="charter-field">
                      <label>Company <span style={{ color: 'var(--white-muted)', fontWeight: 300 }}>(optional)</span></label>
                      <input type="text" id="chartCompany" placeholder="Company name" />
                    </div>
                  </div>
                  <div className="charter-btns">
                    <button className="btn-outline charter-back" onClick={() => charterBack(3)}>&larr; Back</button>
                    <button className="btn-gold charter-submit" onClick={submitCharter}>Request a Quote &rarr;</button>
                  </div>
                </>
              )}
              <div className={`charter-success${showSuccess ? ' show' : ''}`}>
                <div className="charter-success-icon">&#10003;</div>
                <h3 className="serif">Quote request <span className="gold">submitted.</span></h3>
                <p>Thank you. Our aviation team will review your requirements and get back to you within 24 hours with a personalised quote.</p>
                <p style={{ color: 'var(--white-muted)', fontSize: '13px', marginTop: '12px' }}>For urgent requests, call <span className="gold">+92 51 000 0000</span></p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* TWO PILLARS */}
        <section className="section fade-in-left">
          <div className="split">
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Private Charter</div>
              <h3 className="serif">Fly on <span className="gold">your schedule.</span></h3>
              <p>Executive charter services between Pakistan&apos;s major cities — Islamabad, Lahore, Karachi — and Gulf destinations. No commercial airline constraints, no fixed timetables.</p>
              <p>Whether it&apos;s a same-day business trip, a multi-city itinerary, or a last-minute departure, our fleet and operations team deliver seamless private air travel tailored to your requirements.</p>
              <p>Discreet, comfortable, and efficient — designed for executives and organisations who value their time above all else.</p>
            </div>
            <div>
              <div className="label" style={{ fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '16px', fontWeight: 500 }}>Remote Access</div>
              <h3 className="serif">Reach places others <span className="gold">can&apos;t.</span></h3>
              <p>Many of Pakistan&apos;s most significant mining sites, infrastructure projects, and development zones are located in areas with no commercial air service — Balochistan, Gilgit-Baltistan, and remote KPK.</p>
              <p>We provide reliable air access to these locations for site inspections, project oversight, investor visits, and executive travel — safely and on your timeline.</p>
              <p>Purpose-built for the mining, infrastructure, and energy sectors where time-critical site access directly impacts project success.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Comprehensive private aviation solutions for corporate, industrial, and diplomatic clients.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9992;</div>
              <h3>Private Charter</h3>
              <p>On-demand private flights between Pakistani cities and Gulf destinations. Flexible scheduling, premium cabins, and dedicated flight crews for your comfort and privacy.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>Executive Transport</h3>
              <p>Scheduled executive shuttle services for corporations with regular inter-city travel needs. Membership programmes with guaranteed availability and priority booking.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9632;</div>
              <h3>Site Access Flights</h3>
              <p>Reliable air access to remote mining, energy, and infrastructure project sites across Balochistan, KPK, and Gilgit-Baltistan — locations beyond commercial airline reach.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>VIP Delegation Logistics</h3>
              <p>End-to-end air logistics for visiting delegations — international executives, diplomatic missions, and investor groups touring multiple sites across Pakistan.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#43;</div>
              <h3>Medical Evacuation</h3>
              <p>Emergency medical evacuation services for mining operations, construction sites, and remote industrial facilities. 24/7 dispatch capability with medical crew coordination.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8644;</div>
              <h3>Event Transport</h3>
              <p>Charter services for conferences, corporate retreats, and high-profile events. Multi-aircraft coordination for large groups with seamless ground-air-ground logistics.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* SAFETY & COMPLIANCE */}
        <section className="section fade-in">
          <h2 className="serif">Safety &amp; <span className="gold">compliance.</span></h2>
          <p className="subtitle">Every flight meets the highest safety and regulatory standards.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>CAA Certified</h4>
                <p>All operations are conducted under Pakistan Civil Aviation Authority licensing with full regulatory compliance, regular audits, and maintained safety documentation.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>Air Operator Certificate</h4>
                <p>AOC-certified commercial charter operations demonstrating adherence to international safety standards, crew qualifications, and comprehensive insurance coverage.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9881;</div>
              <div>
                <h4>Maintained Fleet</h4>
                <p>Aircraft maintained to manufacturer specifications with independent third-party inspections. Full maintenance records and airworthiness certification on every flight.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>Experienced Crews</h4>
                <p>Highly experienced pilots with thousands of hours on Pakistani and Gulf routes, including mountainous terrain and remote airstrip operations.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">24/7</div>
              <div className="label">Charter dispatch availability</div>
            </div>
            <div className="stat-item">
              <div className="number">PK+Gulf</div>
              <div className="label">Route coverage</div>
            </div>
            <div className="stat-item">
              <div className="number">VIP</div>
              <div className="label">Delegation logistics</div>
            </div>
            <div className="stat-item">
              <div className="number">AOC</div>
              <div className="label">Certified operations</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Travel on <span className="gold">your terms.</span></h2>
          <p>Private charter, executive transport, and site access logistics across Pakistan and the Gulf.</p>
          <a href="/contact?interest=Aviation#contact-form" className="btn-gold">Request a Charter &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
