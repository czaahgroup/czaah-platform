import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

export default function TermsPage() {
  return (
    <>
      <Navbar />

      <main className="legal-page fade-in">
        <h1>Terms &amp; Conditions</h1>
        <span className="legal-date">Last updated: March 2026</span>

        <h2>1. Acceptance of Terms</h2>
        <p>By accessing or using the website and services of CZAAH Capital &amp; Ventures (Private) Limited (&quot;CZAAH&quot;), together with its affiliated entities (collectively referred to as &quot;CZAAH&quot;, &quot;we&quot;, &quot;us&quot;, or &quot;our&quot;), you agree to be bound by these Terms &amp; Conditions (&quot;Terms&quot;). If you do not agree to these Terms, you must not access or use our website or services.</p>
        <p>These Terms constitute a legally binding agreement between you and the applicable CZAAH entity with which you engage. We reserve the right to modify these Terms at any time, and your continued use of our services constitutes acceptance of any such modifications.</p>

        <h2>2. About CZAAH</h2>
        <p>CZAAH is a diversified investment facilitation and advisory group operating through its principal entity:</p>
        <ul>
          <li><strong>CZAAH Capital &amp; Ventures (Private) Limited</strong> &mdash; a private limited company registered with the Securities and Exchange Commission of Pakistan (SECP), with its principal office in Islamabad, Pakistan.</li>
        </ul>
        <p>CZAAH provides investment facilitation, advisory, and consulting services across multiple sectors including minerals and mining, government infrastructure, technology, textiles, aviation, and real estate.</p>

        <h2>3. Services Description</h2>
        <p>CZAAH offers a range of professional services, including but not limited to:</p>
        <ul>
          <li>Investment facilitation and structuring across Pakistani and international markets</li>
          <li>Business setup and entity formation advisory (SECP and related jurisdictions)</li>
          <li>Licensing, compliance, and regulatory navigation</li>
          <li>Due diligence and investor protection services</li>
          <li>Import and export facilitation</li>
          <li>Partnership development and government liaison</li>
          <li>Sector-specific advisory across minerals, infrastructure, technology, textiles, aviation, and real estate</li>
        </ul>
        <p>The specific scope, terms, and fees of any engagement will be set out in a separate service agreement or letter of engagement between CZAAH and the client.</p>

        <h2>4. Investment Disclaimers</h2>
        <p><strong>This section is of particular importance. Please read it carefully.</strong></p>
        <p>CZAAH acts as an investment facilitator and advisor. We do not operate as a bank, broker-dealer, or regulated financial institution, and we do not accept deposits or hold client funds unless expressly agreed under a separate written arrangement.</p>
        <ul>
          <li><strong>No Guarantee of Returns:</strong> CZAAH does not guarantee any investment returns. All investments carry inherent risk, including the potential loss of the entire principal amount invested. Past performance of any investment, sector, or market is not indicative of future results.</li>
          <li><strong>Investment Risk:</strong> The value of investments and the income derived from them can go down as well as up. Emerging market investments, including those in Pakistan, carry additional risks including but not limited to currency fluctuation, political instability, regulatory changes, and liquidity constraints.</li>
          <li><strong>Independent Advice:</strong> CZAAH strongly recommends that all clients seek independent legal, financial, and tax advice before making any investment decision. The information and materials provided by CZAAH do not constitute a solicitation, offer, or recommendation to buy or sell any investment product.</li>
          <li><strong>Forward-Looking Statements:</strong> Any projections, forecasts, estimates, or forward-looking statements provided by CZAAH are based on assumptions and available information at the time of preparation. Actual results may differ materially from those projected.</li>
          <li><strong>Regulatory Status:</strong> CZAAH is not licensed as a securities broker, investment bank, or asset management company. Our services are limited to facilitation, advisory, and consulting as described in our engagement agreements.</li>
        </ul>

        <h2>5. Intellectual Property</h2>
        <p>All content on this website, including but not limited to text, graphics, logos, images, brand marks, data compilations, and software, is the property of CZAAH or its licensors and is protected by applicable intellectual property laws in Pakistan, the United Arab Emirates, and internationally.</p>
        <p>The CZAAH name, logo, and all related marks are trademarks of CZAAH. You may not use, reproduce, modify, distribute, or display any of our intellectual property without prior written consent from CZAAH.</p>
        <p>Limited permission is granted to view and download materials from this website for personal, non-commercial informational purposes only, provided that you retain all copyright and proprietary notices contained in the original materials.</p>

        <h2>6. Limitation of Liability</h2>
        <p>To the maximum extent permitted by applicable law:</p>
        <ul>
          <li>CZAAH, its directors, officers, employees, agents, and affiliates shall not be liable for any direct, indirect, incidental, special, consequential, or punitive damages arising out of or in connection with your use of our website or services.</li>
          <li>CZAAH makes no warranties or representations, express or implied, regarding the accuracy, completeness, reliability, or suitability of any information provided on this website or through our services.</li>
          <li>Our total aggregate liability for any claims arising out of or in connection with our services shall not exceed the fees actually paid by you to CZAAH for the specific service giving rise to the claim.</li>
          <li>CZAAH shall not be liable for any losses arising from events beyond our reasonable control, including but not limited to natural disasters, government actions, changes in law or regulation, currency controls, market disruptions, or force majeure events.</li>
        </ul>

        <h2>7. Governing Law</h2>
        <p>These Terms shall be governed by and construed in accordance with the laws of the Islamic Republic of Pakistan. The courts of Islamabad, Pakistan shall have exclusive jurisdiction over any disputes arising under these Terms.</p>

        <h2>8. Dispute Resolution</h2>
        <p>In the event of any dispute, claim, or controversy arising out of or relating to these Terms or our services, the parties agree to first attempt resolution through good-faith negotiation for a period of thirty (30) days from the date written notice of the dispute is delivered.</p>
        <p>If the dispute cannot be resolved through negotiation, it shall be referred to and finally resolved by arbitration in accordance with the following:</p>
        <ul>
          <li>Arbitration shall be conducted under the Arbitration Act, 1940, as amended, with the seat of arbitration in Islamabad, Pakistan.</li>
        </ul>
        <p>The arbitration shall be conducted in the English language. The decision of the arbitrator(s) shall be final and binding on both parties.</p>

        <h2>9. Third-Party Links</h2>
        <p>Our website may contain links to third-party websites, services, or resources. These links are provided for your convenience and informational purposes only. CZAAH does not endorse, control, or assume responsibility for the content, privacy policies, or practices of any third-party websites.</p>
        <p>Accessing third-party websites through links on our website is at your own risk. We encourage you to review the terms and privacy policies of any third-party website you visit.</p>

        <h2>10. Confidentiality</h2>
        <p>All non-public information exchanged between CZAAH and its clients in the course of any engagement shall be treated as confidential. Neither party shall disclose confidential information to any third party without the prior written consent of the other party, except as required by law, regulation, or legal process.</p>
        <p>This obligation of confidentiality shall survive the termination of any service agreement or engagement between the parties.</p>

        <h2>11. Amendments</h2>
        <p>CZAAH reserves the right to modify, update, or replace any part of these Terms at its sole discretion. Changes will be effective upon posting on our website with an updated &quot;Last updated&quot; date.</p>
        <p>It is your responsibility to review these Terms periodically for changes. Your continued use of our website or services following the posting of any changes constitutes acceptance of those changes.</p>
        <p>Material changes to these Terms that may affect existing client relationships will be communicated through direct notification where practicable.</p>

        <h2>12. Severability</h2>
        <p>If any provision of these Terms is held to be invalid, illegal, or unenforceable by a court of competent jurisdiction, such provision shall be modified to the minimum extent necessary to make it valid and enforceable, or if modification is not possible, it shall be severed from these Terms. The remaining provisions shall continue in full force and effect.</p>

        <h2>13. Contact Us</h2>
        <p>If you have questions or concerns regarding these Terms &amp; Conditions, please contact us:</p>
        <p>
          <strong>Email:</strong> <a href="mailto:info@czaah.com" className="text-czaah-gold">info@czaah.com</a><br />
          <strong>CZAAH Capital &amp; Ventures (Private) Limited</strong><br />
          Islamabad, Pakistan
        </p>
      </main>

      <Footer />
    </>
  )
}
