'use client';
// @ts-nocheck

import { useState, useEffect, useRef, useCallback } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface LicenseItem {
  name: string;
  body: string;
  time: string;
  level: 'low' | 'medium' | 'high';
  desc: string;
}

const universal: LicenseItem[] = [
  { name: 'SECP Registration', body: 'Securities & Exchange Commission of Pakistan', time: '7\u201315 days', level: 'low', desc: 'Company incorporation and registration with SECP \u2014 the foundational requirement for any business entity operating in Pakistan.' },
  { name: 'NTN (Tax Number)', body: 'Federal Board of Revenue', time: '3\u20135 days', level: 'low', desc: 'National Tax Number registration for income tax purposes \u2014 mandatory for all businesses and required before any commercial activity.' },
  { name: 'Sales Tax Registration', body: 'Federal Board of Revenue', time: '5\u20137 days', level: 'low', desc: 'Registration under the Sales Tax Act for businesses involved in the supply of taxable goods or services.' },
  { name: 'Social Security (EOBI)', body: 'Employees Old-Age Benefits Institution', time: '7\u201314 days', level: 'low', desc: 'Employer registration with EOBI for mandatory employee pension and social security contributions.' }
];

const sectors: Record<string, { label: string; items: LicenseItem[] }> = {
  mining: { label: 'Mining & Minerals', items: [
    { name: 'Exploration License', body: 'Provincial Mines & Minerals Dept', time: '30\u201390 days', level: 'high', desc: 'Authorization to conduct mineral exploration activities within a designated area. Requires detailed work programme and financial capability proof.' },
    { name: 'Mining Lease', body: 'Provincial Mines & Minerals Dept', time: '60\u2013180 days', level: 'high', desc: 'Lease granting the right to extract minerals from a specific area. Requires exploration data, environmental plan, and provincial government approval.' },
    { name: 'Environmental Impact Assessment', body: 'Environmental Protection Agency', time: '30\u201360 days', level: 'medium', desc: 'Mandatory environmental review for mining operations, assessing impact on land, water, air quality, and local communities.' },
    { name: 'Explosives License', body: 'Dept of Explosives', time: '14\u201330 days', level: 'medium', desc: 'License for the purchase, storage, and use of explosives in mining operations. Requires safety protocols and secure storage facilities.' },
    { name: 'NOC (Security)', body: 'Home Department', time: '14\u201321 days', level: 'medium', desc: 'Security clearance from the provincial Home Department, particularly for mining operations in sensitive or border regions.' }
  ]},
  pharma: { label: 'Pharmaceuticals', items: [
    { name: 'DRAP Manufacturing License', body: 'Drug Regulatory Authority of Pakistan', time: '60\u2013120 days', level: 'high', desc: 'License to establish and operate a pharmaceutical manufacturing facility. Requires facility inspection and quality system documentation.' },
    { name: 'GMP Certification', body: 'Drug Regulatory Authority of Pakistan', time: '90\u2013180 days', level: 'high', desc: 'Good Manufacturing Practice certification ensuring pharmaceutical production meets international quality standards.' },
    { name: 'Product Registration', body: 'DRAP (per product)', time: '30\u201390 days', level: 'medium', desc: 'Individual registration for each pharmaceutical product before it can be manufactured, imported, or sold in Pakistan.' },
    { name: 'Controlled Substances License', body: 'Drug Regulatory Authority of Pakistan', time: '30\u201360 days', level: 'high', desc: 'Special license for handling, manufacturing, or distributing controlled and narcotic substances under strict regulatory oversight.' },
    { name: 'Import License (APIs)', body: 'Ministry of Commerce', time: '14\u201330 days', level: 'medium', desc: 'Authorization to import Active Pharmaceutical Ingredients required for drug manufacturing.' }
  ]},
  tech: { label: 'Technology & IT', items: [
    { name: 'PTA License (Telecom)', body: 'Pakistan Telecommunication Authority', time: '30\u201360 days', level: 'medium', desc: 'Licensing for telecom services, ISPs, and technology companies operating communication infrastructure in Pakistan.' },
    { name: 'STZ Registration', body: 'Special Technology Zone Authority', time: '14\u201330 days', level: 'low', desc: 'Registration with a Special Technology Zone for tax incentives, streamlined regulation, and tech ecosystem benefits.' },
    { name: 'Data Protection Compliance', body: 'Ministry of IT & Telecom', time: 'Ongoing', level: 'medium', desc: "Compliance with Pakistan's evolving data protection framework, including data handling, storage, and cross-border transfer requirements." },
    { name: 'Software Export Registration', body: 'Pakistan Software Export Board', time: '7\u201314 days', level: 'low', desc: 'Registration with PSEB to access IT export incentives, tax benefits, and official recognition as a software exporter.' }
  ]},
  food: { label: 'Food & Agriculture', items: [
    { name: 'Food Safety License', body: 'PSQCA / Provincial Food Authority', time: '30\u201360 days', level: 'medium', desc: 'Mandatory food safety certification for businesses involved in food production, processing, storage, or distribution.' },
    { name: 'Organic Certification', body: 'Accredited Certification Body', time: '60\u201390 days', level: 'medium', desc: 'Third-party certification verifying organic farming and production standards for premium market access.' },
    { name: 'Phytosanitary Certificate', body: 'Dept of Plant Protection', time: '7\u201314 days', level: 'low', desc: 'Certificate confirming agricultural exports are free from pests and diseases, required by importing countries.' },
    { name: 'Cold Storage License', body: 'Provincial Authority', time: '14\u201330 days', level: 'low', desc: 'License for operating cold chain and storage facilities, essential for perishable food and agricultural products.' }
  ]},
  construction: { label: 'Construction', items: [
    { name: 'PEC Registration', body: 'Pakistan Engineering Council', time: '14\u201330 days', level: 'medium', desc: 'Mandatory registration for engineering and construction firms, establishing eligibility for government and private contracts.' },
    { name: 'Building Permit', body: 'CDA / LDA / KDA', time: '30\u201390 days', level: 'high', desc: 'Development authority approval for construction projects, covering structural plans, land use zoning, and safety compliance.' },
    { name: 'Environmental NOC', body: 'Environmental Protection Agency', time: '30\u201360 days', level: 'medium', desc: 'Environmental clearance for construction projects assessing impact on surroundings, drainage, and waste management.' },
    { name: 'Fire Safety Certificate', body: 'Civil Defence', time: '7\u201314 days', level: 'low', desc: 'Certification confirming the building meets fire safety standards, including emergency exits, fire suppression, and alarm systems.' },
    { name: 'Labour License', body: 'Provincial Labour Dept', time: '7\u201314 days', level: 'low', desc: 'Registration under provincial labour laws for businesses employing workers, covering wage, safety, and welfare compliance.' }
  ]},
  trade: { label: 'Import & Export', items: [
    { name: 'WeBOC Registration', body: 'Pakistan Customs', time: '7\u201314 days', level: 'low', desc: "Registration on Pakistan Customs' Web Based One Customs clearance system \u2014 required for all import/export operations." },
    { name: 'Chamber of Commerce Membership', body: 'FPCCI / Local Chamber', time: '3\u20137 days', level: 'low', desc: 'Membership with the Federation of Pakistan Chambers of Commerce or local chamber, required for trade documentation.' },
    { name: 'GSP+ Documentation', body: 'Ministry of Commerce', time: 'Ongoing', level: 'medium', desc: 'Compliance documentation for EU Generalised Scheme of Preferences Plus, providing duty-free access to European markets.' },
    { name: 'SRO Exemption Applications', body: 'Federal Board of Revenue', time: '14\u201330 days', level: 'medium', desc: 'Applications for Statutory Regulatory Order-based tax and duty exemptions applicable to specific trade categories.' }
  ]},
  energy: { label: 'Energy & Power', items: [
    { name: 'NEPRA License', body: 'National Electric Power Regulatory Authority', time: '60\u2013120 days', level: 'high', desc: 'License for electricity generation, transmission, or distribution. Covers solar, wind, hydro, and thermal power projects.' },
    { name: 'OGRA License', body: 'Oil & Gas Regulatory Authority', time: '60\u201390 days', level: 'high', desc: 'License for oil and gas exploration, refining, distribution, or LPG/CNG operations in Pakistan.' },
    { name: 'Environmental Approval', body: 'Environmental Protection Agency', time: '30\u201360 days', level: 'medium', desc: 'Environmental clearance for energy projects, including impact assessment on emissions, land use, and water resources.' },
    { name: 'Grid Connection', body: 'NTDC / DISCO', time: '30\u201390 days', level: 'high', desc: 'Approval for connecting power generation facilities to the national grid via NTDC or regional distribution company.' }
  ]},
  healthcare: { label: 'Healthcare', items: [
    { name: 'Hospital Registration', body: 'Provincial Health Dept', time: '30\u201360 days', level: 'medium', desc: 'Registration and licensing of healthcare facilities including hospitals, clinics, and medical centres under provincial health regulations.' },
    { name: 'PMDC Registration', body: 'Pakistan Medical & Dental Council', time: '14\u201330 days', level: 'medium', desc: 'Registration for medical practitioners and healthcare institutions, ensuring qualified staff and standards compliance.' },
    { name: 'Diagnostic Lab License', body: 'Provincial Authority', time: '30\u201345 days', level: 'medium', desc: 'License for operating diagnostic and pathology laboratories, requiring equipment standards and qualified technicians.' },
    { name: 'Pharmacy License', body: 'Provincial Pharmacy Council', time: '14\u201330 days', level: 'low', desc: 'License for operating a pharmacy, requiring a qualified pharmacist and compliance with drug storage and dispensing regulations.' }
  ]}
};

function ComplexityBars({ level }: { level: 'low' | 'medium' | 'high' }) {
  const count = level === 'low' ? 1 : level === 'medium' ? 2 : 3;
  const label = level.charAt(0).toUpperCase() + level.slice(1);
  return (
    <div className={`lc-card-right lc-${level}`}>
      <div className="lc-complexity">
        {[0, 1, 2].map(i => (
          <div key={i} className={`lc-bar${i < count ? ' lc-filled' : ''}`}></div>
        ))}
      </div>
      <div className="lc-complexity-text">{label}</div>
    </div>
  );
}

function LicenseCard({ item, visible }: { item: LicenseItem; visible: boolean }) {
  return (
    <div className={`lc-card${visible ? ' lc-visible' : ''}`}>
      <div className="lc-card-main">
        <div className="lc-card-name">{item.name}</div>
        <div className="lc-card-body">{item.desc}</div>
        <div className="lc-card-meta">
          <span>&#9670; {item.body}</span>
          <span>&#9200; {item.time}</span>
        </div>
      </div>
      <ComplexityBars level={item.level} />
    </div>
  );
}

export default function LicensingPage() {
  const [activeSector, setActiveSector] = useState<string | null>(null);
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set());
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('visible');
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => {
      observerRef.current?.observe(el);
    });

    return () => observerRef.current?.disconnect();
  }, []);

  const handleSectorClick = useCallback((sectorKey: string) => {
    setActiveSector(sectorKey);
    setVisibleCards(new Set());

    const sector = sectors[sectorKey];
    if (!sector) return;

    const totalCards = universal.length + sector.items.length;
    for (let i = 0; i < totalCards; i++) {
      setTimeout(() => {
        setVisibleCards(prev => new Set(prev).add(i));
      }, 60 * i);
    }
  }, []);

  const sectorData = activeSector ? sectors[activeSector] : null;
  const allItems = sectorData ? [...universal, ...sectorData.items] : [];

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Licensing.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Government &amp; Regulatory</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Licensing &amp;<br /><span className="gold">Compliance.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Navigating Pakistan&apos;s regulatory landscape requires deep institutional knowledge. CZAAH manages FBR registration, Board of Investment approvals, industry-specific licensing, provincial permits, and environmental clearances — so you can operate with full confidence.</p>
              <a href="/contact?interest=Licensing%20%26%20Compliance#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Navigate Regulations &rarr;</a>
            </div>
          </section>
        </div>

        {/* SECTOR COMPLIANCE NAVIGATOR */}
        <style>{`
          .lc-navigator {
            max-width: 1100px; margin: 0 auto; padding: 80px 32px;
          }
          .lc-heading {
            font-family: 'Cinzel', serif; font-size: 2.2rem; font-weight: 600;
            color: var(--white); margin-bottom: 8px;
          }
          .lc-heading .gold { color: var(--gold); }
          .lc-subtext {
            color: var(--white-muted); font-size: 1.05rem; margin-bottom: 36px; max-width: 640px;
          }
          .lc-pills { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 40px; }
          .lc-pill {
            background: var(--black-card); border: 1px solid var(--black-border);
            color: var(--white-muted); font-family: 'Raleway', sans-serif; font-size: 0.88rem;
            font-weight: 500; padding: 10px 20px; border-radius: 100px; cursor: pointer;
            transition: all 0.3s var(--ease-smooth); white-space: nowrap;
          }
          .lc-pill:hover { border-color: var(--gold-dim); color: var(--white); }
          .lc-pill.lc-active {
            background: var(--gold); border-color: var(--gold); color: #000; font-weight: 600;
          }
          .lc-panel { min-height: 120px; }
          .lc-empty {
            text-align: center; padding: 60px 20px; color: var(--white-dim); font-size: 1.05rem;
            border: 1px dashed var(--black-border); border-radius: 12px;
          }
          .lc-group-label {
            font-family: 'Raleway', sans-serif; font-size: 0.75rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.12em; color: var(--gold-dim);
            margin-bottom: 16px; margin-top: 8px;
          }
          .lc-group-label.lc-sector-label { margin-top: 36px; }
          .lc-cards { display: flex; flex-direction: column; gap: 12px; }
          .lc-card {
            background: var(--black-card); border: 1px solid var(--black-border); border-radius: 10px;
            padding: 20px 24px; display: grid; grid-template-columns: 1fr auto; gap: 12px 24px;
            align-items: start; opacity: 0; transform: translateY(14px);
            transition: opacity 0.4s var(--ease-out), transform 0.4s var(--ease-out), border-color 0.3s;
          }
          .lc-card.lc-visible { opacity: 1; transform: translateY(0); }
          .lc-card:hover { border-color: var(--gold-dim); }
          .lc-card-main { min-width: 0; }
          .lc-card-name {
            font-family: 'Raleway', sans-serif; font-weight: 600; font-size: 1rem;
            color: var(--white); margin-bottom: 4px;
          }
          .lc-card-body { color: var(--white-dim); font-size: 0.88rem; margin-bottom: 8px; }
          .lc-card-meta { display: flex; flex-wrap: wrap; gap: 16px; font-size: 0.8rem; color: var(--white-muted); }
          .lc-card-meta span { display: flex; align-items: center; gap: 5px; }
          .lc-card-right {
            display: flex; flex-direction: column; align-items: flex-end; gap: 6px; padding-top: 2px;
          }
          .lc-complexity { display: flex; gap: 3px; align-items: center; }
          .lc-bar {
            width: 18px; height: 5px; border-radius: 2px; background: var(--black-border); transition: background 0.3s;
          }
          .lc-bar.lc-filled { background: var(--black-border); }
          .lc-low .lc-bar.lc-filled { background: #4ade80; }
          .lc-medium .lc-bar.lc-filled { background: var(--gold); }
          .lc-high .lc-bar.lc-filled { background: #f87171; }
          .lc-complexity-text {
            font-size: 0.72rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 0.08em; text-align: right;
          }
          .lc-low .lc-complexity-text { color: #4ade80; }
          .lc-medium .lc-complexity-text { color: var(--gold); }
          .lc-high .lc-complexity-text { color: #f87171; }
          @media (max-width: 640px) {
            .lc-navigator { padding: 48px 18px; }
            .lc-heading { font-size: 1.6rem; }
            .lc-card { grid-template-columns: 1fr; gap: 10px; }
            .lc-card-right { flex-direction: row; align-items: center; gap: 12px; }
            .lc-pills { gap: 8px; }
            .lc-pill { padding: 8px 16px; font-size: 0.82rem; }
          }
        `}</style>

        <section className="lc-navigator fade-in">
          <h2 className="lc-heading">Sector Compliance <span className="gold">Navigator.</span></h2>
          <p className="lc-subtext">Select your industry sector to see the full regulatory roadmap — every license, permit, and registration required to operate in Pakistan.</p>

          <div className="lc-pills">
            {Object.entries(sectors).map(([key]) => (
              <button
                key={key}
                className={`lc-pill${activeSector === key ? ' lc-active' : ''}`}
                onClick={() => handleSectorClick(key)}
              >
                {key === 'mining' ? 'Mining & Minerals' :
                 key === 'pharma' ? 'Pharmaceuticals' :
                 key === 'tech' ? 'Technology & IT' :
                 key === 'food' ? 'Food & Agriculture' :
                 key === 'construction' ? 'Construction' :
                 key === 'trade' ? 'Import & Export' :
                 key === 'energy' ? 'Energy & Power' :
                 key === 'healthcare' ? 'Healthcare' : key}
              </button>
            ))}
          </div>

          <div className="lc-panel">
            {!activeSector ? (
              <div className="lc-empty">Select your industry to see the full regulatory roadmap</div>
            ) : (
              <>
                <div className="lc-group-label">Universal Requirements</div>
                <div className="lc-cards">
                  {universal.map((item, i) => (
                    <LicenseCard key={`u-${i}`} item={item} visible={visibleCards.has(i)} />
                  ))}
                </div>
                {sectorData && (
                  <>
                    <div className="lc-group-label lc-sector-label">{sectorData.label} — Sector-Specific</div>
                    <div className="lc-cards">
                      {sectorData.items.map((item, i) => (
                        <LicenseCard key={`s-${i}`} item={item} visible={visibleCards.has(universal.length + i)} />
                      ))}
                    </div>
                  </>
                )}
              </>
            )}
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Comprehensive licensing and compliance management across Pakistan&apos;s federal and provincial regulatory framework.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>FBR Registration</h3>
              <p>National Tax Number (NTN) acquisition, sales tax registration, income tax compliance setup, and ongoing FBR filing management. We ensure your tax obligations are met from day one.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9881;</div>
              <h3>Board of Investment</h3>
              <p>Foreign investment approval facilitation, profit repatriation permissions, investment incentive scheme applications, and BOI liaison for international investors entering Pakistan.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Industry Licensing</h3>
              <p>Sector-specific permits and licenses for mining, pharmaceuticals, telecommunications, food production, manufacturing, and other regulated industries across Pakistan.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9632;</div>
              <h3>Provincial Permits</h3>
              <p>Development authority approvals, environmental impact assessments, No Objection Certificates (NOCs), and provincial regulatory clearances across Punjab, Sindh, KPK, and Balochistan.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8644;</div>
              <h3>Import/Export Licensing</h3>
              <p>WeBOC registration, customs licensing, trade permits, and import/export documentation. We prepare your business for compliant cross-border trade operations.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#36;</div>
              <h3>Ongoing Regulatory Compliance</h3>
              <p>Tax filings, audit coordination, regulatory reporting, and compliance monitoring. Proactive management ensures your business stays ahead of evolving regulatory requirements.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">Regulatory capabilities <span className="gold">at a glance.</span></h2>
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">50+</div>
              <div className="label">Regulatory bodies navigated</div>
            </div>
            <div className="stat-item">
              <div className="number">FBR</div>
              <div className="label">Registered tax agents</div>
            </div>
            <div className="stat-item">
              <div className="number">BOI</div>
              <div className="label">Investment facilitation</div>
            </div>
            <div className="stat-item">
              <div className="number">Multi</div>
              <div className="label">Provincial coverage</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* WHY CZAAH */}
        <section className="section fade-in">
          <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
          <p className="subtitle">We turn Pakistan&apos;s regulatory complexity into a streamlined process for our clients.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>Regulatory Expertise</h4>
                <p>Deep understanding of Pakistan&apos;s multi-layered regulatory framework — federal, provincial, and sector-specific. Our team has navigated licensing processes across every major industry and jurisdiction in the country.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>Government Relationships</h4>
                <p>Established working relationships with FBR, BOI, SECP, provincial development authorities, and sector regulators enable us to expedite approvals and resolve issues efficiently.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>Cross-Provincial Coverage</h4>
                <p>Operations and relationships spanning Punjab, Sindh, KPK, Balochistan, and Gilgit-Baltistan. Wherever your project is located, we have the regulatory knowledge and access to support it.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#8644;</div>
              <div>
                <h4>Proactive Compliance</h4>
                <p>We don&apos;t just secure licenses — we maintain them. Ongoing monitoring of regulatory changes, filing deadlines, and compliance requirements ensures your business is always ahead of the curve.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Navigate Pakistan&apos;s regulatory <span className="gold">landscape.</span></h2>
          <p>FBR, BOI, provincial permits, and industry licensing &mdash; managed by a team that operates inside these institutions.</p>
          <a href="/contact?interest=Licensing%20%26%20Compliance#contact-form" className="btn-gold">Discuss Compliance &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
