'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'

interface Service {
  id: string
  name: string
  slug: string
  description: string
  icon_url: string | null
  image_url: string | null
}

export default function ServicesPage() {
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchServices() {
      try {
        const res = await fetch('/api/public/services')
        if (res.ok) {
          const data = await res.json()
          setServices(data)
        }
      } catch (err) {
        console.error('Failed to fetch services:', err)
      } finally {
        setLoading(false)
      }
    }
    fetchServices()
  }, [])

  return (
    <div className="min-h-screen bg-czaah-black">
      {/* Hero */}
      <section className="pt-32 pb-24 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="font-[family-name:var(--font-heading)] text-5xl md:text-6xl lg:text-7xl text-czaah-gold tracking-wide mb-8">
            Our Services.
          </h1>
          <p className="font-[family-name:var(--font-display)] italic text-xl md:text-2xl text-czaah-muted max-w-4xl leading-relaxed">
            CZAAH provides a comprehensive suite of institutional services designed
            to facilitate investment, manage risk, and deliver results across
            complex markets and regulatory environments.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="pb-24 px-6 border-t border-czaah-border">
        <div className="max-w-7xl mx-auto pt-16">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-czaah-card border border-czaah-border rounded-lg p-8 animate-pulse"
                >
                  <div className="h-6 bg-czaah-elevated rounded w-2/3 mb-4" />
                  <div className="h-4 bg-czaah-elevated rounded w-full mb-2" />
                  <div className="h-4 bg-czaah-elevated rounded w-4/5" />
                </div>
              ))}
            </div>
          ) : services.length === 0 ? (
            <div className="text-center py-20">
              <p className="font-[family-name:var(--font-body)] text-czaah-muted text-lg">
                No services available at this time.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service) => (
                <Link
                  key={service.id}
                  href={`/services/${service.slug}`}
                  className="group bg-czaah-card border border-czaah-border rounded-lg p-8 hover:border-czaah-gold/40 transition-all duration-300"
                >
                  <h3 className="font-[family-name:var(--font-heading)] text-lg text-czaah-gold mb-4 group-hover:text-czaah-gold-light transition-colors">
                    {service.name}
                  </h3>
                  <p className="font-[family-name:var(--font-body)] text-czaah-muted text-sm leading-relaxed mb-6">
                    {service.description}
                  </p>
                  <span className="font-[family-name:var(--font-body)] text-czaah-gold text-sm tracking-wide uppercase group-hover:translate-x-1 inline-block transition-transform">
                    Explore &rarr;
                  </span>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 border-t border-czaah-border">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="font-[family-name:var(--font-display)] italic text-3xl md:text-4xl text-czaah-white mb-8">
            Need a tailored solution?
          </h2>
          <Link
            href="/contact"
            className="inline-block bg-czaah-gold text-czaah-black font-[family-name:var(--font-body)] font-semibold px-10 py-4 rounded hover:bg-czaah-gold-light transition-colors text-lg"
          >
            Get in Touch
          </Link>
        </div>
      </section>
    </div>
  )
}
