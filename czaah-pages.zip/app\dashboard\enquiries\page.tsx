'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

interface Enquiry {
  id: string
  reference_number: string
  product_name: string | null
  sector_id: string | null
  status: string
  description: string | null
  created_at: string
  member_id: string
  assigned_admin_id: string | null
  profiles?: { full_name: string; email: string }
  sectors?: { name: string } | null
  last_message?: string | null
}

const STATUS_BADGES: Record<string, string> = {
  submitted: 'bg-yellow-500/20 text-yellow-400',
  assigned: 'bg-blue-500/20 text-blue-400',
  active: 'bg-green-500/20 text-green-400',
  waiting: 'bg-orange-500/20 text-orange-400',
  resolved: 'bg-neutral-500/20 text-neutral-400',
  archived: 'bg-neutral-500/20 text-neutral-400',
}

const FILTER_TABS = ['All', 'Active', 'Waiting', 'Resolved'] as const

function EnquiryRow({ enq }: { enq: Enquiry }) {
  return (
    <Link
      href={`/dashboard/enquiries/${enq.id}`}
      className="block px-6 py-4 hover:bg-czaah-elevated transition-colors"
    >
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-3 mb-1">
            <span className="font-medium text-czaah-white truncate">
              {enq.product_name || 'General Enquiry'}
            </span>
            <span className={`text-xs px-2 py-0.5 rounded shrink-0 ${STATUS_BADGES[enq.status] || ''}`}>
              {enq.status}
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs text-czaah-muted-dim">
            <span>{enq.reference_number}</span>
            {enq.sectors?.name && (
              <>
                <span>&middot;</span>
                <span>{enq.sectors.name}</span>
              </>
            )}
          </div>
          {enq.last_message && (
            <p className="text-xs text-czaah-muted mt-1 truncate max-w-md">
              {enq.last_message}
            </p>
          )}
        </div>
        <span className="text-xs text-czaah-muted-dim shrink-0">
          {new Date(enq.created_at).toLocaleDateString()}
        </span>
      </div>
    </Link>
  )
}

export default function EnquiriesListPage() {
  const [enquiries, setEnquiries] = useState<Enquiry[]>([])
  const [userId, setUserId] = useState<string | null>(null)
  const [userRole, setUserRole] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<(typeof FILTER_TABS)[number]>('All')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function load() {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) { router.push('/login'); return }
        setUserId(user.id)

        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single()
        setUserRole(profile?.role || 'member')

        // Fetch enquiries via API
        const res = await fetch('/api/enquiries')
        const json = await res.json()
        if (!res.ok) throw new Error(json.error || 'Failed to load enquiries')

        const enqs: Enquiry[] = json.data || []

        // Fetch sector names for each unique sector_id
        const sectorIds = [...new Set(enqs.map((e) => e.sector_id).filter(Boolean))] as string[]
        let sectorMap: Record<string, string> = {}
        if (sectorIds.length > 0) {
          const { data: sectors } = await supabase
            .from('sectors')
            .select('id, name')
            .in('id', sectorIds)
          if (sectors) {
            sectorMap = Object.fromEntries(sectors.map((s) => [s.id, s.name]))
          }
        }

        // Fetch last message for each enquiry
        const enquiryIds = enqs.map((e) => e.id)
        const lastMessages: Record<string, string> = {}
        if (enquiryIds.length > 0) {
          for (const eid of enquiryIds) {
            const { data: msgs } = await supabase
              .from('chat_messages')
              .select('content')
              .eq('enquiry_id', eid)
              .eq('is_internal_note', false)
              .order('created_at', { ascending: false })
              .limit(1)
            if (msgs && msgs.length > 0) {
              lastMessages[eid] = msgs[0].content || ''
            }
          }
        }

        const enriched = enqs.map((e) => ({
          ...e,
          sectors: e.sector_id && sectorMap[e.sector_id] ? { name: sectorMap[e.sector_id] } : null,
          last_message: lastMessages[e.id] || null,
        }))

        setEnquiries(enriched)
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Something went wrong')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const applyFilter = (list: Enquiry[]) => list.filter((e) => {
    if (activeTab === 'All') return true
    if (activeTab === 'Active') return ['submitted', 'assigned', 'active'].includes(e.status)
    if (activeTab === 'Waiting') return e.status === 'waiting'
    if (activeTab === 'Resolved') return ['resolved', 'archived'].includes(e.status)
    return true
  })

  const isAdminOrSuper = userRole === 'admin' || userRole === 'super_admin'
  const assignedEnquiries = applyFilter(enquiries.filter(e => e.assigned_admin_id === userId && e.member_id !== userId))
  const myEnquiries = applyFilter(enquiries.filter(e => e.member_id === userId))
  const allFiltered = applyFilter(enquiries)

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-czaah-muted">Loading...</div>
      </div>
    )
  }

  return (
    <>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <h1 className="font-[family-name:var(--font-heading)] text-2xl text-czaah-white">
          Enquiries
        </h1>
        <Link
          href="/dashboard/enquiries/new"
          className="bg-czaah-gold text-czaah-black font-semibold px-5 py-2.5 rounded text-sm hover:bg-czaah-gold-light transition-colors"
        >
          New Enquiry
        </Link>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {FILTER_TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-1.5 rounded text-sm whitespace-nowrap transition-colors ${
              activeTab === tab
                ? 'bg-czaah-gold text-czaah-black font-semibold'
                : 'bg-czaah-card border border-czaah-border text-czaah-muted hover:text-czaah-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 mb-6">
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      {isAdminOrSuper ? (
        <>
          {/* Assigned Enquiries */}
          <div className="bg-czaah-card border border-czaah-border rounded-lg mb-6">
            <div className="px-6 py-4 border-b border-czaah-border">
              <h2 className="font-[family-name:var(--font-heading)] text-lg">Assigned Enquiries</h2>
            </div>
            {assignedEnquiries.length === 0 ? (
              <div className="px-6 py-10 text-center">
                <p className="text-czaah-muted text-sm">No enquiries assigned to you{activeTab !== 'All' ? ` (${activeTab})` : ''}.</p>
              </div>
            ) : (
              <div className="divide-y divide-czaah-border">
                {assignedEnquiries.map((enq) => <EnquiryRow key={enq.id} enq={enq} />)}
              </div>
            )}
          </div>

          {/* My Enquiries */}
          <div className="bg-czaah-card border border-czaah-border rounded-lg">
            <div className="px-6 py-4 border-b border-czaah-border">
              <h2 className="font-[family-name:var(--font-heading)] text-lg">My Enquiries</h2>
            </div>
            {myEnquiries.length === 0 ? (
              <div className="px-6 py-10 text-center">
                <p className="text-czaah-muted text-sm">You haven&apos;t submitted any enquiries{activeTab !== 'All' ? ` (${activeTab})` : ''}.</p>
              </div>
            ) : (
              <div className="divide-y divide-czaah-border">
                {myEnquiries.map((enq) => <EnquiryRow key={enq.id} enq={enq} />)}
              </div>
            )}
          </div>
        </>
      ) : (
        /* Member view — single list */
        <div className="bg-czaah-card border border-czaah-border rounded-lg">
          {allFiltered.length === 0 ? (
            <div className="px-6 py-16 text-center">
              <p className="text-czaah-muted mb-4">No enquiries{activeTab !== 'All' ? ` (${activeTab})` : ''}.</p>
              <Link
                href="/dashboard/enquiries/new"
                className="inline-block bg-czaah-gold text-czaah-black font-semibold px-6 py-2.5 rounded hover:bg-czaah-gold/90 transition-colors text-sm"
              >
                Submit an Enquiry
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-czaah-border">
              {allFiltered.map((enq) => <EnquiryRow key={enq.id} enq={enq} />)}
            </div>
          )}
        </div>
      )}
    </>
  )
}
