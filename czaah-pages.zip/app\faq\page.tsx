'use client'
// @ts-nocheck

import { useState, type ReactNode } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

interface FaqItem {
  question: string
  answer: string | ReactNode
}

interface FaqCategory {
  title: string
  titleGold: string
  items: FaqItem[]
}

const FAQ_DATA: FaqCategory[] = [
  {
    title: 'Investment',
    titleGold: 'Basics',
    items: [
      {
        question: 'What is CZAAH?',
        answer: 'CZAAH is a diversified investment facilitation group headquartered in Islamabad, Pakistan, with international reach across key global markets. We connect international investors with Pakistan\u2019s highest-growth opportunities across minerals, real estate, technology, textiles, agriculture, and pharmaceuticals.',
      },
      {
        question: 'Who can invest through CZAAH?',
        answer: 'We serve institutional investors, multinational corporations, sovereign entities, Gulf-based family offices, diaspora Pakistanis (UK, US, UAE), and high-net-worth individuals. Our institutional structure accommodates both direct and structured investment.',
      },
      {
        question: 'What is the minimum investment?',
        answer: 'Investment minimums vary by opportunity and structure. Deal-by-deal investments typically start from $100,000, while pooled vehicles may offer lower entry points. Contact us to discuss specific opportunities.',
      },
    ],
  },
  {
    title: 'Legal &',
    titleGold: 'Regulatory',
    items: [
      {
        question: 'Is it safe for foreigners to invest in Pakistan?',
        answer: 'Yes. Pakistan\u2019s Board of Investment (BOI) actively facilitates foreign investment with repatriation guarantees and incentive schemes. CZAAH provides additional protection through institutional-grade legal frameworks, comprehensive due diligence, and defined exit mechanisms.',
      },
      {
        question: 'What legal structure is used for investments?',
        answer: 'We use Special Purpose Vehicles (SPVs) for individual deals, protecting investors from cross-deal risk. Our institutional structure provides international investors with robust legal frameworks and transparent transaction structures.',
      },
      {
        question: 'How long does company registration take in Pakistan?',
        answer: 'SECP company incorporation can be completed in 48\u201372 hours with fast-track processing. Full operational setup including FBR registration, bank accounts, and BOI approvals typically takes 2\u20134 weeks with CZAAH\u2019s facilitation.',
      },
    ],
  },
  {
    title: 'Sectors &',
    titleGold: 'Opportunities',
    items: [
      {
        question: 'Which sectors offer the best returns?',
        answer: 'Minerals and mining (particularly copper and gold exploration) and CPEC corridor real estate currently offer the highest growth potential. Technology and pharmaceuticals offer strong recurring returns. We recommend a diversified approach based on your risk profile.',
      },
      {
        question: 'What is CPEC and why does it matter?',
        answer: 'The China-Pakistan Economic Corridor is a $62 billion+ infrastructure and economic development programme creating 9 Special Economic Zones across Pakistan. It\u2019s driving massive demand for commercial property, industrial capacity, and supporting services.',
      },
      {
        question: 'Can I invest from the UAE/UK/US without visiting Pakistan?',
        answer: 'Yes. Our international operations allow investors from the UAE, UK, US, and beyond to invest through familiar frameworks with transparent transactions. We handle all on-the-ground operations, due diligence, and asset management on your behalf.',
      },
    ],
  },
  {
    title: 'Process &',
    titleGold: 'Reporting',
    items: [
      {
        question: 'How does the investment process work?',
        answer: (
          <span>Five steps: Initial consultation, investment assessment and proposal, legal and licensing facilitation, investment execution, and ongoing portfolio management. See our <Link href="/process" className="text-czaah-gold hover:underline">How It Works</Link> page for details.</span>
        ),
      },
      {
        question: 'What reporting do investors receive?',
        answer: 'Quarterly performance reports, independent valuations, regulatory compliance updates, and ad-hoc reporting as needed. All reporting meets international institutional standards.',
      },
      {
        question: 'What are the exit options?',
        answer: 'Every investment is structured with defined exit mechanisms \u2014 buyback arrangements, secondary market facilitation, or agreed-upon timelines. Exit terms are established before investment.',
      },
    ],
  },
]

function FaqAccordion({ category }: { category: FaqCategory }) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  return (
    <div className="mb-12">
      <h3 className="font-[family-name:var(--font-heading)] text-2xl mb-6">
        {category.title} <span className="gold">{category.titleGold}</span>
      </h3>

      {category.items.map((item, i) => {
        const isActive = activeIndex === i
        return (
          <div key={i} className="border-b border-czaah-border">
            <div
              className="flex justify-between items-center py-5 cursor-pointer text-base font-medium text-czaah-white hover:text-czaah-gold transition-colors"
              onClick={() => setActiveIndex(isActive ? null : i)}
            >
              <span>{item.question}</span>
              <span className={`text-xl text-czaah-gold transition-transform ${isActive ? 'rotate-45' : ''}`}>+</span>
            </div>
            <div className={`overflow-hidden transition-all duration-400 ${isActive ? 'max-h-[500px] pb-5' : 'max-h-0'}`}>
              <p className="text-[15px] leading-[1.8] text-czaah-muted-dim">{item.answer}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default function FaqPage() {
  return (
    <>
      <Navbar />

      {/* HERO */}
      <section className="v-hero">
        <div className="v-hero-text">
          <Link href="/" className="back-link hero-enter">&larr; Back to Overview</Link>
          <span className="gold-line hero-enter"></span>
          <div className="label hero-enter hero-enter-delay-1">Frequently Asked Questions</div>
          <h1 className="serif hero-enter hero-enter-delay-2">Common <span className="gold">questions.</span></h1>
          <p className="hero-enter hero-enter-delay-3">Answers to the most common questions from international investors, diaspora Pakistanis, and corporations evaluating investment in Pakistan.</p>
        </div>
        <div className="v-hero-visual">
          <div className="v-hero-graphic">
            <img src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=800&q=80" alt="Documents and study" loading="eager" />
            <div className="img-overlay"></div>
            <div className="glow"></div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* FAQ SECTION */}
      <section className="section fade-in">
        {FAQ_DATA.map((category, i) => (
          <FaqAccordion key={i} category={category} />
        ))}
      </section>

      <div className="divider"></div>

      {/* CTA */}
      <section className="cta-banner fade-in">
        <h2 className="serif">Have a question not <span className="gold">listed here?</span></h2>
        <p>Our team is available to discuss your specific investment questions, regulatory concerns, or partnership enquiries.</p>
        <Link href="/contact" className="btn-gold">Contact Us &rarr;</Link>
      </section>

      <Footer />
    </>
  )
}
