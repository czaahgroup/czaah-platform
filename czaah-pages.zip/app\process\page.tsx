// @ts-nocheck
import Link from 'next/link'
import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

export default function ProcessPage() {
  return (
    <>
      <Navbar />

      {/* HERO */}
      <section className="v-hero">
        <div className="v-hero-text">
          <span className="gold-line hero-enter"></span>
          <div className="label hero-enter hero-enter-delay-1">Our Process</div>
          <h1 className="serif hero-enter hero-enter-delay-2">How it <span className="gold">works.</span></h1>
          <p className="hero-enter hero-enter-delay-3">A transparent, structured process designed to give international investors confidence at every stage &mdash; from initial assessment through ongoing portfolio management.</p>
          <Link href="/contact" className="btn-gold hero-enter hero-enter-delay-4">Begin a Consultation &rarr;</Link>
        </div>
        <div className="v-hero-visual">
          <div className="v-hero-graphic">
            <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80" alt="Business meeting" loading="eager" />
            <div className="img-overlay"></div>
            <div className="glow"></div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* PROCESS STEPS */}
      <section className="section fade-in">
        <h2 className="serif">Your investment <span className="gold">journey.</span></h2>
        <p className="subtitle">Five stages, each designed for clarity, speed, and investor protection.</p>

        <div className="process-list stagger">
          <div className="process-item">
            <div>
              <h4>Initial Consultation</h4>
              <p>A confidential discussion to understand your investment objectives, risk appetite, sector preferences, and timeline. We map the right opportunities to your goals across any of our twelve active sectors.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Investment Assessment &amp; Proposal</h4>
              <p>Our team conducts comprehensive market analysis, feasibility assessment, and due diligence on shortlisted opportunities. You receive a detailed investment proposal with financial projections, risk analysis, regulatory requirements, and recommended deal structure.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Legal &amp; Licensing Facilitation</h4>
              <p>We handle all regulatory navigation &mdash; SECP registration, BOI approvals, FBR compliance, industry licensing, and provincial permits. Our institutional structure provides clean legal frameworks for international investors.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Investment Execution</h4>
              <p>With approvals in place, we execute the investment &mdash; whether it&apos;s acquiring a mining lease, purchasing commercial property, securing a government contract, or establishing a manufacturing JV. Every transaction is documented, insured, and transparent.</p>
            </div>
          </div>
          <div className="process-item">
            <div>
              <h4>Ongoing Portfolio Management</h4>
              <p>Post-investment, CZAAH provides continuous oversight &mdash; financial reporting, asset management, regulatory compliance, performance monitoring, and strategic guidance. You have a dedicated team managing your Pakistan portfolio.</p>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* WHY THIS PROCESS WORKS */}
      <section className="section fade-in-left">
        <h2 className="serif">Why this process <span className="gold">works.</span></h2>
        <p className="subtitle">The principles that institutional investors expect from an emerging market counterparty.</p>

        <div className="detail-grid stagger" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
          <div className="detail-card">
            <div className="card-icon">&#9670;</div>
            <h3>Transparency</h3>
            <p>Every step documented, every decision explained. Full visibility into fees, timelines, and risk factors.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9632;</div>
            <h3>Speed</h3>
            <p>Regulatory relationships that compress timelines. What takes others months, we accomplish in weeks.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#9733;</div>
            <h3>Protection</h3>
            <p>Legal safeguards and insurance at every stage. Your capital is protected by international-grade frameworks.</p>
          </div>
          <div className="detail-card">
            <div className="card-icon">&#8644;</div>
            <h3>Reporting</h3>
            <p>Quarterly reports, real-time portfolio access, and a dedicated relationship manager for every engagement.</p>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* CTA */}
      <section className="cta-banner fade-in">
        <h2 className="serif">Ready to discuss <span className="gold">next steps?</span></h2>
        <p>A single consultation is all it takes to begin. Our team will assess your objectives and outline a tailored path forward.</p>
        <Link href="/contact" className="btn-gold">Request a Consultation &rarr;</Link>
      </section>

      <Footer />
    </>
  )
}
