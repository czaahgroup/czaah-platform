'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

interface Bookmark {
  id: string
  sector_id: string | null
  service_id: string | null
  product_id: string | null
  created_at: string
}

interface SectorInfo { id: string; name: string; slug: string; description: string | null }
interface ServiceInfo { id: string; name: string; slug: string; description: string | null }
interface ProductInfo { id: string; name: string; slug: string; description: string | null; sector_id: string | null; service_id: string | null }

type BookmarkType = 'sectors' | 'services' | 'products'

export default function BookmarksPage() {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([])
  const [sectors, setSectors] = useState<Record<string, SectorInfo>>({})
  const [services, setServices] = useState<Record<string, ServiceInfo>>({})
  const [products, setProducts] = useState<Record<string, ProductInfo>>({})
  const [loading, setLoading] = useState(true)
  const [removing, setRemoving] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<BookmarkType>('sectors')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/login'); return }

      // Load bookmarks
      const { data: bmarks } = await supabase
        .from('member_bookmarks')
        .select('id, sector_id, service_id, product_id, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      const allBookmarks = bmarks || []
      setBookmarks(allBookmarks)

      // Resolve sector names
      const sectorIds = [...new Set(allBookmarks.map(b => b.sector_id).filter(Boolean))] as string[]
      if (sectorIds.length > 0) {
        const { data } = await supabase.from('sectors').select('id, name, slug, description').in('id', sectorIds)
        if (data) setSectors(Object.fromEntries(data.map(s => [s.id, s])))
      }

      // Resolve service names
      const serviceIds = [...new Set(allBookmarks.map(b => b.service_id).filter(Boolean))] as string[]
      if (serviceIds.length > 0) {
        const { data } = await supabase.from('services').select('id, name, slug, description').in('id', serviceIds)
        if (data) setServices(Object.fromEntries(data.map(s => [s.id, s])))
      }

      // Resolve product names
      const productIds = [...new Set(allBookmarks.map(b => b.product_id).filter(Boolean))] as string[]
      if (productIds.length > 0) {
        const { data } = await supabase.from('products').select('id, name, slug, description, sector_id, service_id').in('id', productIds)
        if (data) setProducts(Object.fromEntries(data.map(p => [p.id, p])))
      }

      setLoading(false)
    }
    load()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  async function removeBookmark(bookmarkId: string) {
    setRemoving(bookmarkId)
    await supabase.from('member_bookmarks').delete().eq('id', bookmarkId)
    setBookmarks(prev => prev.filter(b => b.id !== bookmarkId))
    setRemoving(null)
  }

  const sectorBookmarks = bookmarks.filter(b => b.sector_id)
  const serviceBookmarks = bookmarks.filter(b => b.service_id)
  const productBookmarks = bookmarks.filter(b => b.product_id)

  const tabs: { key: BookmarkType; label: string; count: number }[] = [
    { key: 'sectors', label: 'Sectors', count: sectorBookmarks.length },
    { key: 'services', label: 'Services', count: serviceBookmarks.length },
    { key: 'products', label: 'Products', count: productBookmarks.length },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-czaah-muted">Loading...</div>
      </div>
    )
  }

  return (
    <>
      <div className="mb-6">
        <h1 className="font-[family-name:var(--font-heading)] text-2xl text-czaah-white">
          Bookmarks
        </h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-1.5 rounded text-sm whitespace-nowrap transition-colors ${
              activeTab === tab.key
                ? 'bg-czaah-gold text-czaah-black font-semibold'
                : 'bg-czaah-card border border-czaah-border text-czaah-muted hover:text-czaah-white'
            }`}
          >
            {tab.label} ({tab.count})
          </button>
        ))}
      </div>

      {/* Bookmark list */}
      <div className="bg-czaah-card border border-czaah-border rounded-lg">
        {activeTab === 'sectors' && (
          sectorBookmarks.length === 0 ? (
            <EmptyState message="No sector bookmarks yet." browseHref="/sectors" browseLabel="Browse Sectors" />
          ) : (
            <div className="divide-y divide-czaah-border">
              {sectorBookmarks.map((b) => {
                const sector = b.sector_id ? sectors[b.sector_id] : null
                return (
                  <BookmarkRow
                    key={b.id}
                    name={sector?.name || 'Unknown Sector'}
                    description={sector?.description}
                    href={sector ? `/sectors/${sector.slug}` : '#'}
                    date={b.created_at}
                    removing={removing === b.id}
                    onRemove={() => removeBookmark(b.id)}
                  />
                )
              })}
            </div>
          )
        )}

        {activeTab === 'services' && (
          serviceBookmarks.length === 0 ? (
            <EmptyState message="No service bookmarks yet." browseHref="/sectors" browseLabel="Browse Services" />
          ) : (
            <div className="divide-y divide-czaah-border">
              {serviceBookmarks.map((b) => {
                const service = b.service_id ? services[b.service_id] : null
                return (
                  <BookmarkRow
                    key={b.id}
                    name={service?.name || 'Unknown Service'}
                    description={service?.description}
                    href={service ? `/services/${service.slug}` : '#'}
                    date={b.created_at}
                    removing={removing === b.id}
                    onRemove={() => removeBookmark(b.id)}
                  />
                )
              })}
            </div>
          )
        )}

        {activeTab === 'products' && (
          productBookmarks.length === 0 ? (
            <EmptyState message="No product bookmarks yet." browseHref="/sectors" browseLabel="Browse Products" />
          ) : (
            <div className="divide-y divide-czaah-border">
              {productBookmarks.map((b) => {
                const product = b.product_id ? products[b.product_id] : null
                return (
                  <BookmarkRow
                    key={b.id}
                    name={product?.name || 'Unknown Product'}
                    description={product?.description}
                    href={product ? `/products/${product.slug}` : '#'}
                    date={b.created_at}
                    removing={removing === b.id}
                    onRemove={() => removeBookmark(b.id)}
                  />
                )
              })}
            </div>
          )
        )}
      </div>
    </>
  )
}

function EmptyState({ message, browseHref, browseLabel }: { message: string; browseHref: string; browseLabel: string }) {
  return (
    <div className="px-6 py-16 text-center">
      <p className="text-czaah-muted mb-4">{message}</p>
      <Link
        href={browseHref}
        className="inline-block bg-czaah-gold text-czaah-black font-semibold px-6 py-2.5 rounded hover:bg-czaah-gold/90 transition-colors text-sm"
      >
        {browseLabel} &rarr;
      </Link>
    </div>
  )
}

function BookmarkRow({
  name, description, href, date, removing, onRemove,
}: {
  name: string; description: string | null | undefined; href: string; date: string; removing: boolean; onRemove: () => void
}) {
  return (
    <div className="px-6 py-4 flex items-center justify-between gap-4">
      <div className="min-w-0">
        <Link href={href} className="text-sm font-medium text-czaah-white hover:text-czaah-gold transition-colors">
          {name}
        </Link>
        {description && (
          <p className="text-xs text-czaah-muted-dim mt-1 truncate max-w-md">{description}</p>
        )}
        <p className="text-xs text-czaah-muted-dim mt-1">
          Bookmarked {new Date(date).toLocaleDateString()}
        </p>
      </div>
      <button
        onClick={onRemove}
        disabled={removing}
        className="text-xs text-red-400 hover:text-red-300 transition-colors disabled:opacity-50 shrink-0"
      >
        {removing ? 'Removing...' : 'Remove'}
      </button>
    </div>
  )
}
