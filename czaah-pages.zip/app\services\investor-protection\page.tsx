'use client';
// @ts-nocheck

import { useState, useEffect, useRef } from 'react';
import { Navbar } from '@/components/layouts/Navbar';
import { Footer } from '@/components/layouts/Footer';

interface ProtectionLayer {
  num: string;
  name: string;
  brief: string;
  items: string[];
}

const layers: ProtectionLayer[] = [
  {
    num: '01',
    name: 'Pre-Investment Screening',
    brief: 'Filtering out risk before capital is committed.',
    items: [
      'Market viability assessment and sector analysis',
      'Counterparty background checks (criminal, litigation, financial)',
      'Regulatory environment review for the specific investment type',
      'Sanction screening and AML/KYC compliance verification',
      'Independent reference checks across our institutional network',
      'Red flag identification and go/no-go recommendation'
    ]
  },
  {
    num: '02',
    name: 'Legal Architecture',
    brief: 'Contracts built to protect, not just document.',
    items: [
      'Investment agreements drafted to international standards (English law / DIFC option)',
      'Shareholder agreements with minority protection clauses',
      'Tag-along, drag-along, anti-dilution, and pre-emption rights',
      'Arbitration clauses (LCIA, ICC, or DIFC) for dispute resolution',
      'Escrow arrangements for staged capital deployment',
      'Personal guarantee and security collateral where appropriate'
    ]
  },
  {
    num: '03',
    name: 'Asset Verification',
    brief: 'Confirming that what you\u2019re buying is real.',
    items: [
      'Property title search and ownership chain verification',
      'Land revenue record authentication (Patwari/Revenue Dept)',
      'Physical asset inspection and condition assessment',
      'Encumbrance and lien checks across all relevant registries',
      'Mining license verification with provincial Mines Department',
      'Company registry search (SECP) for corporate assets'
    ]
  },
  {
    num: '04',
    name: 'Financial Governance',
    brief: 'Institutional-grade oversight of your capital.',
    items: [
      'Independent board representation or observer rights',
      'Ring-fenced SPV structures isolating deal-specific risk',
      'Dedicated bank accounts with dual-signatory controls',
      'Quarterly financial reporting to international accounting standards',
      'Annual independent audit by Big 4 or equivalent firm',
      'Capital call and distribution waterfall management'
    ]
  },
  {
    num: '05',
    name: 'Ongoing Monitoring',
    brief: 'Continuous vigilance throughout the investment lifecycle.',
    items: [
      'Monthly operational updates and KPI tracking',
      'Regular site visits and physical inspection (real assets)',
      'Regulatory compliance monitoring and filing management',
      'Market condition tracking and risk reassessment',
      'Partner/counterparty ongoing due diligence',
      'Early warning system for material adverse changes'
    ]
  },
  {
    num: '06',
    name: 'Exit Protection',
    brief: 'Defined mechanisms for capital recovery.',
    items: [
      'Pre-agreed exit mechanisms in every investment structure',
      'Put options and buyback arrangements at defined triggers',
      'Secondary market facilitation for equity positions',
      'Profit repatriation structuring (SBP compliance)',
      'Tax-efficient exit planning across multiple jurisdictions',
      'Liquidation preference and waterfall protections'
    ]
  }
];

export default function InvestorProtectionPage() {
  const [expandedLayers, setExpandedLayers] = useState<Set<number>>(new Set());
  const [visibleLayers, setVisibleLayers] = useState<Set<number>>(new Set());
  const frameworkRef = useRef<HTMLDivElement>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('visible');
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach(el => {
      observerRef.current?.observe(el);
    });

    return () => observerRef.current?.disconnect();
  }, []);

  useEffect(() => {
    if (!frameworkRef.current) return;
    const fwObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          layers.forEach((_, i) => {
            setTimeout(() => {
              setVisibleLayers(prev => new Set(prev).add(i));
            }, i * 120);
          });
          fwObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    fwObserver.observe(frameworkRef.current);
    return () => fwObserver.disconnect();
  }, []);

  const toggleLayer = (index: number) => {
    setExpandedLayers(prev => {
      const next = new Set(prev);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      return next;
    });
  };

  return (
    <>
      <Navbar />
      <div className="page-wrap">

        <div className="v-hero-wrapper" style={{ backgroundImage: "url('/Images/Investor-Protection.jpg')" }}>
          <section className="v-hero">
            <div className="v-hero-text">
              <a href="/" className="back-link hero-enter">&larr; Back to Overview</a>
              <span className="gold-line hero-enter"></span>
              <div className="label hero-enter hero-enter-delay-1">Risk &amp; Protection</div>
              <h1 className="serif hero-enter hero-enter-delay-2">Investor<br /><span className="gold">Protection.</span></h1>
              <p className="hero-enter hero-enter-delay-3">Protecting international investors through comprehensive due diligence, legal safeguards, transparent reporting, and risk management — ensuring every investment in Pakistan is secure, verified, and properly structured.</p>
              <a href="/contact?interest=Investor%20Protection#contact-form" className="btn-gold hero-enter hero-enter-delay-4">Protect Your Investment &rarr;</a>
            </div>
          </section>
        </div>

        <div className="divider"></div>

        {/* PROTECTION FRAMEWORK */}
        <section className="section fade-in">
          <h2 className="serif">Protection <span className="gold">framework.</span></h2>
          <p className="subtitle">Six layers of institutional-grade protection — from initial screening through to exit. Click any layer to explore.</p>

          <style>{`
            .ip-framework { display: flex; flex-direction: column; gap: 0; margin-top: 3rem; }
            .ip-layer {
              border: 1px solid var(--black-border); background: var(--black-card); margin-bottom: -1px;
              opacity: 0; transform: translateX(-40px);
              transition: opacity 0.5s var(--ease-smooth), transform 0.5s var(--ease-smooth);
            }
            .ip-layer.ip-visible { opacity: 1; transform: translateX(0); }
            .ip-layer:first-child { border-radius: 8px 8px 0 0; }
            .ip-layer:last-child { border-radius: 0 0 8px 8px; }
            .ip-layer-header {
              display: flex; align-items: center; gap: 1.5rem; padding: 1.25rem 1.75rem;
              cursor: pointer; position: relative; transition: background 0.3s var(--ease-smooth);
            }
            .ip-layer-header:hover { background: var(--black-elevated); }
            .ip-layer-bar {
              position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
              border-radius: 4px 0 0 0; transition: width 0.3s var(--ease-smooth);
            }
            .ip-layer:nth-child(1) .ip-layer-bar { background: rgba(201,168,76,0.3); }
            .ip-layer:nth-child(2) .ip-layer-bar { background: rgba(201,168,76,0.45); }
            .ip-layer:nth-child(3) .ip-layer-bar { background: rgba(201,168,76,0.58); }
            .ip-layer:nth-child(4) .ip-layer-bar { background: rgba(201,168,76,0.72); }
            .ip-layer:nth-child(5) .ip-layer-bar { background: rgba(201,168,76,0.86); }
            .ip-layer:nth-child(6) .ip-layer-bar { background: var(--gold); }
            .ip-layer:nth-child(1) { margin-left: 0; }
            .ip-layer:nth-child(2) { margin-left: 0.5rem; }
            .ip-layer:nth-child(3) { margin-left: 1rem; }
            .ip-layer:nth-child(4) { margin-left: 1.5rem; }
            .ip-layer:nth-child(5) { margin-left: 2rem; }
            .ip-layer:nth-child(6) { margin-left: 2.5rem; }
            .ip-layer-num {
              font-family: 'Raleway', sans-serif; font-weight: 600; font-size: 0.75rem;
              color: var(--gold); letter-spacing: 0.05em; min-width: 2rem;
            }
            .ip-layer-info { flex: 1; }
            .ip-layer-name {
              font-family: 'Cinzel', serif; font-size: 1.15rem; font-weight: 600;
              color: var(--white); margin-bottom: 0.15rem;
            }
            .ip-layer-brief { font-size: 0.875rem; color: var(--white-muted); font-style: italic; }
            .ip-layer-arrow {
              font-size: 1.25rem; color: var(--white-dim);
              transition: transform 0.3s var(--ease-smooth), color 0.3s; flex-shrink: 0;
            }
            .ip-layer.ip-expanded .ip-layer-arrow { transform: rotate(180deg); color: var(--gold); }
            .ip-layer-content {
              max-height: 0; overflow: hidden; opacity: 0;
              transition: max-height 0.45s var(--ease-smooth), opacity 0.35s var(--ease-smooth), padding 0.35s var(--ease-smooth);
              padding: 0 1.75rem 0 5rem;
            }
            .ip-layer.ip-expanded .ip-layer-content {
              max-height: 500px; opacity: 1; padding: 0 1.75rem 1.5rem 5rem;
            }
            .ip-layer-content p {
              font-size: 0.9rem; color: var(--white-muted); margin-bottom: 1rem; line-height: 1.6;
            }
            .ip-layer-content ul {
              list-style: none; padding: 0; margin: 0; display: grid;
              grid-template-columns: 1fr 1fr; gap: 0.6rem 2rem;
            }
            .ip-layer-content ul li {
              font-size: 0.85rem; color: var(--white-dim); padding-left: 1.25rem;
              position: relative; line-height: 1.5;
            }
            .ip-layer-content ul li::before {
              content: ''; position: absolute; left: 0; top: 0.5em; width: 6px; height: 6px;
              border-radius: 50%; background: var(--gold-dim);
            }
            .ip-layer-content .ip-deliverable-label {
              font-size: 0.75rem; font-weight: 600; color: var(--gold);
              letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 0.75rem; margin-top: 0.25rem;
            }
            .ip-layer.ip-expanded { background: var(--black-elevated); }
            .ip-layer.ip-expanded .ip-layer-name { color: var(--gold); }
            @media (max-width: 768px) {
              .ip-layer:nth-child(1), .ip-layer:nth-child(2), .ip-layer:nth-child(3),
              .ip-layer:nth-child(4), .ip-layer:nth-child(5), .ip-layer:nth-child(6) { margin-left: 0; }
              .ip-layer-header { gap: 1rem; padding: 1rem 1.25rem; }
              .ip-layer-content { padding: 0 1.25rem 0 3.75rem; }
              .ip-layer.ip-expanded .ip-layer-content { padding: 0 1.25rem 1.25rem 3.75rem; }
              .ip-layer-content ul { grid-template-columns: 1fr; }
              .ip-layer-name { font-size: 1rem; }
              .ip-layer-brief { font-size: 0.8rem; }
            }
          `}</style>

          <div className="ip-framework" ref={frameworkRef}>
            {layers.map((layer, i) => (
              <div
                key={i}
                className={`ip-layer${visibleLayers.has(i) ? ' ip-visible' : ''}${expandedLayers.has(i) ? ' ip-expanded' : ''}`}
              >
                <div className="ip-layer-header" onClick={() => toggleLayer(i)}>
                  <div className="ip-layer-bar"></div>
                  <div className="ip-layer-num">{layer.num}</div>
                  <div className="ip-layer-info">
                    <div className="ip-layer-name">{layer.name}</div>
                    <div className="ip-layer-brief">{layer.brief}</div>
                  </div>
                  <div className="ip-layer-arrow">&#9662;</div>
                </div>
                <div className="ip-layer-content">
                  <div className="ip-deliverable-label">Deliverables</div>
                  <ul>
                    {layer.items.map((item, j) => (
                      <li key={j}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="divider"></div>

        {/* SERVICES */}
        <section className="section fade-in">
          <h2 className="serif">Our <span className="gold">services.</span></h2>
          <p className="subtitle">Comprehensive investor protection — from pre-investment due diligence through to ongoing monitoring and defined exit strategies.</p>

          <div className="detail-grid stagger">
            <div className="detail-card">
              <div className="card-icon">&#9670;</div>
              <h3>Investment Due Diligence</h3>
              <p>Asset verification, financial analysis, background checks on partners and projects. We ensure every aspect of your investment is thoroughly investigated before capital is deployed.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9632;</div>
              <h3>Legal Safeguards</h3>
              <p>Investor-protecting contracts, shareholder agreements, dispute resolution mechanisms. Our legal frameworks are built to international standards and enforced through Pakistani and international jurisdictions.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#10003;</div>
              <h3>Title &amp; Asset Verification</h3>
              <p>Property title verification, asset authentication, ownership chain validation. We confirm that what you&apos;re investing in is real, legally clean, and free from encumbrances.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9881;</div>
              <h3>Financial Reporting</h3>
              <p>Regular investment reports, independent valuations, performance tracking. You receive transparent, auditable updates on every investment — no surprises, no opacity.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#9733;</div>
              <h3>Insurance Facilitation</h3>
              <p>Investment insurance, political risk coverage, asset protection policies. We connect you with the right insurers to protect against unforeseen risks across all asset classes.</p>
            </div>
            <div className="detail-card">
              <div className="card-icon">&#8644;</div>
              <h3>Exit Mechanisms</h3>
              <p>Defined exit strategies, buyback arrangements, secondary market facilitation. Every investment we structure includes clear, pre-agreed mechanisms for capital recovery.</p>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* STATS */}
        <section className="section section-center fade-in-scale">
          <h2 className="serif">Investor protection <span className="gold">at a glance.</span></h2>
          <div className="stats-row stagger">
            <div className="stat-item">
              <div className="number">100%</div>
              <div className="label">Due diligence completion</div>
            </div>
            <div className="stat-item">
              <div className="number">Legal</div>
              <div className="label">International-grade contracts</div>
            </div>
            <div className="stat-item">
              <div className="number">Quarterly</div>
              <div className="label">Reporting cycle</div>
            </div>
            <div className="stat-item">
              <div className="number">Defined</div>
              <div className="label">Exit mechanisms</div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        {/* WHY CZAAH */}
        <section className="section fade-in">
          <h2 className="serif">Why <span className="gold">CZAAH.</span></h2>
          <p className="subtitle">International investors trust CZAAH because we combine local intelligence with institutional-grade protection frameworks.</p>

          <div className="relationships stagger">
            <div className="rel-card">
              <div className="rel-icon">&#9670;</div>
              <div>
                <h4>Local Intelligence</h4>
                <p>Deep on-the-ground knowledge of Pakistan&apos;s regulatory, legal, and commercial landscape. We identify risks that remote due diligence simply cannot uncover — protecting you from hidden exposures.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9632;</div>
              <div>
                <h4>Legal Expertise</h4>
                <p>Access to Pakistan&apos;s leading commercial law firms and international arbitration specialists. Our contracts are drafted to protect investor interests across multiple jurisdictions and enforcement regimes.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#9733;</div>
              <div>
                <h4>Transparent Reporting</h4>
                <p>No opacity, no guesswork. Every investment is tracked through independent valuations, auditable financial reports, and regular performance updates — delivered to international reporting standards.</p>
              </div>
            </div>
            <div className="rel-card">
              <div className="rel-icon">&#8644;</div>
              <div>
                <h4>Proven Track Record</h4>
                <p>A portfolio of successfully protected investments across minerals, real estate, technology, and trade. Our investors receive the confidence that comes from rigorous process and demonstrated results.</p>
              </div>
            </div>
          </div>
        </section>

        <div className="divider"></div>

        <section className="cta-banner fade-in">
          <h2 className="serif">Deploy capital with <span className="gold">certainty.</span></h2>
          <p>Due diligence, legal frameworks, transparent reporting, and defined exit mechanisms &mdash; institutional-grade investor protection.</p>
          <a href="/contact?interest=Investor%20Protection#contact-form" className="btn-gold">Request a Consultation &rarr;</a>
        </section>

      </div>
      <Footer />
    </>
  );
}
