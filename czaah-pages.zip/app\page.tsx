'use client'
// @ts-nocheck

import Link from 'next/link'
import { useEffect, useRef, useState, useCallback } from 'react'
import { Navbar } from '@/components/layouts/Navbar'
import { Footer } from '@/components/layouts/Footer'

/* ------------------------------------------------------------------ */
/*  Data                                                               */
/* ------------------------------------------------------------------ */

const sectorCards = [
  { name: 'Minerals & Mining', icon: '\u25C6', description: 'Access Pakistan\'s $1T+ in untapped mineral reserves \u2014 copper, gold, rare earths, coal, and gemstones across Balochistan, KPK, and Gilgit-Baltistan.', tag: '$1T+ Reserves', slug: 'minerals' },
  { name: 'Real Estate', icon: '\u2302', description: 'Invest in Pakistan\'s highest-growth corridors \u2014 CPEC zones, commercial hubs, and industrial real estate with structured, transparent investment vehicles.', tag: 'CPEC Corridor', slug: 'realestate' },
  { name: 'Construction & Development', icon: '\u26E8', description: 'Civil infrastructure, commercial buildings, CPEC corridor projects, and Special Economic Zone development with trusted construction partners.', tag: 'Infrastructure', slug: 'construction' },
  { name: 'Technology & IT', icon: '\u2699', description: 'Enter Pakistan\'s $3.2B+ IT sector \u2014 government digital transformation partnerships and access to 500,000+ skilled technology professionals.', tag: '$3.2B+ Sector', slug: 'technology' },
  { name: 'Textiles & Trade', icon: '\u2756', description: 'Source from the world\'s 4th largest textile exporter \u2014 certified, compliant, and competitively priced. Denim, knitwear, home textiles, and sportswear.', tag: '4th Global Exporter', slug: 'textiles' },
  { name: 'Agriculture', icon: '\u2618', description: 'Pakistan\'s agricultural sector accounts for 23% of GDP. Large-scale farming, organic food production, and food processing \u2014 vast fertile land and growing export demand.', tag: '23% of GDP', slug: 'agriculture' },
  { name: 'Pharmaceuticals', icon: '\u2624', description: 'A $4B+ market growing at 12% annually. Medicine production, medical supply chains, and healthcare manufacturing with access to 230M+ domestic consumers.', tag: '$4B+ Market', slug: 'pharmaceuticals' },
  { name: 'Engineering & Energy', icon: '\u2692', description: 'HVAC systems, elevators, escalators, power generation, civil works, solar panels, and industrial air conditioning solutions across Pakistan.', tag: '8 Disciplines', slug: 'engineering' },
  { name: 'Aviation', icon: '\u2708', description: 'Premium private charter and executive transport across Pakistan. Corporate travel, site access flights, medical evacuation, and VIP delegation logistics.', tag: 'Private Charter', slug: 'aviation' },
  { name: 'Human Resources', icon: '\u265F', description: 'Access Pakistan\'s 70M+ workforce \u2014 overseas manpower deployment, domestic staffing, executive search, trade testing, and HR advisory services.', tag: '70M+ Workforce', slug: 'manpower' },
  { name: 'Tourism & Hospitality', icon: '\u2702', description: 'Luxury hotel investment, destination management, and adventure expeditions across the Karakoram, Hindukush, and Pakistan\'s ancient heritage sites.', tag: 'Destination Mgmt', slug: 'tourism' },
  { name: 'Luxury Car Rentals', icon: '\u2605', description: 'Premium executive chauffeur services, armoured transport, corporate fleet management, and VIP delegation logistics across Pakistan.', tag: 'Executive Fleet', slug: 'luxury-rentals' },
  { name: 'Education', icon: '\u270E', description: 'University partnerships, campus development, vocational training, and EdTech deployment across Pakistan\'s $8B+ education market.', tag: '230M Population', slug: 'education' },
] as const

const serviceCards = [
  { icon: '\u25C6', model: 'Setup & Registration', title: 'Business Setup', description: 'Company registration through SECP, corporate structuring, legal documentation, and entity formation for foreign and overseas investors.', slug: 'business-setup' },
  { icon: '\u25A0', model: 'Government & Regulatory', title: 'Licensing & Compliance', description: 'Assistance with FBR registration, Board of Investment approvals, industry licensing, and provincial regulatory requirements.', slug: 'licensing' },
  { icon: '\u21C4', model: 'International Trade', title: 'Import & Export', description: 'Trade documentation, customs clearance, global supplier connections, and export management through our international trade network.', slug: 'import-export' },
  { icon: '\u2605', model: 'Risk & Protection', title: 'Investor Protection', description: 'Legal contracts, project verification, investment due diligence, insurance facilitation, and transparent financial reporting at every stage.', slug: 'investor-protection' },
  { icon: '$', model: 'Strategy & Analysis', title: 'Investment Advisory', description: 'Feasibility studies, market opportunity mapping, financial modelling, and strategic guidance for verified investment opportunities across all sectors.', slug: 'investment-advisory' },
  { icon: '+', model: 'Local Expertise', title: 'Partnership Development', description: 'Connection with government departments, legal experts, developers, financial institutions, and industrial partners for safe, transparent investment.', slug: 'partnership-development' },
] as const

const verticals = [
  { num: '01', name: 'Minerals & Mining', model: 'Advisory \u00B7 Access \u00B7 Deal Structuring', description: 'Navigate Pakistan\'s complex mining regulatory landscape. We facilitate exploration licensing, joint ventures, and connect producers with international buyers.', slug: 'minerals', coreFocus: true },
  { num: '02', name: 'Real Estate', model: 'CPEC \u00B7 Commercial \u00B7 Industrial', description: 'Invest in Pakistan\'s highest-growth corridors \u2014 CPEC Special Economic Zones, commercial hubs, and industrial properties with structured, transparent vehicles.', slug: 'realestate', coreFocus: true },
  { num: '03', name: 'Technology & IT', model: 'Market Entry \u00B7 Talent \u00B7 Digital', description: 'Enter Pakistan\'s booming tech sector \u2014 government IT partnerships for enterprise vendors, and access to 500,000+ skilled professionals for global firms.', slug: 'technology', coreFocus: false },
  { num: '04', name: 'Textiles & Trade', model: 'Sourcing \u00B7 Compliance \u00B7 Export', description: 'Source certified Pakistani textiles for EU, US, and Gulf markets. Full compliance handling \u2014 OEKO-TEX, GOTS, Better Cotton \u2014 with GSP+ zero-duty EU access.', slug: 'textiles', coreFocus: false },
  { num: '05', name: 'Agriculture', model: 'Farming \u00B7 Organic \u00B7 Processing', description: 'Pakistan\'s agricultural sector is 23% of GDP with massive modernisation potential. Large-scale farming, organic food production, and cold chain infrastructure.', slug: 'agriculture', coreFocus: false },
  { num: '06', name: 'Pharmaceuticals', model: 'Manufacturing \u00B7 Healthcare \u00B7 Export', description: 'A $4B+ market growing at 12% annually. Generic drug manufacturing, API production, and healthcare infrastructure with access to 230M+ consumers.', slug: 'pharmaceuticals', coreFocus: false },
  { num: '07', name: 'Construction & Development', model: 'Infrastructure \u00B7 Commercial \u00B7 CPEC', description: 'Civil infrastructure, commercial buildings, CPEC corridor projects, and Special Economic Zone development with trusted construction partners.', slug: 'construction', coreFocus: true },
  { num: '08', name: 'Engineering & Energy', model: 'HVAC \u00B7 Solar \u00B7 Power \u00B7 Civil', description: 'Comprehensive engineering services \u2014 HVAC, elevators, escalators, power generation, civil works, solar panels, and industrial air conditioning solutions.', slug: 'engineering', coreFocus: false },
  { num: '09', name: 'Aviation', model: 'Charter \u00B7 Logistics \u00B7 Executive', description: 'Premium private charter and executive transport across Pakistan and the Gulf. Site access flights, medical evacuation, and VIP delegation logistics.', slug: 'aviation', coreFocus: false },
  { num: '10', name: 'Human Resources', model: 'Staffing \u00B7 Recruitment \u00B7 Deployment', description: 'Access Pakistan\'s 70M+ workforce \u2014 overseas manpower deployment, domestic staffing, executive search, trade testing, and comprehensive HR advisory services.', slug: 'manpower', coreFocus: false },
  { num: '11', name: 'Tourism & Hospitality', model: 'Hotels \u00B7 Travel \u00B7 Adventure', description: 'Luxury hotel investment, destination management, and adventure expeditions across the Karakoram, Hindukush, and Pakistan\'s ancient heritage sites.', slug: 'tourism', coreFocus: false },
  { num: '12', name: 'Luxury Car Rentals', model: 'Executive \u00B7 Armoured \u00B7 Fleet', description: 'Premium executive chauffeur services, armoured transport, corporate fleet management, and VIP delegation logistics across Pakistan.', slug: 'luxury-rentals', coreFocus: false },
  { num: '13', name: 'Education', model: 'Universities \u00B7 EdTech \u00B7 Vocational', description: 'University partnerships, campus development, vocational training, and EdTech deployment for investors entering Pakistan\'s $8B+ education market.', slug: 'education', coreFocus: false },
] as const

const sectorIcons = [
  { key: 'minerals', icon: '\u25C6', label: 'Minerals' },
  { key: 'realestate', icon: '\u2302', label: 'Real Estate' },
  { key: 'technology', icon: '\u2699', label: 'Technology' },
  { key: 'textiles', icon: '\u2756', label: 'Textiles' },
  { key: 'agriculture', icon: '\u2618', label: 'Agriculture' },
  { key: 'pharmaceuticals', icon: '\u2624', label: 'Pharma' },
  { key: 'construction', icon: '\u26E8', label: 'Construction' },
  { key: 'engineering', icon: '\u2692', label: 'Engineering' },
  { key: 'aviation', icon: '\u2708', label: 'Aviation' },
  { key: 'manpower', icon: '\u265F', label: 'HR' },
  { key: 'tourism', icon: '\u2702', label: 'Tourism' },
  { key: 'luxuryrentals', icon: '\u2605', label: 'Luxury Cars' },
  { key: 'education', icon: '\u270E', label: 'Education' },
] as const

const sectorSnippetData: Record<string, { title: string; text: string; link: string }> = {
  minerals: {
    title: 'Minerals & Mining',
    text: 'Pakistan holds an estimated $1 trillion+ in untapped mineral reserves \u2014 copper, gold, rare earths, coal, and gemstones across Balochistan, KPK, and Gilgit-Baltistan. CZAAH facilitates exploration licensing, joint ventures, and connects producers with international buyers.',
    link: '/sectors/minerals',
  },
  realestate: {
    title: 'Real Estate',
    text: 'Pakistan\'s $300B+ real estate market is being reshaped by CPEC. We provide structured, transparent access to commercial and industrial properties in Special Economic Zones \u2014 with 6-8% rental yields and significant appreciation potential.',
    link: '/sectors/realestate',
  },
  textiles: {
    title: 'Textiles & Trade',
    text: 'The world\'s 4th largest textile exporter. CZAAH connects international buyers with Pakistan\'s vast manufacturing base \u2014 denim, knitwear, home textiles, sportswear \u2014 fully certified, quality-assured, with GSP+ zero-duty EU access.',
    link: '/sectors/textiles',
  },
  technology: {
    title: 'Technology & IT',
    text: 'Pakistan\'s $3.2B+ IT export sector is growing at 25%+ annually. We facilitate government digital transformation partnerships for enterprise vendors and provide access to 500,000+ skilled technology professionals.',
    link: '/sectors/technology',
  },
  agriculture: {
    title: 'Agriculture',
    text: 'Accounting for 23% of GDP with vast fertile land, Pakistan\'s agricultural sector offers compelling opportunities in large-scale farming, organic food production, cold chain infrastructure, and food processing for export.',
    link: '/sectors/agriculture',
  },
  pharmaceuticals: {
    title: 'Pharmaceuticals',
    text: 'A $4B+ market growing at 12% annually with 800+ licensed manufacturers. CZAAH facilitates market entry partnerships in generic drug manufacturing, API production, and healthcare infrastructure.',
    link: '/sectors/pharmaceuticals',
  },
  aviation: {
    title: 'Aviation',
    text: 'Premium private charter and executive transport across Pakistan and the Gulf. Corporate travel, remote site access flights, medical evacuation, and VIP delegation logistics \u2014 on your schedule.',
    link: '/sectors/aviation',
  },
  manpower: {
    title: 'Human Resources',
    text: 'Pakistan\'s 70M+ workforce is one of the world\'s largest. CZAAH facilitates overseas manpower deployment, domestic staffing solutions, executive search, trade testing, and HR advisory for international employers.',
    link: '/sectors/manpower',
  },
  construction: {
    title: 'Construction & Development',
    text: 'Civil infrastructure, commercial buildings, CPEC corridor projects, and Special Economic Zone development. Full project facilitation from planning through execution with trusted construction partners.',
    link: '/sectors/construction',
  },
  engineering: {
    title: 'Engineering & Energy',
    text: 'Comprehensive engineering services including HVAC systems, elevator and escalator installation, power generation, civil works, solar panel deployment, and industrial air conditioning solutions across Pakistan.',
    link: '/sectors/engineering',
  },
  tourism: {
    title: 'Tourism & Hospitality',
    text: 'Pakistan\'s tourism sector is experiencing rapid growth \u2014 from luxury hotel investment and destination management to adventure expeditions across the Karakoram, Hindukush, and ancient heritage sites.',
    link: '/sectors/tourism',
  },
  luxuryrentals: {
    title: 'Luxury Car Rentals',
    text: 'Premium executive chauffeur services, armoured transport, corporate fleet management, and VIP delegation logistics \u2014 ensuring secure, first-class ground transportation across Pakistan.',
    link: '/sectors/luxury-rentals',
  },
  education: {
    title: 'Education',
    text: 'Pakistan\'s youngest demographic in its history meets the largest education infrastructure gap in South Asia. CZAAH facilitates university partnerships, campus development, vocational training, and EdTech deployment for international education investors.',
    link: '/sectors/education',
  },
}

const statsData = [
  { flag: 'https://flagcdn.com/w80/pk.png', alt: 'Pakistan', name: 'Pakistan', label: 'Headquarters & on-the-ground operations across Pakistan' },
  { flag: 'https://flagcdn.com/w80/gb.png', alt: 'United Kingdom', name: 'United Kingdom', label: 'European investor relations & capital partnerships' },
  { flag: 'https://flagcdn.com/w80/eu.png', alt: 'European Union', name: 'Europe', label: 'GSP+ trade access & institutional investor network' },
  { flag: 'https://flagcdn.com/w80/cn.png', alt: 'China', name: 'Asia', label: 'CPEC partnerships & cross-border trade facilitation' },
  { flag: 'https://flagcdn.com/w80/sa.png', alt: 'Saudi Arabia', name: 'Middle East', label: 'Gulf capital partnerships & commodities trading network' },
  { flag: 'https://flagcdn.com/w80/us.png', alt: 'USA', name: 'USA', label: 'Diaspora investment & technology sector partnerships' },
] as const

const testimonials = [
  { quote: 'CZAAH navigated the entire SECP registration and BOI approval process for our Pakistan subsidiary in under three weeks. Their regulatory relationships saved us months of delays.', author: 'Senior Partner', role: 'Gulf-based Investment Fund' },
  { quote: 'We needed a trusted local partner to evaluate mining opportunities in Balochistan. CZAAH\'s on-the-ground expertise and government access gave us the confidence to commit capital.', author: 'Director of Operations', role: 'International Mining Company' },
  { quote: 'As overseas Pakistanis, finding transparent, structured real estate investment access was impossible \u2014 until CZAAH. Their institutional structure gave us the security we needed.', author: 'Private Investor', role: 'UK-based Diaspora HNWI' },
  { quote: 'CZAAH\'s cross-party political coverage means our investments are protected regardless of which government is in power. That level of continuity is unmatched in Pakistan.', author: 'Managing Director', role: 'Saudi Family Office' },
  { quote: 'Their team secured our textile export documentation and FBR duty rebates faster than any agent we\'ve worked with. The connections they have in customs are extraordinary.', author: 'Head of Sourcing', role: 'European Fashion House' },
  { quote: 'We were evaluating IT outsourcing in Pakistan but had no local visibility. CZAAH vetted three development firms, structured the contracts, and handled all compliance. Seamless.', author: 'CTO', role: 'US-based SaaS Company' },
  { quote: 'The aviation logistics CZAAH arranged for our site inspection across three provinces was flawless. It turned a two-week trip into four days and impressed our entire board.', author: 'VP of Development', role: 'Chinese Infrastructure Firm' },
  { quote: 'What sets CZAAH apart is their institutional discipline. Clean documentation, transparent reporting, and a compliance standard you rarely see in frontier markets.', author: 'Portfolio Manager', role: 'London-based PE Fund' },
] as const

const filterTabsData = [
  { label: 'All', query: 'Pakistan investment business economy' },
  { label: 'Mining', query: 'Pakistan mining minerals Reko Diq' },
  { label: 'CPEC', query: 'CPEC Pakistan China corridor' },
  { label: 'Real Estate', query: 'Pakistan real estate property' },
  { label: 'Technology', query: 'Pakistan technology IT exports' },
  { label: 'Textiles', query: 'Pakistan textile exports trade' },
  { label: 'Economy', query: 'Pakistan stock market PSX economy' },
] as const

const partnerNames = ['Sovereign Funds', 'Chinese SOEs', 'Gulf Family Offices', 'Mining Corporates', 'Diaspora HNWIs', 'Global Tech Firms'] as const

const chartBarHeights = ['30%', '50%', '40%', '70%', '55%', '80%', '65%', '90%', '75%', '95%', '85%', '100%']

/* ------------------------------------------------------------------ */
/*  News Types & Helpers                                               */
/* ------------------------------------------------------------------ */

interface NewsArticle {
  title: string
  description?: string
  url: string
  urlToImage?: string
  publishedAt: string
  source?: { name: string }
}

function formatNewsDate(dateStr: string) {
  const d = new Date(dateStr)
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  return months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear()
}

function truncateText(str: string, len: number) {
  const clean = str.replace(/<[^>]*>/g, '')
  return clean.length > len ? clean.substring(0, len) + '...' : clean
}

/* ------------------------------------------------------------------ */
/*  Page Component                                                     */
/* ------------------------------------------------------------------ */

export default function HomePage() {
  const cardsTrackRef = useRef<HTMLDivElement>(null)
  const [activeSector, setActiveSector] = useState<string | null>(null)
  const [sectorSnippet, setSectorSnippet] = useState<{ title: string; text: string; link: string } | null>(null)
  const [snippetVisible, setSnippetVisible] = useState(true)

  // News state
  const [newsArticles, setNewsArticles] = useState<NewsArticle[]>([])
  const [currentSlide, setCurrentSlide] = useState(0)
  const [newsLoading, setNewsLoading] = useState(true)
  const [newsError, setNewsError] = useState(false)
  const [activeFilter, setActiveFilter] = useState(0)
  const [slideDirection, setSlideDirection] = useState<number | null>(null)
  const [slideAnimating, setSlideAnimating] = useState(false)

  // Scroll cards
  const scrollCards = (dir: number) => {
    if (cardsTrackRef.current) {
      cardsTrackRef.current.scrollBy({ left: dir * 300, behavior: 'smooth' })
    }
  }

  // Sector icon click
  const showSector = (key: string) => {
    const data = sectorSnippetData[key]
    if (!data) return
    setActiveSector(key)
    setSnippetVisible(false)
    setTimeout(() => {
      setSectorSnippet(data)
      setSnippetVisible(true)
    }, 300)
  }

  // News fetching
  const fetchNews = useCallback(async (query: string) => {
    setNewsLoading(true)
    setNewsError(false)
    setNewsArticles([])
    setCurrentSlide(0)

    const WORKER_URL = 'https://czaah-news.czaah-news.workers.dev'

    try {
      const response = await fetch(WORKER_URL + '?q=' + encodeURIComponent(query))
      const data = await response.json()
      if (data.status !== 'ok' || !data.articles || data.articles.length === 0) {
        throw new Error('No articles')
      }
      setNewsArticles(data.articles)
      setNewsLoading(false)
    } catch {
      // Fallback: use backend proxy for NewsAPI
      try {
        const response = await fetch('/api/public/news?q=' + encodeURIComponent(query) + '&pageSize=8')
        const data = await response.json()
        if (data.status === 'ok' && data.articles && data.articles.length > 0) {
          setNewsArticles(data.articles)
          setNewsLoading(false)
          return
        }
      } catch {
        // ignore
      }
      setNewsError(true)
      setNewsLoading(false)
    }
  }, [])

  const changeSlide = (direction: number) => {
    const newIndex = currentSlide + direction
    if (newIndex < 0 || newIndex >= newsArticles.length || slideAnimating) return
    setSlideAnimating(true)
    setSlideDirection(direction)
    setTimeout(() => {
      setCurrentSlide(newIndex)
      setSlideDirection(null)
      setSlideAnimating(false)
    }, 300)
  }

  // Fetch news on mount
  useEffect(() => {
    fetchNews('Pakistan investment business economy')
  }, [fetchNews])

  // Intersection Observer for scroll animations
  useEffect(() => {
    const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible')

          // Animate showcase bars
          entry.target.querySelectorAll<HTMLElement>('.showcase-bar-fill[data-width]').forEach((bar, i) => {
            setTimeout(() => {
              bar.style.width = bar.dataset.width || '0%'
              bar.classList.add('animated')
            }, 200 + i * 200)
          })

          // Animate chart bars
          entry.target.querySelectorAll('.chart-bar').forEach((bar, i) => {
            setTimeout(() => {
              bar.classList.add('animated')
            }, 300 + i * 60)
          })
        }
      })
    }, observerOptions)

    document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right, .fade-in-scale, .stagger').forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  // Keyboard navigation for news
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') changeSlide(-1)
      if (e.key === 'ArrowRight') changeSlide(1)
    }
    document.addEventListener('keydown', handleKey)
    return () => document.removeEventListener('keydown', handleKey)
  })

  const currentArticle = newsArticles[currentSlide]

  return (
    <>
      <Navbar />

      {/* ── HERO ── */}
      <div className="hero-wrapper" style={{ position: 'relative', width: '100%', background: "url('/header-image.png') center center / cover no-repeat" }}>
        <div style={{ content: "''", position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.55) 40%, rgba(0,0,0,0.8) 100%)', zIndex: 1 }} />
        <section className="section hero" style={{ position: 'relative', zIndex: 2, padding: '160px 48px 80px', maxWidth: 1200, margin: '0 auto' }}>
          <span className="gold-line hero-enter" />
          <div className="hero-label hero-enter hero-enter-delay-1" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 14, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 24, fontWeight: 400 }}>
            Capital &middot; Ventures &middot; Infrastructure
          </div>
          <h1 className="serif hero-enter hero-enter-delay-2" style={{ fontFamily: "'Cinzel', serif", fontSize: 'clamp(32px, 4.5vw, 56px)', fontWeight: 400, lineHeight: 1.2, maxWidth: 640, marginBottom: 24, letterSpacing: '-0.01em' }}>
            Pakistan&apos;s investment facilitation and advisory group.
          </h1>
          <p className="hero-enter hero-enter-delay-3" style={{ fontSize: 16, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 480, marginBottom: 48 }}>
            Anchored in <strong style={{ color: 'var(--gold)', fontWeight: 500 }}>Mining &amp; Minerals</strong>, <strong style={{ color: 'var(--gold)', fontWeight: 500 }}>Real Estate</strong>, and <strong style={{ color: 'var(--gold)', fontWeight: 500 }}>Construction &amp; Development</strong> &mdash; with structured access across thirteen sectors through our institutional infrastructure.
          </p>

          <div className="hero-ctas hero-enter hero-enter-delay-4" style={{ display: 'flex', gap: 16, marginBottom: 48, flexWrap: 'wrap' }}>
            <Link href="/contact" className="btn-gold">Schedule a Consultation &rarr;</Link>
            <Link href="/dashboard/investments" className="btn-outline" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '12px 28px', border: '1px solid var(--gold)', color: 'var(--gold)', fontSize: 13, fontWeight: 500, letterSpacing: '0.05em', textDecoration: 'none', transition: 'all 0.3s ease' }}>
              Explore Opportunities &rarr;
            </Link>
          </div>

          <div className="carousel-nav hero-enter hero-enter-delay-4" style={{ display: 'flex', gap: 12, marginBottom: 0 }}>
            <button onClick={() => scrollCards(-1)} aria-label="Previous">&larr;</button>
            <button onClick={() => scrollCards(1)} aria-label="Next">&rarr;</button>
          </div>

          <div className="cards-track" id="cardsTrack" ref={cardsTrackRef}>
            {sectorCards.map((sector) => (
              <Link href={`/sectors/${sector.slug}`} className="card" key={sector.slug}>
                <div className="card-glow" />
                <div className="card-icon">{sector.icon}</div>
                <h3>{sector.name}</h3>
                <p>{sector.description}</p>
                <span className="card-tag">{sector.tag}</span>
              </Link>
            ))}
          </div>
        </section>
      </div>

      <div className="divider" />

      {/* ── CORE SERVICES ── */}
      <section className="section fade-in" id="services">
        <h2 className="serif">How we support <span className="gold">investors.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px' }}>
          From entity formation through deal execution and ongoing portfolio oversight &mdash; a single counterparty for the entire investment lifecycle.
        </p>

        <div className="verticals-grid stagger fade-in" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
          {serviceCards.map((service) => (
            <Link href={`/services/${service.slug}`} className="vertical-card" key={service.slug}>
              <span className="v-number">{service.icon}</span>
              <div className="v-model">{service.model}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </Link>
          ))}
        </div>
      </section>

      <div className="divider" />

      {/* ── FROM COMPLEXITY TO CLARITY ── */}
      <section className="section section-center fade-in" id="network">
        <h2 className="serif">From complexity to <span className="gold">clarity.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px', marginLeft: 'auto', marginRight: 'auto' }}>
          Deep sectoral expertise across every major Pakistani market &mdash; click any sector to learn more.
        </p>

        <div className="sector-icons stagger fade-in">
          {sectorIcons.map((s) => (
            <div
              key={s.key}
              className={`sector-icon${activeSector === s.key ? ' active' : ''}`}
              onClick={() => showSector(s.key)}
            >
              {s.icon}
              <span className="sector-label">{s.label}</span>
            </div>
          ))}
        </div>

        <div className="sector-snippet">
          <div className={`sector-snippet-inner${snippetVisible ? ' show' : ''}`}>
            {sectorSnippet ? (
              <>
                <h3 className="serif">{sectorSnippet.title}</h3>
                <p>{sectorSnippet.text}</p>
                <Link href={sectorSnippet.link} className="snippet-link">Explore this sector &rarr;</Link>
              </>
            ) : (
              <>
                <h3>Select a sector above</h3>
                <p>Click any icon to explore our expertise across Pakistan&apos;s highest-growth investment sectors.</p>
              </>
            )}
          </div>
        </div>
      </section>

      <div className="divider" />

      {/* ── OPPORTUNITIES IN REAL TIME ── */}
      <section className="section section-center fade-in" id="showcase">
        <div className="hero-label" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 14, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 16, fontWeight: 400 }}>
          Live Pipeline
        </div>
        <h2 className="serif">Opportunities <span className="gold">in real time.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px', marginLeft: 'auto', marginRight: 'auto' }}>
          Real-time visibility into Pakistan&apos;s active deal pipeline &mdash; from mineral exploration to infrastructure tenders.
        </p>

        <div className="showcase-panel fade-in-scale">
          <div className="showcase-header">
            <span className="showcase-dot red" />
            <span className="showcase-dot yellow" />
            <span className="showcase-dot green" />
          </div>
          <div className="showcase-body">
            <div>
              <div className="metric">
                <div className="metric-label">Mineral Reserves Accessible</div>
                <div className="metric-value">$1T<span className="gold">+</span></div>
                <div className="showcase-bar"><div className="showcase-bar-fill" data-width="85%" /></div>
              </div>
              <div className="metric">
                <div className="metric-label">Active Sectors</div>
                <div className="metric-value">12 <span className="gold">verticals</span></div>
                <div className="showcase-bar"><div className="showcase-bar-fill" data-width="100%" /></div>
              </div>
              <div className="metric">
                <div className="metric-label">Sectors Covered</div>
                <div className="metric-value">13 <span className="gold">sectors</span></div>
                <div className="showcase-bar"><div className="showcase-bar-fill" data-width="65%" /></div>
              </div>
            </div>
            <div className="showcase-visual">
              <div className="showcase-chart" id="showcaseChart">
                {chartBarHeights.map((h, i) => (
                  <div key={i} className="chart-bar" style={{ height: h }} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="divider" />

      {/* ── VERTICALS ── */}
      <section className="section fade-in" id="verticals">
        <h2 className="serif">Thirteen sectors. <span className="gold">One partner.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px' }}>
          Capital deployment, resource sourcing, government markets, and infrastructure &mdash; a single counterparty across every vertical.
        </p>

        <div className="verticals-grid stagger fade-in">
          {verticals.map((v) => (
            <Link href={`/sectors/${v.slug}`} className={`vertical-card${v.coreFocus ? ' core-focus' : ''}`} key={v.slug}>
              <span className="v-number">{v.num}</span>
              {v.coreFocus && <span className="core-focus-badge">Core Focus</span>}
              <div className="v-model">{v.model}</div>
              <h3>{v.name}</h3>
              <p>{v.description}</p>
            </Link>
          ))}
        </div>
      </section>

      <div className="divider" />

      {/* ── GLOBAL PRESENCE ── */}
      <section className="section section-center fade-in" id="structure">
        <h2 className="serif">Global presence,<br /><span className="gold">local depth.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px', marginLeft: 'auto', marginRight: 'auto' }}>
          Headquartered in Islamabad, with investor relationships spanning six regions and international-standard transaction structures.
        </p>

        <div className="stats-grid stagger fade-in">
          {statsData.map((stat) => (
            <div className="stat-card" key={stat.name}>
              <div className="stat-flag">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={stat.flag} alt={stat.alt} />
              </div>
              <div className="stat-number">{stat.name}</div>
              <div className="stat-label">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      <div className="divider" />

      {/* ── AT YOUR COMMAND ── */}
      <section className="section fade-in">
        <div className="command-section">
          <div className="command-text fade-in-left">
            <h2 className="serif">At your command.</h2>
            <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px' }}>
              From initial assessment through deal closure &mdash; advisory, facilitation, and partnership across Pakistan&apos;s highest-value sectors.
            </p>
            <Link href="/contact" className="btn-outline">Explore Partnership &rarr;</Link>
          </div>
          <div className="command-keys fade-in-right">
            <div className="key">
              <span style={{ fontSize: 28, color: 'var(--gold)' }}>{'\u25C6'}</span>
              <small>access</small>
            </div>
            <div className="key">
              <span style={{ fontSize: 28, color: 'var(--gold)' }}>+</span>
              <small>&nbsp;</small>
            </div>
            <div className="key">
              <span style={{ fontSize: 28, color: 'var(--gold)' }}>{'\u2605'}</span>
              <small>capital</small>
            </div>
          </div>
        </div>
      </section>

      <div className="divider" />

      {/* ── LIVE NEWS FEED ── */}
      <section className="section section-center fade-in" id="insights">
        <div className="insight-dot" />
        <h2 className="serif">Latest <span className="gold">news.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px', marginLeft: 'auto', marginRight: 'auto' }}>
          Live market news and updates on Pakistan&apos;s investment landscape, sourced from leading publications.
        </p>

        <div className="filter-tabs" style={{ justifyContent: 'center' }}>
          {filterTabsData.map((tab, i) => (
            <button
              key={tab.label}
              className={`filter-tab${activeFilter === i ? ' active' : ''}`}
              onClick={() => {
                setActiveFilter(i)
                fetchNews(tab.query)
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="news-carousel-wrapper">
          <div className="news-carousel-card">
            {newsLoading && (
              <div className="news-loading">
                <div className="spinner" />
                Loading latest news&hellip;
              </div>
            )}
            {newsError && (
              <div className="news-error">
                <h3>Unable to load news</h3>
                <p>Please check your connection and try again later.</p>
              </div>
            )}
            {!newsLoading && !newsError && currentArticle && (
              <div className={`news-slide${slideDirection !== null ? (slideDirection > 0 ? ' slide-out-left' : ' slide-out-right') : ''}`}>
                {currentArticle.urlToImage && (
                  /* eslint-disable-next-line @next/next/no-img-element */
                  <img
                    className="news-thumb"
                    src={currentArticle.urlToImage}
                    alt=""
                    loading="lazy"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
                  />
                )}
                <div className="news-card-meta">
                  {currentArticle.source?.name && (
                    <span className="news-card-tag">{currentArticle.source.name}</span>
                  )}
                  <span className="news-card-date">{formatNewsDate(currentArticle.publishedAt)}</span>
                </div>
                <h3>{currentArticle.title}</h3>
                {currentArticle.description && (
                  <p>{truncateText(currentArticle.description, 200)}</p>
                )}
                <a href={currentArticle.url} target="_blank" rel="noopener noreferrer" className="news-card-link">
                  Read Full Article &rarr;
                </a>
              </div>
            )}
          </div>
          {!newsLoading && !newsError && newsArticles.length > 0 && (
            <>
              <div className="news-carousel-controls">
                <button className="news-nav-btn" onClick={() => changeSlide(-1)} disabled={currentSlide === 0}>&larr;</button>
                <span className="news-counter">
                  <span className="current">{currentSlide + 1}</span> / <span>{newsArticles.length}</span>
                </span>
                <button className="news-nav-btn" onClick={() => changeSlide(1)} disabled={currentSlide === newsArticles.length - 1}>&rarr;</button>
              </div>
              <div className="news-dots">
                {newsArticles.map((_, i) => (
                  <div key={i} className={`news-dot${i === currentSlide ? ' active' : ''}`} />
                ))}
              </div>
            </>
          )}
        </div>
      </section>

      <div className="divider" />

      {/* ── PARTNERS ── */}
      <section className="section section-center fade-in">
        <div className="hero-label" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 14, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 16, fontWeight: 400 }}>
          Who We Serve
        </div>
        <h2 className="serif">Built for serious <span className="gold">partners.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px', marginLeft: 'auto', marginRight: 'auto' }}>
          Institutional investors, sovereign entities, multinational corporations, and family offices deploying capital into Pakistan&apos;s highest-growth verticals.
        </p>

        <div className="partners-row stagger fade-in">
          {partnerNames.map((name) => (
            <span className="partner-name" key={name}>{name}</span>
          ))}
        </div>
      </section>

      <div className="divider" />

      {/* ── TESTIMONIALS ── */}
      <section className="section fade-in" id="testimonials">
        <h2 className="serif">What our clients <span className="gold">say.</span></h2>
        <p className="subtitle" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 17, lineHeight: 1.7, color: 'var(--white-dim)', maxWidth: 520, marginBottom: 60, letterSpacing: '0.5px' }}>
          From Gulf sovereign wealth to London private equity &mdash; how our partners describe the experience.
        </p>

        <div className="testimonials-overflow">
          <div className="testimonials-track">
            {/* Set 1 */}
            {testimonials.map((t, i) => (
              <div className="testimonial-card" key={`t1-${i}`}>
                <div className="testimonial-quote">&ldquo;</div>
                <p>{t.quote}</p>
                <div className="testimonial-author">{t.author}</div>
                <div className="testimonial-role">{t.role}</div>
              </div>
            ))}
            {/* Set 2 (duplicate for seamless loop) */}
            {testimonials.map((t, i) => (
              <div className="testimonial-card" key={`t2-${i}`}>
                <div className="testimonial-quote">&ldquo;</div>
                <p>{t.quote}</p>
                <div className="testimonial-author">{t.author}</div>
                <div className="testimonial-role">{t.role}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="divider" />

      {/* ── CTA ── */}
      <section className="cta-banner fade-in" id="contact">
        <h2 className="serif">Begin the <span className="gold">conversation.</span></h2>
        <p>Structured access to Pakistan&apos;s most compelling sectors &mdash; with a single, institutional-grade counterparty.</p>
        <Link href="/contact" className="btn-gold">Request a Consultation &rarr;</Link>
      </section>

      <Footer />
    </>
  )
}
