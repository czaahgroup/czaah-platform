'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { EnquiryForm } from '@/components/forms/EnquiryForm'

export default function NewEnquiryPage() {
  const router = useRouter()

  return (
    <>
      <Link
        href="/dashboard/enquiries"
        className="text-sm text-czaah-muted hover:text-czaah-gold transition-colors mb-6 inline-block"
      >
        &larr; Back to Enquiries
      </Link>

      <div className="max-w-2xl">
        <h1 className="font-[family-name:var(--font-heading)] text-2xl text-czaah-white mb-8">
          New Enquiry
        </h1>
        <EnquiryForm
          onSuccess={() => {
            setTimeout(() => router.push('/dashboard/enquiries'), 2000)
          }}
        />
      </div>
    </>
  )
}
