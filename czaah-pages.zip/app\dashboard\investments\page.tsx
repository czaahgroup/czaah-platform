'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

interface Investment {
  id: string
  title: string
  sector_tag: string | null
  status: string
  min_investment_amount: number | null
  currency: string
  target_return: string | null
  investment_timeline: string | null
  description: string | null
  location: string | null
  key_highlights: string[]
  published_at: string | null
}

const STATUS_BADGES: Record<string, string> = {
  published: 'bg-green-500/20 text-green-400',
  closing_soon: 'bg-orange-500/20 text-orange-400',
}

function formatStatus(status: string) {
  return status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

function formatCurrency(amount: number | null, currency: string) {
  if (amount === null || amount === undefined) return '--'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export default function InvestmentsBrowsePage() {
  const [investments, setInvestments] = useState<Investment[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [sectorFilter, setSectorFilter] = useState('')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function load() {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) { router.push('/login'); return }

        const res = await fetch('/api/investments')
        const json = await res.json()
        if (!res.ok) throw new Error(json.error || 'Failed to load investments')
        setInvestments(json.data || [])
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : 'Something went wrong')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Get unique sectors for filtering
  const sectors = [...new Set(investments.map((inv) => inv.sector_tag).filter(Boolean))] as string[]

  const filtered = investments.filter((inv) => {
    const matchesSector = !sectorFilter || inv.sector_tag === sectorFilter
    const matchesSearch = !search ||
      inv.title.toLowerCase().includes(search.toLowerCase()) ||
      (inv.sector_tag?.toLowerCase().includes(search.toLowerCase())) ||
      (inv.location?.toLowerCase().includes(search.toLowerCase()))
    return matchesSector && matchesSearch
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-czaah-muted">Loading...</div>
      </div>
    )
  }

  return (
    <>
      <div className="mb-6">
        <h1 className="font-[family-name:var(--font-heading)] text-2xl text-czaah-white mb-1">
          Investment Opportunities
        </h1>
        <p className="text-sm text-czaah-muted">
          Explore exclusive investment opportunities curated by CZAAH.
        </p>
      </div>

      {/* Search and filter */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search investments..."
          className="flex-1 bg-czaah-card border border-czaah-border rounded px-4 py-2.5 text-czaah-white placeholder:text-czaah-muted-dim text-sm"
        />
        {sectors.length > 0 && (
          <select
            value={sectorFilter}
            onChange={(e) => setSectorFilter(e.target.value)}
            className="bg-czaah-card border border-czaah-border rounded px-4 py-2.5 text-czaah-white text-sm"
          >
            <option value="">All Sectors</option>
            {sectors.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        )}
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 mb-6">
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      {/* Investment grid */}
      {filtered.length === 0 ? (
        <div className="bg-czaah-card border border-czaah-border rounded-lg px-6 py-16 text-center">
          <p className="text-czaah-muted">
            {investments.length === 0
              ? 'No investment opportunities available at this time.'
              : 'No investments match your search.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((inv) => (
            <Link
              key={inv.id}
              href={`/dashboard/investments/${inv.id}`}
              className="group bg-czaah-card border border-czaah-border rounded-lg overflow-hidden hover:border-czaah-gold/40 transition-all"
            >
              <div className="p-5">
                {/* Header */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <h3 className="font-[family-name:var(--font-heading)] text-lg text-czaah-white group-hover:text-czaah-gold transition-colors leading-tight">
                    {inv.title}
                  </h3>
                  <span className={`text-xs px-2 py-0.5 rounded shrink-0 ${STATUS_BADGES[inv.status] || ''}`}>
                    {formatStatus(inv.status)}
                  </span>
                </div>

                {/* Sector tag */}
                {inv.sector_tag && (
                  <span className="inline-block text-xs bg-czaah-gold/10 text-czaah-gold px-2 py-0.5 rounded mb-3">
                    {inv.sector_tag}
                  </span>
                )}

                {/* Description preview */}
                {inv.description && (
                  <p className="text-sm text-czaah-muted line-clamp-2 mb-4">
                    {inv.description}
                  </p>
                )}

                {/* Key metrics */}
                <div className="grid grid-cols-2 gap-3 pt-3 border-t border-czaah-border/50">
                  <div>
                    <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-0.5">Min Investment</p>
                    <p className="text-sm text-czaah-white font-medium">
                      {formatCurrency(inv.min_investment_amount, inv.currency)}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-0.5">Target Return</p>
                    <p className="text-sm text-czaah-gold font-medium">
                      {inv.target_return || '--'}
                    </p>
                  </div>
                  {inv.investment_timeline && (
                    <div>
                      <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-0.5">Timeline</p>
                      <p className="text-sm text-czaah-white">{inv.investment_timeline}</p>
                    </div>
                  )}
                  {inv.location && (
                    <div>
                      <p className="text-[10px] text-czaah-muted-dim uppercase tracking-wider mb-0.5">Location</p>
                      <p className="text-sm text-czaah-white">{inv.location}</p>
                    </div>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </>
  )
}
